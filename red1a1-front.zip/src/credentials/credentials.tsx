export const production = "https://red1a1-back.herokuapp.com/api";
export const development = "http://localhost:8080/api";

export const rentas = "61e99f0e0d3bd9163e4a4b42";
export const ventas = "61e99f120d3bd9163e4a4b46";
export const casasC = "61e99edd0d3bd9163e4a4b3a";
export const departamentosCat = "61e99ee80d3bd9163e4a4b3e";
export const desarrollosCat = "6213cb350d7c145fa7ae62ac";
export const localesCat = "6213cb3c0d7c145fa7ae62b0";
export const oficinasCat = "6213cb430d7c145fa7ae62b4";
export const bodegasCat = "6213cb480d7c145fa7ae62b8";

export const googleClientId =
  "670476434432-m4i4b7hvrlds0lunt1k3tbes8983p6i2.apps.googleusercontent.com";

export const stripePublicId =
  "pk_test_51KlHyqITJUOVXM1TTiuTj9Nbl5UjpkOdn4j3nl42D64lUaV9TnNkMgCPMaSzPJm68LtLmLTPiC2O8ZOKbEWncRs100hxibM6CC";