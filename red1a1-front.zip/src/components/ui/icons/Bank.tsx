export const Bank = () => {
  return <i className="bi bi-bank"></i>;
};
