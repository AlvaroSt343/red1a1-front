export const CashCoin = () => {
  return <i className="bi bi-cash-coin" />;
};
