export const Referencia = () => {
  return <i className="bi bi-shuffle"></i>;
};
