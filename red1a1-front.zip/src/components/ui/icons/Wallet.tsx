export const Wallet = () => {
  return <i className="bi bi-wallet" />;
};
