import { Col, Container, Row } from "react-bootstrap";

const DatosReferencias = () => {
  return (
    <Container>
      <Row>
        <Col>
          <span>Número de cuenta: 123456789</span>
        </Col>
        <Col>
          <span>CLABE 123456 123546 123456</span>
        </Col>
        <Col>
          <span>Beneficiario Red1a1</span>
        </Col>
      </Row>
    </Container>
  );
};

export default DatosReferencias;
