export * from "./InmueblesInterface";
