"use strict";
(() => {
var exports = {};
exports.id = 1677;
exports.ids = [1677,2197];
exports.modules = {

/***/ 6681:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C7": () => (/* binding */ production),
/* harmony export */   "GJ": () => (/* binding */ rentas),
/* harmony export */   "DJ": () => (/* binding */ ventas),
/* harmony export */   "bF": () => (/* binding */ casasC),
/* harmony export */   "ay": () => (/* binding */ departamentosCat),
/* harmony export */   "Bd": () => (/* binding */ desarrollosCat),
/* harmony export */   "qn": () => (/* binding */ localesCat),
/* harmony export */   "iS": () => (/* binding */ oficinasCat),
/* harmony export */   "A9": () => (/* binding */ bodegasCat),
/* harmony export */   "eq": () => (/* binding */ googleClientId),
/* harmony export */   "tB": () => (/* binding */ stripePublicId)
/* harmony export */ });
/* unused harmony export development */
const production = "https://red1a1-back.herokuapp.com/api";
const development = "http://localhost:8080/api";
const rentas = "61e99f0e0d3bd9163e4a4b42";
const ventas = "61e99f120d3bd9163e4a4b46";
const casasC = "61e99edd0d3bd9163e4a4b3a";
const departamentosCat = "61e99ee80d3bd9163e4a4b3e";
const desarrollosCat = "6213cb350d7c145fa7ae62ac";
const localesCat = "6213cb3c0d7c145fa7ae62b0";
const oficinasCat = "6213cb430d7c145fa7ae62b4";
const bodegasCat = "6213cb480d7c145fa7ae62b8";
const googleClientId = "670476434432-m4i4b7hvrlds0lunt1k3tbes8983p6i2.apps.googleusercontent.com";
const stripePublicId = "pk_test_51KlHyqITJUOVXM1TTiuTj9Nbl5UjpkOdn4j3nl42D64lUaV9TnNkMgCPMaSzPJm68LtLmLTPiC2O8ZOKbEWncRs100hxibM6CC";


/***/ }),

/***/ 121:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _credentials_credentials__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6681);
/* harmony import */ var _404__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9622);



const getStaticProps = async ()=>{
    const resp = await fetch(`${_credentials_credentials__WEBPACK_IMPORTED_MODULE_2__/* .production */ .C7}/inmuebles/`);
    const data = await resp.json();
    return {
        props: {
            data
        },
        revalidate: 15
    };
};
const Index = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_404__WEBPACK_IMPORTED_MODULE_1__["default"], {
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);


/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1728,9622], () => (__webpack_exec__(121)));
module.exports = __webpack_exports__;

})();