(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 7415:
/***/ ((module) => {

// Exports
module.exports = {
	"VentanaChat": "Contenido_VentanaChat__LNywL",
	"header": "Contenido_header___HwuI",
	"perfilImg": "Contenido_perfilImg__RwB4Y",
	"nombre": "Contenido_nombre__ZvSQk",
	"conexion": "Contenido_conexion__nbZMV",
	"dashIcon": "Contenido_dashIcon__dpggg",
	"hora": "Contenido_hora__0uzaq",
	"chatBox": "Contenido_chatBox__wzlLF",
	"sendMensajeFooter": "Contenido_sendMensajeFooter__6TPfH",
	"btnEnviar": "Contenido_btnEnviar__BJV3T",
	"iconSend": "Contenido_iconSend__YG57X",
	"messageBox": "Contenido_messageBox__o7B1q",
	"mensaje1": "Contenido_mensaje1__npbQU",
	"mensaje2": "Contenido_mensaje2__ip34G"
};


/***/ }),

/***/ 8258:
/***/ ((module) => {

// Exports
module.exports = {
	"michat": "MisChats_michat__VuAIs",
	"ChatHover": "MisChats_ChatHover__U_YJo",
	"OFhead": "MisChats_OFhead__g45tf",
	"OFbody": "MisChats_OFbody__jLwff",
	"hora": "MisChats_hora__YMSrV",
	"nombre": "MisChats_nombre__bKIGR",
	"mensaje": "MisChats_mensaje__FaQnJ",
	"backImg": "MisChats_backImg__rIRST"
};


/***/ }),

/***/ 4467:
/***/ ((module) => {

// Exports
module.exports = {
	"modalLabels": "AuthModal_modalLabels__T9Gnb",
	"modalInputs": "AuthModal_modalInputs__pKywC",
	"modalGoogleBtn": "AuthModal_modalGoogleBtn__5BN8B",
	"modalFbBtn": "AuthModal_modalFbBtn__jX4ZA",
	"modalContent": "AuthModal_modalContent__Bs1MU",
	"mostrarContraseña": "AuthModal_mostrarContrase_a__R5GLX"
};


/***/ }),

/***/ 2893:
/***/ ((module) => {

// Exports
module.exports = {
	"buscador": "Buscador_buscador__T0bve",
	"respuesta": "Buscador_respuesta__a37x9",
	"item": "Buscador_item__bLX3L",
	"buscador2": "Buscador_buscador2__yH_nM",
	"respuesta2": "Buscador_respuesta2__QI3Yv",
	"item2": "Buscador_item2__INoMs",
	"filterIcon": "Buscador_filterIcon__44GQr",
	"filterIconActive": "Buscador_filterIconActive__HtYGw",
	"leftArrow": "Buscador_leftArrow__XR6MH"
};


/***/ }),

/***/ 2566:
/***/ ((module) => {

// Exports
module.exports = {
	"footerContent": "Footer_footerContent__UgKm3",
	"footerStyle": "Footer_footerStyle__DQ7O6",
	"footerLink": "Footer_footerLink___LKy_",
	"footerPhone": "Footer_footerPhone__23_dN",
	"mbExtend": "Footer_mbExtend__Swhob"
};


/***/ }),

/***/ 8716:
/***/ ((module) => {

// Exports
module.exports = {
	"navStyle": "Header_navStyle__HBCv5",
	"navEnlace": "Header_navEnlace__TYTt8",
	"navPerfil": "Header_navPerfil__dF0Er",
	"sesionBtn": "Header_sesionBtn__pknjn",
	"menu": "Header_menu__Cd6rh",
	"menuItem": "Header_menuItem__Ca4o_",
	"menuCerrar": "Header_menuCerrar__tw89B",
	"notifImg": "Header_notifImg__8qPNW",
	"notificacionContainer": "Header_notificacionContainer__PQVfF",
	"notificaciones": "Header_notificaciones__e1XvX",
	"pendiente": "Header_pendiente__Xhvwo",
	"noPendiente": "Header_noPendiente__fT0L4",
	"iconNoti": "Header_iconNoti__P5iXP",
	"headerNotif": "Header_headerNotif__Wh4n3",
	"propH": "Header_propH__HDYyd",
	"btnApprove": "Header_btnApprove__o_q6H",
	"btnReject": "Header_btnReject__0f9Av",
	"footVer": "Header_footVer__k33Bz",
	"notContainer": "Header_notContainer__7Ex1M",
	"listIcon": "Header_listIcon__8lS3F",
	"respNavbar": "Header_respNavbar__jRSie",
	"resHeader": "Header_resHeader__y0QcG",
	"resHeaderAtive": "Header_resHeaderAtive__DSBnY",
	"headerLinkItem": "Header_headerLinkItem__MKQKt"
};


/***/ }),

/***/ 7410:
/***/ ((module) => {

// Exports
module.exports = {
	"purple-nav": "PurpleHeader_purple-nav__g9zU8",
	"searchBtn": "PurpleHeader_searchBtn__XIuzm",
	"purpleNav2": "PurpleHeader_purpleNav2__PPyNA",
	"purpleLinks": "PurpleHeader_purpleLinks__iSDNA",
	"filterIconContainer": "PurpleHeader_filterIconContainer__krHoa",
	"filterIcon": "PurpleHeader_filterIcon__IfiC6",
	"filterIconActive": "PurpleHeader_filterIconActive__wYevn",
	"searchInput": "PurpleHeader_searchInput__Jib2q",
	"notificacion": "PurpleHeader_notificacion___ygw2"
};


/***/ }),

/***/ 7144:
/***/ ((module) => {

// Exports
module.exports = {
	"ocultarHeaderResponsive": "Responsive_ocultarHeaderResponsive__CWUIz",
	"mostrarHeaderResponsive": "Responsive_mostrarHeaderResponsive__qUxPC"
};


/***/ }),

/***/ 6323:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1165);
/* harmony import */ var _paginas_perfil_chats_VentanaChat__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3458);
/* harmony import */ var _ui_footer_Footer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9348);
/* harmony import */ var _ui_header_Header__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1198);
/* harmony import */ var _ui_purpleheader_PurpleHeader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3038);
/* harmony import */ var components_ui_buscador_BuscadorRes__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(475);
/* harmony import */ var components_ui_header_ResponsiveHeader__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3091);
/* harmony import */ var _styles_Responsive_module_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7144);
/* harmony import */ var _styles_Responsive_module_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_styles_Responsive_module_css__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var components_ui_responsive_BottomNavBar__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7729);
/* harmony import */ var context_map_MapContext__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1131);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_paginas_perfil_chats_VentanaChat__WEBPACK_IMPORTED_MODULE_4__, _ui_header_Header__WEBPACK_IMPORTED_MODULE_6__]);
([_paginas_perfil_chats_VentanaChat__WEBPACK_IMPORTED_MODULE_4__, _ui_header_Header__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);













const Layout = ({ children  })=>{
    const { verificaToken , auth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__/* .AuthContext */ .V);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { ocultarBottomNav  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(context_map_MapContext__WEBPACK_IMPORTED_MODULE_11__/* .MapContext */ .X);
    const admin = router.pathname.includes("dashboard");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        verificaToken();
    }, [
        verificaToken
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: admin ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: children
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_Responsive_module_css__WEBPACK_IMPORTED_MODULE_12___default().ocultarHeaderResponsive),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_header_Header__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_purpleheader_PurpleHeader__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_Responsive_module_css__WEBPACK_IMPORTED_MODULE_12___default().mostrarHeaderResponsive),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ui_header_ResponsiveHeader__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ui_buscador_BuscadorRes__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        }),
                        auth.logged && ocultarBottomNav ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ui_responsive_BottomNavBar__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        }) : null
                    ]
                }),
                children,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_paginas_perfil_chats_VentanaChat__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_footer_Footer__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

});

/***/ }),

/***/ 9756:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ chats_Mensaje)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "linkify-react"
const external_linkify_react_namespaceObject = require("linkify-react");
var external_linkify_react_default = /*#__PURE__*/__webpack_require__.n(external_linkify_react_namespaceObject);
// EXTERNAL MODULE: ./src/components/paginas/perfil/chats/Contenido.module.css
var Contenido_module = __webpack_require__(7415);
var Contenido_module_default = /*#__PURE__*/__webpack_require__.n(Contenido_module);
// EXTERNAL MODULE: ./src/helpers/horaMes.tsx
var horaMes = __webpack_require__(3289);
;// CONCATENATED MODULE: ./src/components/paginas/perfil/chats/Mensaje.tsx




const options = {
    defaultProtocol: "https",
    target: "_blank",
    rel: "noopener noreferrer"
};
const Mensaje = ({ mensaje , propio  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "col-11 mb-2",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: propio ? (Contenido_module_default()).mensaje2 : (Contenido_module_default()).mensaje1,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((external_linkify_react_default()), {
                    options: options,
                    children: mensaje.mensaje
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `d-flex justify-content-end ${(Contenido_module_default()).hora}`,
                    children: (0,horaMes/* horaMes */._3)(mensaje && mensaje.createdAt)
                })
            ]
        })
    }));
};
/* harmony default export */ const chats_Mensaje = (Mensaje);


/***/ }),

/***/ 1565:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ chats_MisChats)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/context/chat/ChatContext.tsx + 1 modules
var ChatContext = __webpack_require__(1458);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
// EXTERNAL MODULE: ./src/components/ui/loading/Loading.tsx
var Loading = __webpack_require__(6220);
// EXTERNAL MODULE: ./src/hooks/useConversaciones.tsx
var useConversaciones = __webpack_require__(5440);
// EXTERNAL MODULE: ./src/context/auth/AuthContext.tsx
var AuthContext = __webpack_require__(1165);
// EXTERNAL MODULE: ./src/credentials/credentials.tsx
var credentials = __webpack_require__(6681);
// EXTERNAL MODULE: ./src/helpers/fetch.tsx
var helpers_fetch = __webpack_require__(22);
// EXTERNAL MODULE: ./src/helpers/horaMes.tsx
var horaMes = __webpack_require__(3289);
// EXTERNAL MODULE: ./src/components/paginas/perfil/chats/MisChats.module.css
var MisChats_module = __webpack_require__(8258);
var MisChats_module_default = /*#__PURE__*/__webpack_require__.n(MisChats_module);
;// CONCATENATED MODULE: ./src/components/paginas/perfil/chats/Chat.tsx









const Chat = ({ handleCloseCanvas , conversacion  })=>{
    var ref2, ref1;
    const { dispatch , scrollToBotom  } = (0,external_react_.useContext)(ChatContext/* ChatContext */.p5);
    const { auth  } = (0,external_react_.useContext)(AuthContext/* AuthContext */.V);
    const { 0: contacto1 , 1: setContacto  } = (0,external_react_.useState)();
    const { ultimoMsg  } = (0,useConversaciones/* useUltimoMsg */.A)(conversacion.remitente, conversacion.para);
    const ultimo = ultimoMsg && ultimoMsg.length - 1;
    (0,external_react_.useEffect)(()=>{
        const contacto = conversacion.miembros.find((miembro)=>miembro !== auth.uid
        );
        const traerContacto = async ()=>{
            const resp = await fetch(`${credentials/* production */.C7}/usuarios/${contacto}`);
            const data = await resp.json();
            setContacto(data);
        };
        traerContacto();
    }, [
        conversacion,
        auth
    ]);
    const activarChat = async ()=>{
        var ref;
        dispatch({
            type: "ActivarChat",
            payload: contacto1 === null || contacto1 === void 0 ? void 0 : contacto1.uid
        });
        const resp = await (0,helpers_fetch/* obtenerMensajes */.Xo)(`mensajes/${contacto1 === null || contacto1 === void 0 ? void 0 : contacto1.uid}`);
        dispatch({
            type: "CargarMensajes",
            payload: resp.mensajes
        });
        (ref = scrollToBotom.current) === null || ref === void 0 ? void 0 : ref.scrollIntoView();
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        onClick: handleCloseCanvas,
        className: `${(MisChats_module_default()).ChatHover} pointer mb-2`,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (MisChats_module_default()).michat,
            onClick: activarChat,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-2 text-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (MisChats_module_default()).backImg,
                            children: contacto1 ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: contacto1.img,
                                alt: contacto1.nombre,
                                style: {
                                    borderRadius: "50%",
                                    width: 55,
                                    height: 55
                                }
                            }) : null
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-10",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (MisChats_module_default()).nombre,
                                children: contacto1 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        contacto1.nombre,
                                        " ",
                                        contacto1.apellido
                                    ]
                                }) : null
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (MisChats_module_default()).mensaje,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `d-flex justify-content-between `,
                                    children: ultimoMsg.length === 0 ? "A\xfan no hay mensajes" : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: (ref2 = ultimoMsg[ultimo]) === null || ref2 === void 0 ? void 0 : ref2.mensaje
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: (MisChats_module_default()).hora,
                                                children: (0,horaMes/* hora */.rp)((ref1 = ultimoMsg[ultimo]) === null || ref1 === void 0 ? void 0 : ref1.createdAt)
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const chats_Chat = (Chat);

;// CONCATENATED MODULE: ./src/components/paginas/perfil/chats/MisChats.tsx







const MisChats = ({ showCanvas , handleCloseCanvas  })=>{
    const { cargando , conversaciones  } = (0,external_react_.useContext)(ChatContext/* ChatContext */.p5);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Offcanvas, {
        show: showCanvas,
        onHide: handleCloseCanvas,
        placement: "end",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Offcanvas.Header, {
                closeButton: true,
                className: (MisChats_module_default()).OFhead,
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Offcanvas.Title, {
                    children: "Mis chats"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Offcanvas.Body, {
                className: (MisChats_module_default()).OFbody,
                children: conversaciones.map((conversacion, i)=>/*#__PURE__*/ jsx_runtime_.jsx(external_react_.Fragment, {
                        children: cargando ? /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {
                        }) : /*#__PURE__*/ jsx_runtime_.jsx(chats_Chat, {
                            conversacion: conversacion,
                            handleCloseCanvas: handleCloseCanvas
                        })
                    }, i)
                )
            })
        ]
    }));
};
/* harmony default export */ const chats_MisChats = (MisChats);


/***/ }),

/***/ 3458:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1165);
/* harmony import */ var _context_chat_ChatContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1458);
/* harmony import */ var _context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1810);
/* harmony import */ var _hooks_useForm__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1267);
/* harmony import */ var _hooks_useUserInfo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9227);
/* harmony import */ var _Contenido_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7415);
/* harmony import */ var _Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _Mensaje__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9756);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_5__]);
_context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];










const VentanaChat = ()=>{
    const { auth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__/* .AuthContext */ .V);
    const { socket  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_5__/* .SocketContext */ .J);
    const { setMinimizarChat , minimizarChat , chatState , dispatch , mensajePara , scrollToBotom ,  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_chat_ChatContext__WEBPACK_IMPORTED_MODULE_4__/* .ChatContext */ .p5);
    const { user  } = (0,_hooks_useUserInfo__WEBPACK_IMPORTED_MODULE_7__/* .useUserInfo */ .Pc)(chatState.chatActivo || mensajePara);
    const scrollTo = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { 0: limite , 1: setLimite  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { formulario , handleChange , setFormulario  } = (0,_hooks_useForm__WEBPACK_IMPORTED_MODULE_6__/* .useForm */ .c)({
        mensaje: ""
    });
    const { mensaje: mensaje1  } = formulario;
    const ocultarVentana = ()=>dispatch({
            type: "DesactivarChat",
            payload: null
        })
    ;
    const minimizarVentana = ()=>setMinimizarChat(!minimizarChat)
    ;
    const handleSubmit = async (e)=>{
        e.preventDefault();
        if (mensaje1.length === 0) return;
        const nuevoMensaje = {
            remitente: auth.uid,
            mensaje: mensaje1,
            para: chatState.chatActivo,
            conversacion: chatState.chatActivo
        };
        const notificacion = {
            remitente: auth.uid,
            para: chatState.chatActivo,
            nombre: auth.nombre,
            apellido: auth.apellido,
            mensaje: mensaje1
        };
        socket === null || socket === void 0 ? void 0 : socket.emit("mensaje-personal", nuevoMensaje);
        socket === null || socket === void 0 ? void 0 : socket.emit("nueva-notificacion", notificacion);
        setFormulario({
            mensaje: ""
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        var ref;
        (ref = scrollTo.current) === null || ref === void 0 ? void 0 : ref.scrollIntoView({
            behavior: "smooth"
        });
    }, [
        chatState.mensajes
    ]);
    const cargarMasMensajes = ()=>{
        console.log("cargar m\xe1s mensajes");
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        children: chatState.chatActivo ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().VentanaChat),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().header),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2 text-end",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            className: (_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().perfilImg),
                                            src: user === null || user === void 0 ? void 0 : user.img,
                                            alt: user === null || user === void 0 ? void 0 : user.nombre
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-7",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: `${(_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().nombre)}`,
                                                children: [
                                                    user === null || user === void 0 ? void 0 : user.nombre,
                                                    " ",
                                                    user === null || user === void 0 ? void 0 : user.apellido
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().conexion),
                                                children: (user === null || user === void 0 ? void 0 : user.online) ? "En l\xednea" : "Desconectado"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-3 text-end p-0",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                onClick: minimizarVentana,
                                                className: `${(_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().dashIcon)} ${minimizarChat ? "bi bi-dash-lg" : "bi bi-app"}  me-2 pointer`
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: ocultarVentana,
                                                type: "button",
                                                className: "btn-close btn-close-white mt-3 me-3",
                                                "aria-label": "Close"
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    }),
                    minimizarChat ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-12",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().chatBox),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "row d-flex justify-content-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "text-center",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    onClick: cargarMasMensajes,
                                                    className: "bi bi-arrow-bar-up pointer",
                                                    style: {
                                                        fontSize: 25
                                                    }
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: chatState.mensajes.map((mensaje)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        ref: scrollToBotom,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            ref: scrollTo,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Mensaje__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                mensaje: mensaje,
                                                                propio: mensaje.remitente === auth.uid
                                                            })
                                                        })
                                                    }, mensaje._id)
                                                )
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-12",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().sendMensajeFooter),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "row d-flex justify-content-center",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-12",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Form, {
                                                onSubmit: handleSubmit,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "input-group",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            type: "text",
                                                            className: `${(_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().messageBox)} form-control`,
                                                            placeholder: "Mensaje...",
                                                            value: mensaje1,
                                                            onChange: handleChange,
                                                            name: "mensaje",
                                                            autoComplete: "off"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: `${(_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().btnEnviar)} input-group-text`,
                                                            id: "basic-addon2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                className: (_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().iconSend),
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                    className: "bi bi-send text-white"
                                                                })
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    })
                                })
                            })
                        ]
                    }) : null
                ]
            })
        }) : null
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VentanaChat);

});

/***/ }),

/***/ 4078:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hooks_useForm__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1267);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7924);
/* harmony import */ var _modaltitle_Modaltitle__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4074);
/* harmony import */ var _AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4467);
/* harmony import */ var _AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1165);
/* harmony import */ var react_google_login__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(67);
/* harmony import */ var react_google_login__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_google_login__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var credentials_credentials__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6681);













const RegisterModal = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { 0: showPassword , 1: setShowPassword  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: showPassword2 , 1: setShowPassword2  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { register , mostrarRegistro , cerrarRegistro , abrirLogin , signInWithGoogle ,  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_9__/* .AuthContext */ .V);
    const { formulario , handleChange  } = (0,_hooks_useForm__WEBPACK_IMPORTED_MODULE_5__/* .useForm */ .c)({
        nombre: "",
        apellido: "",
        correo: "",
        password: "",
        password2: "",
        role: "Usuario"
    });
    const { nombre , apellido , correo , password , password2 , role  } = formulario;
    const onSubmit = async (e1)=>{
        e1.preventDefault();
        if (password !== password2) react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error("Las contrase\xf1as no coinciden");
        if (password.length < 6) {
            react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error("La contrase\xf1a tiene que ser de al menos 6 caracteres");
        }
        if (password === password2) {
            const resp = await register(nombre, apellido, correo, password, role);
            if (resp.errors) {
                resp.errors.map((e)=>{
                    return react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(e.msg);
                });
            }
            if (resp.ok) {
                const bienvida = {
                    nombre: resp.usuario.nombre,
                    apellido: resp.usuario.apellido,
                    correo: resp.usuario.correo
                };
                await fetch(`${credentials_credentials__WEBPACK_IMPORTED_MODULE_11__/* .production */ .C7}/correos/bienvenida`, {
                    method: "POST",
                    headers: {
                        "Content-type": "application/json"
                    },
                    body: JSON.stringify(bienvida)
                });
                router.push("/perfil/actualizar-perfil");
                cerrarRegistro();
            }
        }
    };
    const handleModals = ()=>{
        cerrarRegistro();
        abrirLogin();
    };
    const mostrarContraseña = ()=>setShowPassword(!showPassword)
    ;
    const mostrarContraseña2 = ()=>setShowPassword2(!showPassword2)
    ;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Modal, {
            show: mostrarRegistro,
            onHide: cerrarRegistro,
            contentClassName: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12___default().modalContent),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Modal.Header, {
                    closeButton: true,
                    style: {
                        border: "none"
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_4__.ToastContainer, {
                    autoClose: 10000
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Modal.Body, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form, {
                        onSubmit: onSubmit,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row d-flex justify-content-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modaltitle_Modaltitle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    titulo: "Registrarse"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-10",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12___default().modalLabels),
                                            children: "Nombre"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: `${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12___default().modalInputs)} mb-4`,
                                            type: "mail",
                                            name: "nombre",
                                            value: nombre,
                                            onChange: handleChange,
                                            required: true
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-10",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12___default().modalLabels),
                                            children: "Apellidos"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: `${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12___default().modalInputs)} mb-4`,
                                            type: "mail",
                                            name: "apellido",
                                            value: apellido,
                                            onChange: handleChange,
                                            required: true
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-10",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12___default().modalLabels),
                                            children: "Correo electr\xf3nico"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: `${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12___default().modalInputs)} mb-4`,
                                            type: "mail",
                                            name: "correo",
                                            value: correo,
                                            onChange: handleChange,
                                            required: true
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-10",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12___default().modalLabels),
                                            children: "Contrase\xf1a"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: `${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12___default().modalInputs)} mb-4`,
                                                    type: showPassword ? "text" : "password",
                                                    name: "password",
                                                    value: password,
                                                    onChange: handleChange,
                                                    required: true
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    onClick: mostrarContraseña,
                                                    className: `${showPassword ? "bi bi-eye-slash" : "bi bi-eye"} ${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12___default()["mostrarContraseña"])}`
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-10",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12___default().modalLabels),
                                            children: "Confirme su contrase\xf1a"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: `${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12___default().modalInputs)} mb-4`,
                                                    type: showPassword2 ? "text" : "password",
                                                    name: "password2",
                                                    value: password2,
                                                    onChange: handleChange,
                                                    required: true
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    onClick: mostrarContraseña2,
                                                    className: `${showPassword2 ? "bi bi-eye-slash" : "bi bi-eye"} ${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12___default()["mostrarContraseña"])}`
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-10 mb-3 text-center",
                                    children: nombre.length > 0 && apellido.length > 0 && correo.length > 0 && password.length > 0 && password2.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        titulo: "Registrarse"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        titulo: "Registrarse",
                                        btn: "Disabled"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-4 my-4",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-2 text-center my-4 modal-labels",
                                    children: "O"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-4 my-4",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_google_login__WEBPACK_IMPORTED_MODULE_10___default()), {
                                    clientId: credentials_credentials__WEBPACK_IMPORTED_MODULE_11__/* .googleClientId */ .eq,
                                    buttonText: "Inicia sesi\xf3n con google",
                                    onSuccess: signInWithGoogle,
                                    onFailure: signInWithGoogle,
                                    cookiePolicy: "single_host_origin",
                                    render: (renderProps)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            onClick: renderProps.onClick,
                                            className: "col-10 mb-3 text-center pointer",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_12___default().modalGoogleBtn),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        className: "me-3",
                                                        src: "/images/icons/google-icon.png",
                                                        alt: "Inicia sesi\xf3n con google"
                                                    }),
                                                    "Reg\xedstrate con Google"
                                                ]
                                            })
                                        })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        onClick: handleModals,
                                        className: "pointer",
                                        style: {
                                            color: "#3D87F6"
                                        },
                                        children: "\xbfYa tienes cuenta? \xa1Inicia sesi\xf3n!"
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RegisterModal);


/***/ }),

/***/ 1672:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_google_login__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(67);
/* harmony import */ var react_google_login__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_google_login__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1165);
/* harmony import */ var _hooks_useForm__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1267);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7924);
/* harmony import */ var _modaltitle_Modaltitle__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4074);
/* harmony import */ var _AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4467);
/* harmony import */ var _AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var credentials__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6681);













const LoginModal = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { 0: showPassword , 1: setShowPassword  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { login , mostrarLogin , cerrarLogin , abrirRegistro , signInWithGoogle  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_6__/* .AuthContext */ .V);
    const { formulario , handleChange , setFormulario  } = (0,_hooks_useForm__WEBPACK_IMPORTED_MODULE_7__/* .useForm */ .c)({
        correo: "",
        password: "",
        rememberme: false
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const correo = localStorage.getItem("correo");
        if (correo) {
            setFormulario({
                ...formulario,
                correo,
                rememberme: true
            });
        }
    }, []);
    const { correo: correo1 , password , rememberme  } = formulario;
    const toggleCheck = ()=>{
        setFormulario({
            ...formulario,
            rememberme: !rememberme
        });
    };
    const onSubmit = async (e)=>{
        e.preventDefault();
        rememberme ? localStorage.setItem("correo", correo1) : localStorage.removeItem("correo");
        const resp = await login(correo1, password);
        if (!resp.ok) {
            react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(resp.msg);
        }
        if (resp.ok) {
            router.push("/perfil");
            cerrarLogin();
        }
    };
    const mostrarContraseña = ()=>setShowPassword(!showPassword)
    ;
    const handleModals = ()=>{
        cerrarLogin();
        abrirRegistro();
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Modal, {
        show: mostrarLogin,
        onHide: cerrarLogin,
        contentClassName: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalContent),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Modal.Header, {
                closeButton: true,
                style: {
                    border: "none"
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_4__.ToastContainer, {
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Modal.Body, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form, {
                    onSubmit: onSubmit,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row d-flex justify-content-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modaltitle_Modaltitle__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                titulo: "Inicia sesi\xf3n"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-10",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalLabels),
                                        children: "Correo electr\xf3nico"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        className: `${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalInputs)} mb-4`,
                                        type: "mail",
                                        name: "correo",
                                        value: correo1,
                                        onChange: handleChange,
                                        required: true
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-10",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalLabels),
                                        children: "Contrase\xf1a"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                className: `${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalInputs)} mb-4`,
                                                type: showPassword ? "text" : "password",
                                                name: "password",
                                                value: password,
                                                onChange: handleChange,
                                                required: true
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                onClick: mostrarContraseña,
                                                className: `${showPassword ? "bi bi-eye-slash" : "bi bi-eye"} ${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default()["mostrarContraseña"])}`
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-4 my-4",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-2 text-center my-4 modal-labels",
                                children: "O"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-4 my-4",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_google_login__WEBPACK_IMPORTED_MODULE_5__.GoogleLogin, {
                                clientId: credentials__WEBPACK_IMPORTED_MODULE_12__/* .googleClientId */ .eq,
                                buttonText: "Inicia sesi\xf3n con google",
                                onSuccess: signInWithGoogle,
                                onFailure: signInWithGoogle,
                                cookiePolicy: "single_host_origin",
                                render: (renderProps)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        onClick: renderProps.onClick,
                                        className: "col-10 mb-3 text-center pointer",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalGoogleBtn),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    className: "me-3",
                                                    src: "/images/icons/google-icon.png",
                                                    alt: "Inicia sesi\xf3n con google"
                                                }),
                                                "Inicia sesi\xf3n con Google"
                                            ]
                                        })
                                    })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-10 mb-3",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-check",
                                    onClick: ()=>toggleCheck()
                                    ,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: "form-check-input",
                                            type: "checkbox",
                                            name: "rememberme",
                                            checked: rememberme,
                                            readOnly: true
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "modal-labels",
                                            children: "Recordarme"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-10 mb-3 text-center",
                                children: correo1.length > 0 && password.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    titulo: "Iniciar sesi\xf3n"
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    titulo: "Iniciar sesi\xf3n",
                                    btn: "Disabled"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-center",
                                style: {
                                    color: "#3D87F6"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    onClick: handleModals,
                                    className: "pointer",
                                    children: "\xbfA\xfan no tienes cuenta? \xa1Reg\xedstrate!"
                                })
                            })
                        ]
                    })
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoginModal);


/***/ }),

/***/ 2059:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_geosuggest__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8580);
/* harmony import */ var react_geosuggest__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_geosuggest__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _context_map_MapContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1131);
/* harmony import */ var _Buscador_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2893);
/* harmony import */ var _Buscador_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_Buscador_module_css__WEBPACK_IMPORTED_MODULE_5__);






const Buscador = ()=>{
    const geosuggestEl = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { setFiltros , filtros  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_map_MapContext__WEBPACK_IMPORTED_MODULE_4__/* .MapContext */ .X);
    const { setCoordenadas , setDirMapa , setZoom  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_map_MapContext__WEBPACK_IMPORTED_MODULE_4__/* .MapContext */ .X);
    const mostrarFiltros = ()=>setFiltros(true)
    ;
    const onSuggestSelect = (suggest)=>{
        !suggest ? setCoordenadas({
            lat: 19.4326077,
            lng: -99.133208
        }) : setCoordenadas({
            lat: suggest.location.lat,
            lng: suggest.location.lng
        });
        router.push("/");
        !suggest ? setDirMapa(null) : setDirMapa(suggest.label);
        !suggest ? setZoom(5) : setZoom(12);
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_geosuggest__WEBPACK_IMPORTED_MODULE_3___default()), {
        onFocus: mostrarFiltros,
        ref: geosuggestEl,
        queryDelay: 530,
        country: "mx",
        placeholder: "Busca aqu\xed...",
        onSuggestSelect: onSuggestSelect,
        autoComplete: "off",
        inputClassName: (_Buscador_module_css__WEBPACK_IMPORTED_MODULE_5___default().buscador),
        suggestsClassName: (_Buscador_module_css__WEBPACK_IMPORTED_MODULE_5___default().respuesta),
        suggestItemClassName: (_Buscador_module_css__WEBPACK_IMPORTED_MODULE_5___default().item)
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Buscador);


/***/ }),

/***/ 475:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var context_map_MapContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1131);
/* harmony import */ var _Buscador__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2059);
/* harmony import */ var _Buscador_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2893);
/* harmony import */ var _Buscador_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Buscador_module_css__WEBPACK_IMPORTED_MODULE_4__);





const BuscadorRes = ()=>{
    const { filtros , setFiltros , ocultarBottomNav , setOcultarBottomNav  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(context_map_MapContext__WEBPACK_IMPORTED_MODULE_2__/* .MapContext */ .X);
    const mostrarFiltros = ()=>setFiltros(!filtros)
    ;
    const ocultarNav = ()=>setOcultarBottomNav(!ocultarBottomNav)
    ;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "ps-5 pe-2 py-2",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                onClick: ocultarNav,
                className: `bi bi-chevron-left pointer ${(_Buscador_module_css__WEBPACK_IMPORTED_MODULE_4___default().leftArrow)}`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Buscador__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                onClick: mostrarFiltros,
                className: `${filtros ? (_Buscador_module_css__WEBPACK_IMPORTED_MODULE_4___default().filterIconActive) : (_Buscador_module_css__WEBPACK_IMPORTED_MODULE_4___default().filterIcon)} bi bi-sliders pointer`
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BuscadorRes);


/***/ }),

/***/ 9348:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Footer_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2566);
/* harmony import */ var _Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_Footer_module_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _authmodal_AuthModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4078);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1165);







const Footer = ()=>{
    const { auth , abrirRegistro , cerrarRegistro , mostrarRegistro , setMostrarRegistro ,  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_5__/* .AuthContext */ .V);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const goToHome = ()=>router.push("/")
    ;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
        className: `text-center text-lg-start text-muted ${(_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerStyle)}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: "d-flex justify-content-center justify-content-lg-between p-4",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "me-5 d-none d-lg-block"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().mbExtend),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container text-center text-md-start mt-5",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row mt-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-sm-12 col-md-6 p-4 col-xl-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                        className: "text-uppercase mb-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            onClick: goToHome,
                                            className: "pointer",
                                            src: "/images/logos/red1a1-blanco.png"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerContent),
                                        children: "Red 1a1 es la soluci\xf3n para asesores independientes e inmobiliarias que permite la comunicaci\xf3n y el intercambio de carteras de clientes y propiedades. A trav\xe9s de esta herramienta vers\xe1til podr\xe1s agregar, buscar y compartir propiedades."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-sm-12 col-md-6 p-4 col-xl-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                        className: "fw-bold text-white mb-4",
                                        children: "Secciones"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                        href: "/nosotros",
                                        scroll: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: `${(_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerLink)} pointer`,
                                            children: "Nosotros"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                        href: "/paquetes",
                                        scroll: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: `${(_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerLink)} pointer`,
                                            children: "Paquetes"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                        href: "/contacto",
                                        scroll: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: `${(_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerLink)} pointer`,
                                            children: "Cont\xe1ctanos"
                                        })
                                    }),
                                    !auth.logged ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        onClick: abrirRegistro,
                                        className: `${(_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerLink)} pointer`,
                                        children: "Registro"
                                    }) : null
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-sm-12 col-md-6 p-4 col-xl-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                        className: "fw-bold text-white mb-4",
                                        children: "Nuestras Oficinas"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerContent),
                                        children: "Quer\xe9taro, M\xe9xico. C.P. 76230"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-sm-12 col-md-6 p-4 col-xl-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                        className: "fw-bold text-white mb-4",
                                        children: "Tel\xe9fono"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerContent),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerPhone),
                                            children: "442 543 9190"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: "me-2",
                                        href: "https://es-la.facebook.com/red1a1",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "/images/icons/facebook.png",
                                            alt: "S\xedguenos en facebook"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "https://wa.link/8udscw",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "/images/icons/whatsapp.png",
                                            alt: "Comun\xedcate por whatsapp"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                        href: "/terminos-y-condiciones",
                                        scroll: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: `${(_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerLink)} pointer`,
                                            children: "T\xe9rminos y condiciones"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                        href: "/aviso-de-privacidad",
                                        scroll: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: `${(_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerLink)} pointer`,
                                            children: "Aviso de privacidad"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "text-center p-4",
                style: {
                    backgroundColor: "rgba(0, 0, 0, 0.05)"
                },
                children: [
                    "Copyright \xa9 ",
                    new Date().getFullYear(),
                    ":",
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                        href: "/",
                        scroll: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-reset fw-bold pointer",
                            style: {
                                textDecoration: "none"
                            },
                            children: "Red 1a1"
                        })
                    }),
                    ". Todos los derechos reservados."
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_authmodal_AuthModal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 1198:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var gsap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4287);
/* harmony import */ var gsap__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(gsap__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7924);
/* harmony import */ var _Header_module_css__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8716);
/* harmony import */ var _Header_module_css__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_Header_module_css__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _authmodal_LoginModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1672);
/* harmony import */ var _authmodal_AuthModal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4078);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1165);
/* harmony import */ var _paginas_perfil_chats_MisChats__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1565);
/* harmony import */ var context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1810);
/* harmony import */ var hooks_useSolicitudes__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9340);
/* harmony import */ var _MenuUsuario__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1109);
/* harmony import */ var _Notificaciones__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4102);
/* harmony import */ var context_chat_ChatContext__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1458);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_10__]);
context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_10__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
















// interface Notificacion {
//   de: string;
//   para: string;
//   nombre: string;
//   apellido: string;
//   mensaje: string;
// }
const Header = ()=>{
    const { auth , abrirRegistro , abrirLogin  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_8__/* .AuthContext */ .V);
    const { showCanvas , handleCloseCanvas , handleShowCanvas  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(context_chat_ChatContext__WEBPACK_IMPORTED_MODULE_14__/* .ChatContext */ .p5);
    const { socket  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_10__/* .SocketContext */ .J);
    const { 0: mostrarMenu , 1: setMostrarMenu  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const target = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { 0: notificaciones , 1: setNotificaciones  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: contador , 1: setContador  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { solicitudes , cargando , setSolicitudes  } = (0,hooks_useSolicitudes__WEBPACK_IMPORTED_MODULE_11__/* .useSolicitudes */ .R)(auth.uid);
    const notificacionRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    // const [nuevaNotificacion, setNuevaNotificacion] = useState<Notificacion[]>(
    //   []
    // );
    // const uniqueValues = new Set();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        socket === null || socket === void 0 ? void 0 : socket.on("obtener-solicitud", (solicitud)=>{
            setSolicitudes([
                ...solicitudes,
                solicitud
            ]);
            setContador(solicitudes.length + 1);
            const tl = gsap__WEBPACK_IMPORTED_MODULE_4__.gsap.timeline();
            tl.to(notificacionRef.current, {
                y: -5,
                duration: 0.2,
                ease: "ease.out"
            }).to(notificacionRef.current, {
                y: 0,
                duration: 0.2,
                ease: "bounce.out"
            });
        });
    }, [
        socket
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setContador(solicitudes.length);
    }, [
        solicitudes.length
    ]);
    // useEffect(() => {
    //   socket?.on("obtener-notificacion", (notificacion) => {
    //     console.log(notificacion, "sa");
    //     setNuevaNotificacion((noti) => [...noti, notificacion]);
    //   });
    // }, []);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Navbar, {
        className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_15___default().navStyle),
        bg: "light",
        expand: "sm",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Container, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "my-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "/images/logos/red1-color.png",
                                alt: "Red 1 a 1",
                                className: "pointer"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Navbar.Toggle, {
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Navbar.Collapse, {
                        children: !auth.logged ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Nav, {
                            className: "ms-auto my-2",
                            navbarScroll: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    onClick: abrirRegistro,
                                    className: `${(_Header_module_css__WEBPACK_IMPORTED_MODULE_15___default().navEnlace)} pointer ms-3`,
                                    children: "Reg\xedstrate"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    titulo: "Inicia sesi\xf3n",
                                    onClick: abrirLogin
                                })
                            ]
                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Nav, {
                            className: "ms-auto my-2",
                            navbarScroll: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "my-1",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        titulo: "chats",
                                        onClick: handleShowCanvas
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_MenuUsuario__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                    setMostrarMenu: setMostrarMenu,
                                    target: target,
                                    setNotificaciones: setNotificaciones,
                                    mostrarMenu: mostrarMenu
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Notificaciones__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                    notificaciones: notificaciones,
                                    setNotificaciones: setNotificaciones,
                                    target: target,
                                    cargando: cargando,
                                    solicitudes: solicitudes,
                                    setSolicitudes: setSolicitudes,
                                    contador: contador,
                                    setContador: setContador,
                                    notificacionRef: notificacionRef
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_authmodal_LoginModal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_authmodal_AuthModal__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_paginas_perfil_chats_MisChats__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                showCanvas: showCanvas,
                handleCloseCanvas: handleCloseCanvas
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

});

/***/ }),

/***/ 1109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1165);
/* harmony import */ var _Header_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8716);
/* harmony import */ var _Header_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_Header_module_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var context_chat_ChatContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1458);







const MenuUsuario = (props1)=>{
    const { setMostrarMenu , target , setNotificaciones , mostrarMenu  } = props1;
    const { auth , logOut  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_4__/* .AuthContext */ .V);
    const { chatState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(context_chat_ChatContext__WEBPACK_IMPORTED_MODULE_5__/* .ChatContext */ .p5);
    const cerrarSesion = ()=>{
        logOut();
        setMostrarMenu(false);
        setNotificaciones(false);
        chatState.chatActivo = null;
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${(_Header_module_css__WEBPACK_IMPORTED_MODULE_6___default().navPerfil)} pointer ms-3`,
                ref: target,
                onClick: ()=>setMostrarMenu(!mostrarMenu)
                ,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: auth.img,
                    alt: "Mi perfil",
                    style: {
                        width: 50,
                        height: 50,
                        borderRadius: "50%"
                    }
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Overlay, {
                target: target.current,
                show: mostrarMenu,
                placement: "right",
                children: ({ placement , arrowProps , show: _show , popper , ...props })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_6___default().menu),
                        ...props,
                        style: {
                            ...props.style
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `${(_Header_module_css__WEBPACK_IMPORTED_MODULE_6___default().menuItem)} pointer mx-3 my-2`,
                                    onClick: ()=>{
                                        setMostrarMenu(false);
                                    },
                                    children: "Mi Perfil"
                                })
                            }),
                            auth.role === "Individual" || auth.role === "Usuario" || auth.role === "UsuarioPagado" ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil/mis-usuarios",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `${(_Header_module_css__WEBPACK_IMPORTED_MODULE_6___default().menuItem)} pointer mx-3 my-2`,
                                    onClick: ()=>{
                                        setMostrarMenu(false);
                                    },
                                    children: "Mis Usuarios"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil/mis-paquetes",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `${(_Header_module_css__WEBPACK_IMPORTED_MODULE_6___default().menuItem)} pointer mx-3 my-2`,
                                    onClick: ()=>{
                                        setMostrarMenu(false);
                                    },
                                    children: "Mis Paquetes"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil/historial-de-pagos",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `${(_Header_module_css__WEBPACK_IMPORTED_MODULE_6___default().menuItem)} pointer mx-3 my-2`,
                                    onClick: ()=>{
                                        setMostrarMenu(false);
                                    },
                                    children: "Mis Pagos"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil/referencias-de-pago",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `${(_Header_module_css__WEBPACK_IMPORTED_MODULE_6___default().menuItem)} pointer mx-3 my-2`,
                                    onClick: ()=>{
                                        setMostrarMenu(false);
                                    },
                                    children: "Referencias"
                                })
                            }),
                            auth.role === "Administrador" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/dashboard",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `${(_Header_module_css__WEBPACK_IMPORTED_MODULE_6___default().menuItem)} pointer mx-3 my-2`,
                                    onClick: ()=>{
                                        setMostrarMenu(false);
                                    },
                                    children: "Dashboard"
                                })
                            }) : null,
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: `${(_Header_module_css__WEBPACK_IMPORTED_MODULE_6___default().menuCerrar)} pointer mx-3 my-2`,
                                onClick: cerrarSesion,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "bi bi-box-arrow-right"
                                    }),
                                    " Cerrar sesi\xf3n"
                                ]
                            })
                        ]
                    })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MenuUsuario);


/***/ }),

/***/ 4102:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ header_Notificaciones)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: ./src/helpers/fetch.tsx
var helpers_fetch = __webpack_require__(22);
// EXTERNAL MODULE: ./src/context/auth/AuthContext.tsx
var AuthContext = __webpack_require__(1165);
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
// EXTERNAL MODULE: ./src/components/ui/loading/Loading.tsx
var Loading = __webpack_require__(6220);
// EXTERNAL MODULE: ./src/components/ui/header/Header.module.css
var Header_module = __webpack_require__(8716);
var Header_module_default = /*#__PURE__*/__webpack_require__.n(Header_module);
;// CONCATENATED MODULE: ./src/components/ui/header/NotificacionItem.tsx




const NotificacionItem = (props1)=>{
    const { target , cargando , solicitudes , notificaciones , goToProperty , aprobarSolicitud , rechazarSolicitud , goToSolicitudes ,  } = props1;
    return(/*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Overlay, {
        target: target.current,
        show: notificaciones,
        placement: "right",
        children: ({ placement , arrowProps , show: _show , popper , ...props })=>{
            return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Header_module_default()).notificaciones,
                ...props,
                style: {
                    ...props.style
                },
                children: cargando ? /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {
                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        solicitudes.length === 0 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-center py-5",
                            style: {
                                color: "#7A7A7A",
                                fontWeight: "500"
                            },
                            children: "A\xfan no tiene notificaciones"
                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Header_module_default()).headerNotif,
                                    children: "Notificaciones"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Header_module_default()).notContainer,
                                    children: solicitudes === null || solicitudes === void 0 ? void 0 : solicitudes.map((solicitud)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: solicitud.estado === "Pendiente" ? (Header_module_default()).pendiente : (Header_module_default()).noPendiente,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (Header_module_default()).notificacionContainer,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("table", {
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                    valign: "middle",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: `${(Header_module_default()).notifImg}`,
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                            src: solicitud.usuario.img ? solicitud.usuario.img : "",
                                                                            alt: solicitud.usuario.nombre,
                                                                            style: {
                                                                                borderRadius: "50%",
                                                                                width: "100%"
                                                                            }
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                                    children: [
                                                                        solicitud.estado === "Pendiente" ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("b", {
                                                                                    children: [
                                                                                        solicitud.nombre ? solicitud.nombre : solicitud.usuario.nombre,
                                                                                        " ",
                                                                                        solicitud.apellido ? solicitud.apellido : solicitud.usuario.apellido,
                                                                                        " "
                                                                                    ]
                                                                                }),
                                                                                "quiere que le compartas este inmueble:",
                                                                                " "
                                                                            ]
                                                                        }) : solicitud.estado === "Aprobado" ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                            children: [
                                                                                "Haz aceptado la solicitud de",
                                                                                " ",
                                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("b", {
                                                                                    children: [
                                                                                        solicitud.nombre ? solicitud.nombre : solicitud.usuario.nombre,
                                                                                        " ",
                                                                                        solicitud.apellido ? solicitud.apellido : solicitud.usuario.apellido,
                                                                                        ". "
                                                                                    ]
                                                                                }),
                                                                                "Ahora pueda compartir",
                                                                                " "
                                                                            ]
                                                                        }) : solicitud.estado === "Rechazado" ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                            children: [
                                                                                "Haz rechazado la solicitud de",
                                                                                " ",
                                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("b", {
                                                                                    children: [
                                                                                        solicitud.nombre ? solicitud.nombre : solicitud.usuario.nombre,
                                                                                        " ",
                                                                                        solicitud.apellido ? solicitud.apellido : solicitud.usuario.apellido,
                                                                                        ". "
                                                                                    ]
                                                                                }),
                                                                                "Inmueble rechazado:",
                                                                                " "
                                                                            ]
                                                                        }) : "Error. Jam\xe1s debe de llegar a esta punto",
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            className: `${(Header_module_default()).propH} pointer`,
                                                                            onClick: ()=>goToProperty(solicitud.slug ? solicitud.slug : solicitud.inmueble.slug)
                                                                            ,
                                                                            children: solicitud.titulo ? solicitud.titulo : solicitud.inmueble ? solicitud.inmueble.titulo : ''
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    solicitud.estado === "Pendiente" ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "d-flex justify-content-center mt-2",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                                onClick: ()=>aprobarSolicitud(solicitud._id, solicitud.inmueble.titulo, solicitud.inmueble ? solicitud.inmueble.imgs[0] : "", solicitud.usuario.correo)
                                                                ,
                                                                className: `${(Header_module_default()).btnApprove} me-2`,
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: `${(Header_module_default()).iconNoti} bi bi-check-circle`
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                                onClick: ()=>rechazarSolicitud(solicitud._id, solicitud.inmueble.titulo, solicitud.inmueble ? solicitud.inmueble.imgs[0] : "", solicitud.usuario.correo)
                                                                ,
                                                                className: `${(Header_module_default()).btnReject} me-2`,
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: `${(Header_module_default()).iconNoti} bi bi-x-circle`
                                                                })
                                                            })
                                                        ]
                                                    }) : null
                                                ]
                                            })
                                        }, solicitud._id)
                                    )
                                })
                            ]
                        }),
                        solicitudes.length === 0 ? null : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "d-flex justify-content-center py-2",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `${(Header_module_default()).footVer} pointer`,
                                onClick: goToSolicitudes,
                                children: "Ver todas las solicitudes"
                            })
                        })
                    ]
                })
            }));
        }
    }));
};
/* harmony default export */ const header_NotificacionItem = (NotificacionItem);

// EXTERNAL MODULE: ./src/credentials/credentials.tsx
var credentials = __webpack_require__(6681);
;// CONCATENATED MODULE: ./src/components/ui/header/Notificaciones.tsx








const Notificaciones = (props)=>{
    const { notificaciones , setNotificaciones , target , cargando , solicitudes , contador , setContador , notificacionRef , setSolicitudes ,  } = props;
    const { auth  } = (0,external_react_.useContext)(AuthContext/* AuthContext */.V);
    const router = (0,router_.useRouter)();
    const goToProperty = (slug)=>router.push(`propiedades/${slug}`)
    ;
    const mostrarNotificaciones = ()=>{
        setNotificaciones(!notificaciones);
    };
    const goToSolicitudes = ()=>{
        router.push("/perfil/propiedades-compartidas");
        setNotificaciones(false);
    };
    const aprobarSolicitud = async (id, titulo, img, correo)=>{
        const aprobacion = {
            estado: "Aprobado"
        };
        const res = await (0,helpers_fetch/* fetchAceptarRechazarSolicitud */.iT)(`solicitud/aceptar/${id}`, aprobacion);
        const body = {
            nombre: auth.nombre,
            apellido: auth.apellido,
            titulo,
            img,
            correo
        };
        if (res.ok) {
            await fetch(`${credentials/* production */.C7}/correos/solicitud-aprobada`, {
                method: "POST",
                headers: {
                    "Content-type": "application/json"
                },
                body: JSON.stringify(body)
            });
            const solicitudAprobada = solicitudes === null || solicitudes === void 0 ? void 0 : solicitudes.map((solicitud)=>{
                if (solicitud._id === id) {
                    return {
                        ...solicitud,
                        estado: "Aprobado"
                    };
                }
                return solicitud;
            });
            setSolicitudes(solicitudAprobada);
            setContador((prev)=>prev - 1
            );
            external_react_toastify_.toast.success(res.msg);
        }
    };
    const rechazarSolicitud = async (id, titulo, img, correo)=>{
        const rechazo = {
            estado: "Rechazado"
        };
        const body = {
            nombre: auth.nombre,
            apellido: auth.apellido,
            titulo,
            img,
            correo
        };
        const res = await (0,helpers_fetch/* fetchAceptarRechazarSolicitud */.iT)(`solicitud/rechazar/${id}`, rechazo);
        if (res.ok) {
            await fetch(`${credentials/* production */.C7}/correos/solicitud-rechazada`, {
                method: "POST",
                headers: {
                    "Content-type": "application/json"
                },
                body: JSON.stringify(body)
            });
            const solicitudRechazada = solicitudes === null || solicitudes === void 0 ? void 0 : solicitudes.map((solicitud)=>{
                if (solicitud._id === id) {
                    return {
                        ...solicitud,
                        estado: "Rechazado"
                    };
                }
                return solicitud;
            });
            setContador((prev)=>prev - 1
            );
            setSolicitudes(solicitudRechazada);
            external_react_toastify_.toast.success(res.msg);
        }
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "text-center",
                ref: notificacionRef,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "ms-3",
                        onClick: mostrarNotificaciones,
                        style: {
                            border: "2.5px solid #7149bc",
                            borderRadius: "50%",
                            padding: "0px 6px",
                            boxSizing: "border-box",
                            marginTop: "12px",
                            width: "38px"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            style: {
                                fontSize: "20px",
                                color: "#7149BC"
                            },
                            className: "bi bi-bell-fill pointer"
                        })
                    }),
                    contador > 0 ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        style: {
                            position: "absolute",
                            top: 30,
                            marginLeft: 22,
                            color: "#fff",
                            fontSize: 8
                        },
                        className: "px-2 py-1 translate-middle p-2 bg-danger border border-light rounded-circle",
                        children: contador
                    }) : null
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(header_NotificacionItem, {
                target: target,
                cargando: cargando,
                solicitudes: solicitudes,
                notificaciones: notificaciones,
                goToProperty: goToProperty,
                aprobarSolicitud: aprobarSolicitud,
                rechazarSolicitud: rechazarSolicitud,
                goToSolicitudes: goToSolicitudes
            })
        ]
    }));
};
/* harmony default export */ const header_Notificaciones = (Notificaciones);


/***/ }),

/***/ 3091:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var _Header_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8716);
/* harmony import */ var _Header_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_Header_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1165);
/* harmony import */ var _authmodal_LoginModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1672);






const ResponsiveHeader = ()=>{
    const { auth , abrirLogin , abrirRegistro  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__/* .AuthContext */ .V);
    const { 0: mostrar , 1: setMostrar  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const cerrarMenu = ()=>setMostrar(true)
    ;
    const openLogin = ()=>{
        cerrarMenu();
        abrirLogin();
    };
    const openRegister = ()=>{
        cerrarMenu();
        abrirRegistro();
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_5___default().respNavbar),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    onClick: ()=>setMostrar(!mostrar)
                    ,
                    className: `${(_Header_module_css__WEBPACK_IMPORTED_MODULE_5___default().listIcon)}  ${mostrar ? "bi bi-list" : "bi bi-x-lg"}`
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `container my-2 d-flex ${mostrar ? "justify-content-center" : "justify-content-end"}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                    href: "/",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/images/logos/red1-color.png",
                        alt: "Red 1 a 1",
                        className: "pointer",
                        onClick: cerrarMenu
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${mostrar ? (_Header_module_css__WEBPACK_IMPORTED_MODULE_5___default().resHeader) : (_Header_module_css__WEBPACK_IMPORTED_MODULE_5___default().resHeaderAtive)}`,
                children: !auth.logged ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_5___default().headerLinkItem),
                            onClick: openRegister,
                            children: "Reg\xedstrate"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_5___default().headerLinkItem),
                            onClick: openLogin,
                            children: "Inicia sesi\xf3n"
                        })
                    ]
                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            onClick: cerrarMenu,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil/mis-propiedades",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_5___default().headerLinkItem),
                                    children: "Mis propiedades"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            onClick: cerrarMenu,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil/mis-favoritos",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_5___default().headerLinkItem),
                                    children: "Mis favoritos"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            onClick: cerrarMenu,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_5___default().headerLinkItem),
                                    children: "Mi cuenta"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            onClick: cerrarMenu,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil/propiedades-compartidas",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_5___default().headerLinkItem),
                                    children: "Propiedades compartidas"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            onClick: cerrarMenu,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil/historial-de-inmueble",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_5___default().headerLinkItem),
                                    children: "Historial de inmueble"
                                })
                            })
                        }),
                        auth.role === "Individual" || auth.role === "Usuario" || auth.role === "UsuarioPagado" ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            onClick: cerrarMenu,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil/mis-usuarios",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_5___default().headerLinkItem),
                                    children: "Mis Usuarios"
                                })
                            })
                        }),
                        auth.role === "Administrador" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            onClick: cerrarMenu,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/dashboard",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_5___default().headerLinkItem),
                                    children: "Dashboard"
                                })
                            })
                        }) : null
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_authmodal_LoginModal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ResponsiveHeader);


/***/ }),

/***/ 3038:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var context_map_MapContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1131);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1165);
/* harmony import */ var _buscador_Buscador__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2059);
/* harmony import */ var _PurpleHeader_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7410);
/* harmony import */ var _PurpleHeader_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_PurpleHeader_module_css__WEBPACK_IMPORTED_MODULE_6__);







const PurpleHeader = ()=>{
    const { auth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_4__/* .AuthContext */ .V);
    const { setFiltros , filtros  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(context_map_MapContext__WEBPACK_IMPORTED_MODULE_3__/* .MapContext */ .X);
    const mostrarFiltros = ()=>setFiltros(!filtros)
    ;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_PurpleHeader_module_css__WEBPACK_IMPORTED_MODULE_6___default().purpleNav2),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
            className: "nav d-flex justify-content-center",
            children: [
                auth.uid ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "nav-item mt-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil/mis-propiedades",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `${(_PurpleHeader_module_css__WEBPACK_IMPORTED_MODULE_6___default().purpleLinks)} mx-3 pointer`,
                                    children: "Mis Propiedades"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "nav-item mt-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil/mis-favoritos",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `${(_PurpleHeader_module_css__WEBPACK_IMPORTED_MODULE_6___default().purpleLinks)} mx-3 pointer`,
                                    children: "Mis Favoritos"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "nav-item mt-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `${(_PurpleHeader_module_css__WEBPACK_IMPORTED_MODULE_6___default().purpleLinks)} mx-3 pointer`,
                                    children: "Mi Cuenta"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "nav-item mt-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil/propiedades-compartidas",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `${(_PurpleHeader_module_css__WEBPACK_IMPORTED_MODULE_6___default().purpleLinks)} mx-3 pointer`,
                                    children: "Propiedades compartidas"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "nav-item mt-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/perfil/historial-de-inmueble",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `${(_PurpleHeader_module_css__WEBPACK_IMPORTED_MODULE_6___default().purpleLinks)} mx-3 pointer`,
                                    children: "Historial de Inmuebles"
                                })
                            })
                        })
                    ]
                }) : null,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    className: "nav-item",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_PurpleHeader_module_css__WEBPACK_IMPORTED_MODULE_6___default().filterIconContainer),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_buscador_Buscador__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                onClick: mostrarFiltros,
                                className: `${filtros ? (_PurpleHeader_module_css__WEBPACK_IMPORTED_MODULE_6___default().filterIconActive) : (_PurpleHeader_module_css__WEBPACK_IMPORTED_MODULE_6___default().filterIcon)} bi bi-sliders pointer`
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: (_PurpleHeader_module_css__WEBPACK_IMPORTED_MODULE_6___default().searchBtn),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                            className: "bi bi-search"
                        })
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PurpleHeader);


/***/ }),

/***/ 7729:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var context_chat_ChatContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1458);
/* harmony import */ var _ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1130);
/* harmony import */ var _ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_4__);





const BottomNavBar = ()=>{
    const { pathname , push  } = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { showCanvas , setShowCanvas , handleCloseCanvas  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(context_chat_ChatContext__WEBPACK_IMPORTED_MODULE_3__/* .ChatContext */ .p5);
    const goToHome = ()=>push("/")
    ;
    const goToProfile = ()=>push("/perfil")
    ;
    const goToNot = ()=>push("/perfil/solicitudes")
    ;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_4___default().whiteBBar)}`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "row g-0",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col text-center py-3",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_4___default().btnContainer)} py-2`,
                        children: pathname === "/" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_4___default().whiteBBarImg)} pointer`,
                            src: "/images/icons/whitebar-icon-orange-1.png",
                            alt: "..."
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            onClick: goToHome,
                            className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_4___default().whiteBBarImg)} pointer`,
                            src: "/images/icons/whitebar-icon-purple-1.png",
                            alt: "Inicio"
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col text-center py-3",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_4___default().btnContainer)} py-2`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            onClick: ()=>{
                                setShowCanvas(!showCanvas);
                            },
                            className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_4___default().whiteBBarImg)} pointer`,
                            src: "/images/icons/whitebar-icon-purple-2.png",
                            alt: "..."
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col text-center py-3",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_4___default().btnContainer)} py-2`,
                        children: pathname === "/perfil/solicitudes" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_4___default().whiteBBarImg)} pointer`,
                            src: "/images/icons/whitebar-icon-orange-3.png",
                            alt: "..."
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            onClick: goToNot,
                            className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_4___default().whiteBBarImg)} pointer`,
                            src: "/images/icons/whitebar-icon-purple-3.png",
                            alt: "..."
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col text-center py-2",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "py-3",
                        children: pathname === "/perfil" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_4___default().whiteBBarImg)} pointer`,
                            src: "/images/icons/whitebar-icon-orange-4.png",
                            alt: "..."
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            onClick: goToProfile,
                            className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_4___default().whiteBBarImg)} pointer`,
                            src: "/images/icons/whitebar-icon-purple-4.png",
                            alt: "..."
                        })
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BottomNavBar);


/***/ }),

/***/ 9340:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ useSolicitudes)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var credentials_credentials__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6681);


const useSolicitudes = (uid)=>{
    const { 0: solicitudes , 1: setSolicitudes  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const { 0: total , 1: setTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const obtenerSolicitudes = async ()=>{
        if (!uid) return;
        if (uid) {
            try {
                const res = await fetch(`${credentials_credentials__WEBPACK_IMPORTED_MODULE_1__/* .production */ .C7}/solicitud/${uid}`);
                const data = await res.json();
                setTotal(data.total);
                setSolicitudes(data.solicitudes);
                setCargando(false);
            } catch (error) {
                console.log(error);
            }
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerSolicitudes();
    }, [
        uid
    ]);
    return {
        solicitudes,
        cargando,
        setSolicitudes,
        total
    };
};


/***/ }),

/***/ 2957:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8890);
/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(nextjs_progressbar__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var moment_locale_es__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8678);
/* harmony import */ var moment_locale_es__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment_locale_es__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1165);
/* harmony import */ var _components_layout_Layout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6323);
/* harmony import */ var _context_inmuebles_InmuebleContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4549);
/* harmony import */ var _context_map_MapContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1131);
/* harmony import */ var _context_chat_ChatContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1458);
/* harmony import */ var _context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1810);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout_Layout__WEBPACK_IMPORTED_MODULE_5__, _context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_9__]);
([_components_layout_Layout__WEBPACK_IMPORTED_MODULE_5__, _context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);












moment__WEBPACK_IMPORTED_MODULE_2___default().locale('es');
function MyApp({ Component , pageProps  }) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_4__/* .AuthProvider */ .H, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_chat_ChatContext__WEBPACK_IMPORTED_MODULE_8__/* .ChatProvider */ .aM, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_9__/* .SocketProvider */ .w, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((nextjs_progressbar__WEBPACK_IMPORTED_MODULE_1___default()), {
                        height: 6,
                        color: "#7149BC",
                        options: {
                            showSpinner: false
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_map_MapContext__WEBPACK_IMPORTED_MODULE_7__/* .MapProvider */ .I, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_Layout__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_inmuebles_InmuebleContext__WEBPACK_IMPORTED_MODULE_6__/* .InmuebleProvider */ .K, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                                    ...pageProps
                                })
                            })
                        })
                    })
                ]
            })
        })
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

});

/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 4287:
/***/ ((module) => {

"use strict";
module.exports = require("gsap");

/***/ }),

/***/ 3696:
/***/ ((module) => {

"use strict";
module.exports = require("linkifyjs");

/***/ }),

/***/ 2245:
/***/ ((module) => {

"use strict";
module.exports = require("moment");

/***/ }),

/***/ 8678:
/***/ ((module) => {

"use strict";
module.exports = require("moment/locale/es");

/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 8890:
/***/ ((module) => {

"use strict";
module.exports = require("nextjs-progressbar");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap");

/***/ }),

/***/ 8580:
/***/ ((module) => {

"use strict";
module.exports = require("react-geosuggest");

/***/ }),

/***/ 67:
/***/ ((module) => {

"use strict";
module.exports = require("react-google-login");

/***/ }),

/***/ 1187:
/***/ ((module) => {

"use strict";
module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4612:
/***/ ((module) => {

"use strict";
module.exports = import("socket.io-client");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7730,1664,22,1165,6220,7924,4549,1131,9227,1458,7184,4986,1810], () => (__webpack_exec__(2957)));
module.exports = __webpack_exports__;

})();