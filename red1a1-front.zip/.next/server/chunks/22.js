"use strict";
exports.id = 22;
exports.ids = [22];
exports.modules = {

/***/ 6681:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C7": () => (/* binding */ production),
/* harmony export */   "GJ": () => (/* binding */ rentas),
/* harmony export */   "DJ": () => (/* binding */ ventas),
/* harmony export */   "bF": () => (/* binding */ casasC),
/* harmony export */   "ay": () => (/* binding */ departamentosCat),
/* harmony export */   "Bd": () => (/* binding */ desarrollosCat),
/* harmony export */   "qn": () => (/* binding */ localesCat),
/* harmony export */   "iS": () => (/* binding */ oficinasCat),
/* harmony export */   "A9": () => (/* binding */ bodegasCat),
/* harmony export */   "eq": () => (/* binding */ googleClientId),
/* harmony export */   "tB": () => (/* binding */ stripePublicId)
/* harmony export */ });
/* unused harmony export development */
const production = "https://red1a1-back.herokuapp.com/api";
const development = "http://localhost:8080/api";
const rentas = "61e99f0e0d3bd9163e4a4b42";
const ventas = "61e99f120d3bd9163e4a4b46";
const casasC = "61e99edd0d3bd9163e4a4b3a";
const departamentosCat = "61e99ee80d3bd9163e4a4b3e";
const desarrollosCat = "6213cb350d7c145fa7ae62ac";
const localesCat = "6213cb3c0d7c145fa7ae62b0";
const oficinasCat = "6213cb430d7c145fa7ae62b4";
const bodegasCat = "6213cb480d7c145fa7ae62b8";
const googleClientId = "670476434432-m4i4b7hvrlds0lunt1k3tbes8983p6i2.apps.googleusercontent.com";
const stripePublicId = "pk_test_51KlHyqITJUOVXM1TTiuTj9Nbl5UjpkOdn4j3nl42D64lUaV9TnNkMgCPMaSzPJm68LtLmLTPiC2O8ZOKbEWncRs100hxibM6CC";


/***/ }),

/***/ 22:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L8": () => (/* binding */ fetchSinToken),
/* harmony export */   "u9": () => (/* binding */ googleLogin),
/* harmony export */   "bf": () => (/* binding */ crearUsuarioFetch),
/* harmony export */   "Z_": () => (/* binding */ fetchConToken),
/* harmony export */   "lI": () => (/* binding */ fetchContactForm),
/* harmony export */   "ol": () => (/* binding */ fetchSolicitud),
/* harmony export */   "T": () => (/* binding */ fetchEnviarSolicitud),
/* harmony export */   "iT": () => (/* binding */ fetchAceptarRechazarSolicitud),
/* harmony export */   "Az": () => (/* binding */ nuevoPedido),
/* harmony export */   "xh": () => (/* binding */ nuevoPedidoAdmin),
/* harmony export */   "oi": () => (/* binding */ fetchInmueble),
/* harmony export */   "dW": () => (/* binding */ fetchActualizarInmueble),
/* harmony export */   "iE": () => (/* binding */ fetchBorrarInmueble),
/* harmony export */   "P5": () => (/* binding */ actualizarPerfilFetch),
/* harmony export */   "uW": () => (/* binding */ actualizarRolUsuario),
/* harmony export */   "o4": () => (/* binding */ agregarFav),
/* harmony export */   "Ie": () => (/* binding */ eliminarFavorito),
/* harmony export */   "Fl": () => (/* binding */ agregarHist),
/* harmony export */   "I": () => (/* binding */ eliminarHist),
/* harmony export */   "ec": () => (/* binding */ subirFotoPerfil),
/* harmony export */   "pg": () => (/* binding */ subirComprobanteFetch),
/* harmony export */   "Fy": () => (/* binding */ subirFotosInmueble),
/* harmony export */   "Xo": () => (/* binding */ obtenerMensajes),
/* harmony export */   "kP": () => (/* binding */ crearChat),
/* harmony export */   "tU": () => (/* binding */ anadirPaqueteInv),
/* harmony export */   "Np": () => (/* binding */ generarRefInd),
/* harmony export */   "Sd": () => (/* binding */ generarRefMul),
/* harmony export */   "Si": () => (/* binding */ aprobarRef)
/* harmony export */ });
/* unused harmony exports enviarNuevoMensaje, agregarUsuario */
/* harmony import */ var _credentials_credentials__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6681);

const baseURL = _credentials_credentials__WEBPACK_IMPORTED_MODULE_0__/* .production */ .C7;
const devURL = (/* unused pure expression or super */ null && (development));
const fetchSinToken = async (endpoint, data, method = "GET")=>{
    const url = `${baseURL}/${endpoint}`;
    if (method === "GET") {
        const resp = await fetch(url);
        return await resp.json();
    } else {
        const resp = await fetch(url, {
            method,
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(data)
        });
        return await resp.json();
    }
};
const googleLogin = async (endpoint, body)=>{
    const url = `${baseURL}/${endpoint}`;
    const res = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(body)
    });
    const data = await res.json();
    return data;
};
const crearUsuarioFetch = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const fetchConToken = async (endpoint, data, method = "GET")=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    if (method === "GET") {
        const resp = await fetch(url, {
            headers: {
                "x-token": token
            }
        });
        return await resp.json();
    } else {
        const resp = await fetch(url, {
            method,
            headers: {
                "Content-type": "application/json",
                "x-token": token
            },
            body: JSON.stringify(data)
        });
        return await resp.json();
    }
};
const fetchContactForm = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const fetchSolicitud = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const fetchEnviarSolicitud = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const fetchAceptarRechazarSolicitud = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const res = await fetch(url, {
        method: "PUT",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await res.json();
};
const nuevoPedido = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const res = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(data)
    });
    return await res.json();
};
const nuevoPedidoAdmin = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const res = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(data)
    });
    return await res.json();
};
const fetchInmueble = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const fetchActualizarInmueble = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "PUT",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const fetchBorrarInmueble = async (endpoint, method = "DELETE")=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method,
        headers: {
            "Content-type": "application/json",
            "x-token": token
        }
    });
    return await resp.json();
};
const actualizarPerfilFetch = async (endpoint, data)=>{
    const url = `${_credentials_credentials__WEBPACK_IMPORTED_MODULE_0__/* .production */ .C7}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "PUT",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const actualizarRolUsuario = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "PUT",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const agregarFav = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const res = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await res.json();
};
const eliminarFavorito = async (endpoint)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const res = await fetch(url, {
        method: "DELETE",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        }
    });
    return await res.json();
};
const agregarHist = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const res = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await res.json();
};
const eliminarHist = async (endpoint)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const res = await fetch(url, {
        method: "DELETE",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        }
    });
    return await res.json();
};
const subirFotoPerfil = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "x-token": token
        },
        body: data
    });
    return await resp.json();
};
const subirComprobanteFetch = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "x-token": token
        },
        body: data
    });
    return await resp.json();
};
const subirFotosInmueble = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "x-token": token
        },
        body: data
    });
    return await resp.json();
};
const enviarNuevoMensaje = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const obtenerMensajes = async (endpoint)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        headers: {
            "x-token": token
        }
    });
    return await resp.json();
};
const crearChat = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const anadirPaqueteInv = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const agregarUsuario = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const generarRefInd = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const res = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await res.json();
};
const generarRefMul = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const res = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await res.json();
};
const aprobarRef = async (endpoint)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const res = await fetch(url, {
        method: "PUT",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify({
            estado: true
        })
    });
    return await res.json();
};


/***/ })

};
;