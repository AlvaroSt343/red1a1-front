"use strict";
exports.id = 4549;
exports.ids = [4549];
exports.modules = {

/***/ 4549:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ InmuebleContext),
/* harmony export */   "K": () => (/* binding */ InmuebleProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var helpers_fetch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(22);




const InmuebleContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
});
const InmuebleState = {
    titulo: undefined,
    categoria: undefined,
    precio: undefined,
    direccion: undefined,
    lat: undefined,
    lng: undefined,
    tipoPropiedad: undefined,
    descripcion: undefined,
    AA: undefined,
    agua: undefined,
    amueblado: undefined,
    antiguedad: undefined,
    baños: undefined,
    camas: undefined,
    closet: undefined,
    cocina: undefined,
    comedor: undefined,
    comisiones: undefined,
    discapacitados: undefined,
    escuelas: undefined,
    estufa: undefined,
    gas: undefined,
    habitaciones: undefined,
    horno: undefined,
    internet: undefined,
    lavadora: undefined,
    luz: undefined,
    m2Construidos: undefined,
    m2Terreno: undefined,
    mantenimiento: undefined,
    medioBaños: undefined,
    microondas: undefined,
    minihorno: undefined,
    otros: undefined,
    publicado: undefined,
    parking: undefined,
    piscinas: undefined,
    pisos: undefined,
    refrigerador: undefined,
    sala: undefined,
    secadora: undefined
};
const InmuebleProvider = ({ children  })=>{
    const { 0: orden , 1: setOrden  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("createdAt");
    const { 0: solicitud , 1: setSolicitud  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Pendiente");
    const { 0: editar , 1: setEditar  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: idInmueble , 1: setIdInmueble  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: inmuebleState , 1: setInmuebleState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(InmuebleState);
    const { 0: dueño , 1: setDueño  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: estado , 1: setEstado  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Aprobado");
    const { 0: misCompUser , 1: setMisCompUser  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const crearInmueble = async (data)=>{
        const resp = await (0,helpers_fetch__WEBPACK_IMPORTED_MODULE_3__/* .fetchInmueble */ .oi)("inmuebles", data);
        if (resp.ok) {
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.success(resp.msg);
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.success("Ahora agrega las im\xe1genes de tu inmueble");
        }
        if (resp.errors) {
            resp.errors.map((e)=>{
                return react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.error(e.msg);
            });
        }
        return resp;
    };
    const subirImagenesInmueble = async (data, uid, pid, endpoint = "")=>{
        const resp = await (0,helpers_fetch__WEBPACK_IMPORTED_MODULE_3__/* .subirFotosInmueble */ .Fy)(`subidas/${endpoint}${uid}/${pid}`, data);
        if (resp.ok) {
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.success(resp.msg);
        }
        if (!resp.ok) {
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.error("Hubo un error al momento de subir las im\xe1genes. Int\xe9ntelo nuevamente");
        }
        return resp;
    };
    const eliminarInmueble = async (id)=>{
        const resp = await (0,helpers_fetch__WEBPACK_IMPORTED_MODULE_3__/* .fetchBorrarInmueble */ .iE)(`inmuebles/${id}`);
        react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.success(resp.msg);
        return resp;
    };
    const actualizarInmueble = async (data, pid)=>{
        const resp = await (0,helpers_fetch__WEBPACK_IMPORTED_MODULE_3__/* .fetchActualizarInmueble */ .dW)(`inmuebles/${pid}`, data);
        if (resp.ok) {
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.success(resp.msg);
        }
        if (!resp.ok) {
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.error(resp.msg);
        }
        return resp;
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(InmuebleContext.Provider, {
        value: {
            crearInmueble,
            eliminarInmueble,
            subirImagenesInmueble,
            orden,
            setOrden,
            solicitud,
            setSolicitud,
            actualizarInmueble,
            editar,
            setEditar,
            idInmueble,
            setIdInmueble,
            inmuebleState,
            setInmuebleState,
            dueño,
            setDueño,
            estado,
            setEstado,
            misCompUser,
            setMisCompUser
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_2__.ToastContainer, {
            }),
            children
        ]
    }));
};


/***/ })

};
;