exports.id = 717;
exports.ids = [717];
exports.modules = {

/***/ 3320:
/***/ ((module) => {

// Exports
module.exports = {
	"stepLineActive1": "FormDesign_stepLineActive1__IYcds",
	"stepLineActive2": "FormDesign_stepLineActive2__aZ_cb",
	"stepLineActive3": "FormDesign_stepLineActive3__Ub7m0",
	"stepLineActive": "FormDesign_stepLineActive__rMEVO",
	"stepLineInactive": "FormDesign_stepLineInactive__n5fYb",
	"step1": "FormDesign_step1__slIJE",
	"step2": "FormDesign_step2__5VuT8",
	"step3": "FormDesign_step3__lP__i",
	"subTitulo": "FormDesign_subTitulo___re02",
	"MiniSub": "FormDesign_MiniSub__hnIAN",
	"line": "FormDesign_line__qxits",
	"content": "FormDesign_content__zmDtT",
	"labels": "FormDesign_labels__YUfqm",
	"labels2": "FormDesign_labels2__sku1V",
	"thumbsContainer": "FormDesign_thumbsContainer__RTNP6",
	"thumb": "FormDesign_thumb__9XzuO",
	"thumbInner": "FormDesign_thumbInner__yOdZL",
	"img": "FormDesign_img__8fzCP"
};


/***/ }),

/***/ 2044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _FormDesign_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3320);
/* harmony import */ var _FormDesign_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_1__);


const Steps = ({ steps , editar  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "col-sm-12 col-md-12 col-lg-8",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "col-12 my-4",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: steps === 1 ? (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_1___default().stepLineActive1) : steps === 2 ? editar ? (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_1___default().stepLineActive3) : (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_1___default().stepLineActive2) : steps === 3 ? (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_1___default().stepLineActive3) : ""
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_1___default().stepLineInactive)
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row d-flex justify-content-between text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_1___default().step1),
                                children: "1"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: steps === 2 ? (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_1___default().step1) : steps === 3 ? (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_1___default().step1) : (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_1___default().step2),
                                children: "2"
                            })
                        }),
                        !editar ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: steps === 3 ? (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_1___default().step1) : (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_1___default().step3),
                                children: "3"
                            })
                        }) : null
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Steps);


/***/ }),

/***/ 411:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ PrivateRoute)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1165);
/* harmony import */ var _components_ui_loading_Loading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6220);





const PrivateRoute = (Component)=>{
    return function RutaPrivada(props) {
        const { auth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__/* .AuthContext */ .V);
        const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
        if (!auth.logged) {
            (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
                router.replace("/");
            }, []);
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_loading_Loading__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            }));
        }
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
            auth: auth,
            ...props
        }));
    };
};


/***/ })

};
;