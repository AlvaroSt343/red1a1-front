"use strict";
exports.id = 9227;
exports.ids = [9227];
exports.modules = {

/***/ 9227:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Pc": () => (/* binding */ useUserInfo),
/* harmony export */   "TL": () => (/* binding */ useUserInmuebles),
/* harmony export */   "s8": () => (/* binding */ useHistorial),
/* harmony export */   "eV": () => (/* binding */ useHistorialPagos),
/* harmony export */   "ah": () => (/* binding */ useMisUsuarios),
/* harmony export */   "iV": () => (/* binding */ useUsuariosPorDir)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _context_inmuebles_InmuebleContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4549);
/* harmony import */ var _credentials_credentials__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6681);



const devURL = "http://localhost:8080/api";
const baseURL = "https://red1a1-back.herokuapp.com/api";
const useUserInfo = (uid)=>{
    const { 0: user , 1: setUser  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const getUserInfo = async ()=>{
        setLoading(true);
        const data = await fetch(baseURL + "/usuarios/" + uid);
        const resp = await data.json();
        setLoading(false);
        setUser(resp);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        getUserInfo();
    }, [
        uid
    ]);
    return {
        user,
        loading
    };
};
const useUserInmuebles = (uid, desde = 0)=>{
    const { 0: inmuebles , 1: setInmuebles  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const { 0: total , 1: setTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const { orden  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_context_inmuebles_InmuebleContext__WEBPACK_IMPORTED_MODULE_1__/* .InmuebleContext */ .q);
    const obtenerInmueblesDeUsuario = async ()=>{
        const data = await fetch(`${baseURL}/inmuebles/usuario/${uid}?orden=${orden}&limite=20&desde=${desde}`);
        const resp = await data.json();
        setInmuebles(resp.inmueblesUsuario);
        setCargando(false);
        setTotal(resp.total);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerInmueblesDeUsuario();
    }, [
        orden,
        desde,
        uid
    ]);
    return {
        inmuebles,
        cargando,
        total,
        setInmuebles
    };
};
const useHistorial = (uid, desde)=>{
    const { 0: historial , 1: setHistorial  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const { 0: isLoading , 1: setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const { 0: total , 1: setTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const obtenerHistorial = async ()=>{
        const resp = await fetch(`${baseURL}/historial/usuario/${uid}?desde=${desde}&limite=15`);
        const data = await resp.json();
        setHistorial(data.historialUsuario);
        setTotal(data.total);
        setIsLoading(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerHistorial();
    }, [
        desde,
        uid
    ]);
    return {
        historial,
        isLoading,
        setHistorial,
        total
    };
};
const useHistorialPagos = (uid, desde)=>{
    const { 0: historialPago , 1: setHistorialPago  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const { 0: total , 1: setTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const obtenerHistorialPagos = async ()=>{
        const resp = await fetch(`${_credentials_credentials__WEBPACK_IMPORTED_MODULE_2__/* .production */ .C7}/pedidos/usuarios/${uid}?desde=${desde}&limite=15`);
        const data = await resp.json();
        setTotal(data.total);
        setHistorialPago(data.pedidosUsuario);
        setCargando(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerHistorialPagos();
    }, [
        desde,
        uid
    ]);
    return {
        historialPago,
        cargando,
        total
    };
};
const useMisUsuarios = (uid)=>{
    // const [misUsuarios, setMisUsuarios] = useState<UsuariosPagado[]>([]);
    const { 0: misUsuarios , 1: setMisUsuarios  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const obtenerMisUsuarios = async ()=>{
        const res = await fetch(`${baseURL}/usuarios/propietario/${uid}`);
        const data = await res.json();
        setMisUsuarios(data.misUsuarios);
        setCargando(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerMisUsuarios();
    }, [
        uid
    ]);
    return {
        misUsuarios,
        cargando,
        setMisUsuarios
    };
};
const useUsuariosPorDir = (direccion)=>{
    const { 0: usuariosPorDir , 1: setUsuariosDir  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const obtenerUsuariosPorDir = async ()=>{
        const res = await fetch(`${_credentials_credentials__WEBPACK_IMPORTED_MODULE_2__/* .production */ .C7}/usuarios/usuario/ubicacion?direccion=${direccion}`);
        const data = await res.json();
        setUsuariosDir(data.usuarios);
        setCargando(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerUsuariosPorDir();
    }, [
        direccion
    ]);
    return {
        usuariosPorDir,
        cargando
    };
};


/***/ })

};
;