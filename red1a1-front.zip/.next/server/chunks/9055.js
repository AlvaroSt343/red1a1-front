"use strict";
exports.id = 9055;
exports.ids = [9055];
exports.modules = {

/***/ 9055:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1165);
/* harmony import */ var context_map_MapContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1131);
/* harmony import */ var helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7200);
/* harmony import */ var react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2807);
/* harmony import */ var react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1130);
/* harmony import */ var _ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var hooks_useInmuebles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8605);
/* harmony import */ var _loading_Loading__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6220);










const ListaPropResp = ()=>{
    const { auth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__/* .AuthContext */ .V);
    const { coordenadas , southEast , northWest , southWest , northEast , categoria , tipoPropiedad ,  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(context_map_MapContext__WEBPACK_IMPORTED_MODULE_4__/* .MapContext */ .X);
    const { 0: mostrarLista , 1: setMostrarLista  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { 0: limite , 1: setLimite  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(10);
    const { listaInmuebles , cargando  } = (0,hooks_useInmuebles__WEBPACK_IMPORTED_MODULE_7__/* .useListaInmuebleCoords */ .cN)(limite, southEast, northWest, southWest, northEast, coordenadas, categoria, tipoPropiedad);
    const mostrarListaF = ()=>setMostrarLista(!mostrarLista)
    ;
    const cargarMas = ()=>{
        if (limite < listaInmuebles.total) {
            setLimite(limite + 10);
        }
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: (listaInmuebles === null || listaInmuebles === void 0 ? void 0 : listaInmuebles.inmuebles.length) === 0 ? null : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: `
      ${mostrarLista ? (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().listaRespActive) : (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().listaRespInactive)}
      ${auth.logged ? (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().heightLogin) : (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().heightLogOut)}
      `,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    onClick: mostrarListaF,
                    className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().SlideLine)} pointer`
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row g-0",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12",
                        children: !mostrarLista ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().LRtitle1)} mb-3`,
                            children: "Lista de Inmuebles"
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().LRtitle2)}`,
                            children: (listaInmuebles === null || listaInmuebles === void 0 ? void 0 : listaInmuebles.inmuebles.length) === 1 ? `Se encontró ${listaInmuebles.total} resultado` : `Se encontraron ${listaInmuebles === null || listaInmuebles === void 0 ? void 0 : listaInmuebles.total} resultados`
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().bodyList),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row",
                        children: cargando ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loading_Loading__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                listaInmuebles === null || listaInmuebles === void 0 ? void 0 : listaInmuebles.inmuebles.map((inmueble)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-sm-12 col-md-12 col-lg-12 px-4 py-2",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().cardPropBody)} card mb-3 pointer`,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().topIcons1),
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        // onCopy={compartir}
                                                        text: `red1a1.com/app/propiedades/${inmueble.slug}`,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            type: "button",
                                                            className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().iconShare)} btn me-1`
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().topIcons2),
                                                    children: auth.uid ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        // onClick={() => agregarFavorito(inmueble._id, inmueble.usuario)}
                                                        type: "button",
                                                        className: `${(_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().iconFav)} btn me-0`
                                                    }) : null
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "row" /* onClick={() => handleProperty(inmueble._id, inmueble.slug)}*/ ,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "col-sm-12 col-md-4 col-lg-4 col-xl-4 col-12 p-0",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().imgcontainer),
                                                                children: inmueble.imgs.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                    className: (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().cardImg),
                                                                    src: inmueble.imgs.length > 0 ? inmueble.imgs[0] : "",
                                                                    alt: inmueble.titulo
                                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().noImage),
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().textNoImage),
                                                                        children: [
                                                                            "A\xfan no hay ",
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                                                            }),
                                                                            " imagenes ",
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                                                            }),
                                                                            " para mostrar ",
                                                                            ":("
                                                                        ]
                                                                    })
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "col-sm-12 col-md-8 col-lg-8 col-xl-8 col-12",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().cardContenido),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().cardTitle),
                                                                        children: inmueble.titulo
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().cardDescription),
                                                                        children: inmueble.descripcion ? inmueble.descripcion : "Sin descripci\xf3n"
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "row",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "col-sm-4 col-md-5 col-4 text-center p-0",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    className: (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().tagTipoProp),
                                                                                    children: inmueble.tipoPropiedad.nombre
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "col-sm-3 col-md-2 col-lg-2 col-3 text-center p-0",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    className: (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().tagTipo),
                                                                                    children: inmueble.categoria.nombre
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "col-sm-5 col-md-5 col-5 text-end ps-0",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: (_ResposiveStyles_module_css__WEBPACK_IMPORTED_MODULE_9___default().cardPrecio),
                                                                                    children: (0,helpers__WEBPACK_IMPORTED_MODULE_5__/* .formatPrice */ .T4)(inmueble.precio)
                                                                                })
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }, inmueble._id)
                                ),
                                limite > listaInmuebles.total ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: cargando ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loading_Loading__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "text-center pointer",
                                        onClick: cargarMas,
                                        children: "Cargar m\xe1s"
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListaPropResp);


/***/ }),

/***/ 5762:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ formatPrice)
/* harmony export */ });
const formatPrice = (price)=>{
    const precio = new Intl.NumberFormat("es-MX", {
        currency: "MXN"
    }).format(price);
    const formato = "$" + precio;
    return formato;
};


/***/ }),

/***/ 7200:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "iT": () => (/* reexport safe */ _fetch__WEBPACK_IMPORTED_MODULE_0__.iT),
/* harmony export */   "T4": () => (/* reexport safe */ _formatPrice__WEBPACK_IMPORTED_MODULE_1__.T),
/* harmony export */   "rp": () => (/* reexport safe */ _horaMes__WEBPACK_IMPORTED_MODULE_2__.rp)
/* harmony export */ });
/* harmony import */ var _fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(22);
/* harmony import */ var _formatPrice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5762);
/* harmony import */ var _horaMes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3289);






/***/ })

};
;