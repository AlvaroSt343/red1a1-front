exports.id = 4648;
exports.ids = [4648];
exports.modules = {

/***/ 7299:
/***/ ((module) => {

// Exports
module.exports = {
	"containerList": "ListaProp_containerList__l10_A",
	"lista": "ListaProp_lista__IcFpw",
	"cardheader": "ListaProp_cardheader__rEo8D",
	"btnList": "ListaProp_btnList__DoqYK",
	"bodyList": "ListaProp_bodyList__HLpI_",
	"cardPropBody": "ListaProp_cardPropBody__0_fU_",
	"cardImg": "ListaProp_cardImg__ymhkm",
	"cardContenido": "ListaProp_cardContenido__EWmUo",
	"cardTitle": "ListaProp_cardTitle__cdAFW",
	"cardPrecio": "ListaProp_cardPrecio__0XTLQ",
	"cardDescription": "ListaProp_cardDescription__whGmr",
	"tagTipoProp": "ListaProp_tagTipoProp__w3Lu2",
	"tagTipo": "ListaProp_tagTipo__CeEhY",
	"imgcontainer": "ListaProp_imgcontainer__Vg86y",
	"topIcons1": "ListaProp_topIcons1__wIaSP",
	"topIcons2": "ListaProp_topIcons2__Wb_C_",
	"iconShare": "ListaProp_iconShare__cUcZL",
	"iconFav": "ListaProp_iconFav__oNr1o",
	"noImage": "ListaProp_noImage__G9NyF",
	"textNoImage": "ListaProp_textNoImage__wiqhp"
};


/***/ }),

/***/ 2486:
/***/ ((module) => {

// Exports
module.exports = {
	"containerList": "Listaprop_containerList__5ghdM",
	"lista": "Listaprop_lista__MPWnz",
	"cardheader": "Listaprop_cardheader__JXJ5C",
	"btnList": "Listaprop_btnList__amB7y",
	"bodyList": "Listaprop_bodyList__BWar9",
	"cardPropBody": "Listaprop_cardPropBody__92Z2c",
	"cardImg": "Listaprop_cardImg__4MXmS",
	"cardContenido": "Listaprop_cardContenido__ZcuKQ",
	"cardTitle": "Listaprop_cardTitle__NoUJc",
	"cardPrecio": "Listaprop_cardPrecio__AzCQG",
	"cardDescription": "Listaprop_cardDescription__nrFeN",
	"tagTipoProp": "Listaprop_tagTipoProp__m6o9o",
	"tagTipo": "Listaprop_tagTipo__Da1XM",
	"imgcontainer": "Listaprop_imgcontainer__Q1QEQ",
	"topIcons1": "Listaprop_topIcons1__wksZJ",
	"topIcons2": "Listaprop_topIcons2__mqjvq",
	"iconShare": "Listaprop_iconShare__7yvXR",
	"iconFav": "Listaprop_iconFav__H5g5N",
	"noImage": "Listaprop_noImage__3c76_",
	"textNoImage": "Listaprop_textNoImage__M0AnB"
};


/***/ }),

/***/ 4648:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ inicio_ListaProp)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: ./src/context/auth/AuthContext.tsx
var AuthContext = __webpack_require__(1165);
// EXTERNAL MODULE: ./src/helpers/fetch.tsx
var fetch = __webpack_require__(22);
// EXTERNAL MODULE: ./src/hooks/useInmuebles.tsx
var useInmuebles = __webpack_require__(8605);
// EXTERNAL MODULE: ./src/components/ui/loading/Loading.tsx
var Loading = __webpack_require__(6220);
// EXTERNAL MODULE: ./src/components/paginas/inicio/ListaProp.module.css
var ListaProp_module = __webpack_require__(7299);
var ListaProp_module_default = /*#__PURE__*/__webpack_require__.n(ListaProp_module);
// EXTERNAL MODULE: ./src/context/map/MapContext.tsx + 1 modules
var MapContext = __webpack_require__(1131);
// EXTERNAL MODULE: ./src/helpers/index.ts
var helpers = __webpack_require__(7200);
// EXTERNAL MODULE: external "react-copy-to-clipboard"
var external_react_copy_to_clipboard_ = __webpack_require__(2807);
var external_react_copy_to_clipboard_default = /*#__PURE__*/__webpack_require__.n(external_react_copy_to_clipboard_);
// EXTERNAL MODULE: ./src/components/ui/listaprop/Listaprop.module.css
var Listaprop_module = __webpack_require__(2486);
var Listaprop_module_default = /*#__PURE__*/__webpack_require__.n(Listaprop_module);
;// CONCATENATED MODULE: ./src/components/ui/listaprop/ListaPropCard.tsx






const ListaPropCard = (props)=>{
    const { inmueble , compartir , agregarFavorito , handleProperty  } = props;
    const { auth  } = (0,external_react_.useContext)(AuthContext/* AuthContext */.V);
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "col-sm-6 col-md-12 col-lg-12",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: `${(Listaprop_module_default()).cardPropBody} card mb-3 pointer`,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (Listaprop_module_default()).topIcons1,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_copy_to_clipboard_default()), {
                        onCopy: compartir,
                        text: `red1a1.com/app/propiedades/${inmueble.slug}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            type: "button",
                            className: `${(Listaprop_module_default()).iconShare} btn me-1`
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (Listaprop_module_default()).topIcons2,
                    children: auth.uid ? /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>agregarFavorito(inmueble._id, inmueble.usuario)
                        ,
                        type: "button",
                        className: `${(Listaprop_module_default()).iconFav} btn me-0`
                    }) : null
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    onClick: ()=>handleProperty(inmueble._id, inmueble.slug)
                    ,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-sm-12 col-md-4 col-lg-4 col-xl-4 col-12 p-0",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Listaprop_module_default()).imgcontainer,
                                children: inmueble.imgs.length > 0 ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    className: (Listaprop_module_default()).cardImg,
                                    src: inmueble.imgs.length > 0 ? inmueble.imgs[0] : "",
                                    alt: inmueble.titulo
                                }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Listaprop_module_default()).noImage,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (Listaprop_module_default()).textNoImage,
                                        children: [
                                            "A\xfan no hay ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {
                                            }),
                                            " imagenes ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {
                                            }),
                                            " para mostrar ",
                                            ":("
                                        ]
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-sm-12 col-md-8 col-lg-8 col-xl-8 col-12",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Listaprop_module_default()).cardContenido,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (Listaprop_module_default()).cardTitle,
                                        children: inmueble.titulo
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (Listaprop_module_default()).cardDescription,
                                        children: inmueble.descripcion ? inmueble.descripcion : "Sin descripci\xf3n"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col-4 text-center p-0",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: (Listaprop_module_default()).tagTipoProp,
                                                    children: inmueble.tipoPropiedad.nombre
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col-2 text-center p-0",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: (Listaprop_module_default()).tagTipo,
                                                    children: inmueble.categoria.nombre
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col-6 text-end",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (Listaprop_module_default()).cardPrecio,
                                                    children: (0,helpers/* formatPrice */.T4)(inmueble.precio)
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const listaprop_ListaPropCard = (ListaPropCard);

;// CONCATENATED MODULE: ./src/components/paginas/inicio/ListaProp.tsx












function ContextAwareToggle({ children , eventKey , callback  }) {
    const { activeEventKey  } = (0,external_react_.useContext)(external_react_bootstrap_.AccordionContext);
    const decoratedOnClick = (0,external_react_bootstrap_.useAccordionButton)(eventKey, ()=>callback && callback(eventKey)
    );
    const isCurrentEventKey = activeEventKey === eventKey;
    return(/*#__PURE__*/ jsx_runtime_.jsx("button", {
        type: "button",
        className: (ListaProp_module_default()).btnList,
        onClick: decoratedOnClick,
        style: {
            backgroundColor: isCurrentEventKey ? "white" : "white",
            boxShadow: isCurrentEventKey ? "none" : "0px 0px 14px 7px rgba(0, 0, 0, 0.16)",
            float: isCurrentEventKey ? "right" : "left"
        },
        children: children
    }));
}
const ListaProp = ()=>{
    var ref, ref1, ref2;
    const { auth  } = (0,external_react_.useContext)(AuthContext/* AuthContext */.V);
    const { coordenadas , southEast , northWest , southWest , northEast , categoria , tipoPropiedad ,  } = (0,external_react_.useContext)(MapContext/* MapContext */.X);
    const router = (0,router_.useRouter)();
    const { 0: verLista , 1: setVerLista  } = (0,external_react_.useState)(false);
    const { 0: limite , 1: setLimite  } = (0,external_react_.useState)(10);
    const { listaInmuebles , cargando  } = (0,useInmuebles/* useListaInmuebleCoords */.cN)(limite, southEast, northWest, southWest, northEast, coordenadas, categoria, tipoPropiedad);
    const compartir = ()=>external_react_toastify_.toast.success(`Se ha copiado al portapapeles`)
    ;
    const agregarFavorito = async (inmuebleId, propietario)=>{
        const favorito = {
            usuario: auth.uid,
            inmueble: inmuebleId,
            propietario
        };
        const resp = await (0,fetch/* agregarFav */.o4)("favoritos", favorito);
        if (resp.ok) {
            external_react_toastify_.toast.success(resp.msg);
        }
        if (!resp.ok) {
            if (resp.errors) {
                resp.errors.map((error)=>{
                    external_react_toastify_.toast.error(error.msg);
                });
            }
            if (!resp.ok) {
                external_react_toastify_.toast.error(resp.msg);
            }
        }
    };
    const handleProperty = async (id, slug)=>{
        const data = {
            usuario: auth.uid,
            inmueble: id
        };
        router.push(`/propiedades/${slug}`);
        await (0,fetch/* agregarHist */.Fl)("historial", data);
    };
    const cargarMas = ()=>{
        if (limite < listaInmuebles.total) {
            setLimite(limite + 10);
        }
    };
    const handleVerLista = ()=>setVerLista(!verLista)
    ;
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (ListaProp_module_default()).containerList,
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Accordion, {
            defaultActiveKey: "0",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Card, {
                className: (ListaProp_module_default()).lista,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Card.Header, {
                        className: (ListaProp_module_default()).cardheader,
                        children: (listaInmuebles === null || listaInmuebles === void 0 ? void 0 : (ref = listaInmuebles.inmuebles) === null || ref === void 0 ? void 0 : ref.length) === 0 ? null : /*#__PURE__*/ jsx_runtime_.jsx(ContextAwareToggle, {
                            eventKey: "1",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                onClick: handleVerLista,
                                children: verLista ? "< Ocultar lista" : "Vista de lista"
                            })
                        })
                    }),
                    (listaInmuebles === null || listaInmuebles === void 0 ? void 0 : (ref1 = listaInmuebles.inmuebles) === null || ref1 === void 0 ? void 0 : ref1.length) === 0 ? null : /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Accordion.Collapse, {
                        eventKey: "1",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Card.Body, {
                            className: (ListaProp_module_default()).bodyList,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "row",
                                children: cargando ? /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {
                                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        listaInmuebles === null || listaInmuebles === void 0 ? void 0 : (ref2 = listaInmuebles.inmuebles) === null || ref2 === void 0 ? void 0 : ref2.filter((inmueble)=>{
                                            return inmueble.publicado === true;
                                        }).map((inmueble)=>/*#__PURE__*/ jsx_runtime_.jsx(external_react_.Fragment, {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(listaprop_ListaPropCard, {
                                                    inmueble: inmueble,
                                                    compartir: compartir,
                                                    agregarFavorito: agregarFavorito,
                                                    handleProperty: handleProperty
                                                })
                                            }, inmueble._id)
                                        ),
                                        limite > listaInmuebles.total ? null : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                            children: cargando ? /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {
                                            }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "text-center pointer",
                                                onClick: cargarMas,
                                                children: "Cargar m\xe1s"
                                            })
                                        })
                                    ]
                                })
                            })
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const inicio_ListaProp = (ListaProp);


/***/ }),

/***/ 5762:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ formatPrice)
/* harmony export */ });
const formatPrice = (price)=>{
    const precio = new Intl.NumberFormat("es-MX", {
        currency: "MXN"
    }).format(price);
    const formato = "$" + precio;
    return formato;
};


/***/ }),

/***/ 3289:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ publicadoHace),
/* harmony export */   "_3": () => (/* binding */ horaMes),
/* harmony export */   "rp": () => (/* binding */ hora)
/* harmony export */ });
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);

const publicadoHace = (fecha)=>{
    const hoyMes = moment__WEBPACK_IMPORTED_MODULE_0___default()(fecha);
    return hoyMes.fromNow();
};
const horaMes = (fecha)=>{
    const hoyMes = moment__WEBPACK_IMPORTED_MODULE_0___default()(fecha);
    return hoyMes.format("HH:mm a - D/MM/YY");
};
const hora = (fecha)=>{
    const hoyMes = moment__WEBPACK_IMPORTED_MODULE_0___default()(fecha);
    return hoyMes.format("HH:mm a");
};


/***/ }),

/***/ 7200:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "iT": () => (/* reexport safe */ _fetch__WEBPACK_IMPORTED_MODULE_0__.iT),
/* harmony export */   "T4": () => (/* reexport safe */ _formatPrice__WEBPACK_IMPORTED_MODULE_1__.T),
/* harmony export */   "rp": () => (/* reexport safe */ _horaMes__WEBPACK_IMPORTED_MODULE_2__.rp)
/* harmony export */ });
/* harmony import */ var _fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(22);
/* harmony import */ var _formatPrice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5762);
/* harmony import */ var _horaMes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3289);






/***/ })

};
;