exports.id = 7184;
exports.ids = [7184];
exports.modules = {

/***/ 1130:
/***/ ((module) => {

// Exports
module.exports = {
	"whiteBBar": "ResposiveStyles_whiteBBar__pUihV",
	"btnContainer": "ResposiveStyles_btnContainer__Aa5e5",
	"whiteBBarImg": "ResposiveStyles_whiteBBarImg__bYPaB",
	"notifi": "ResposiveStyles_notifi__H5ptf",
	"notifiContainer": "ResposiveStyles_notifiContainer__Gy9xf",
	"notifiContent": "ResposiveStyles_notifiContent__sTq7G",
	"imgContainer": "ResposiveStyles_imgContainer__stzwd",
	"notifiText": "ResposiveStyles_notifiText__0rPp0",
	"notifiTextAprobado": "ResposiveStyles_notifiTextAprobado__EF0Cg",
	"aceptar": "ResposiveStyles_aceptar__kWfjA",
	"rechazar": "ResposiveStyles_rechazar__h2Gu5",
	"hra": "ResposiveStyles_hra__7shYH",
	"heightLogin": "ResposiveStyles_heightLogin__pQ6ur",
	"heightLogOut": "ResposiveStyles_heightLogOut__kzy4M",
	"listaRespInactive": "ResposiveStyles_listaRespInactive__x9__I",
	"listaRespActive": "ResposiveStyles_listaRespActive__EgA8L",
	"SlideLine": "ResposiveStyles_SlideLine__LXyEm",
	"LRtitle1": "ResposiveStyles_LRtitle1__sbkFc",
	"LRtitle2": "ResposiveStyles_LRtitle2__tRHXs",
	"bodyList": "ResposiveStyles_bodyList__STa_i",
	"cardPropBody": "ResposiveStyles_cardPropBody__6rwtp",
	"imgcontainer": "ResposiveStyles_imgcontainer__UdffD",
	"cardImg": "ResposiveStyles_cardImg__cifUW",
	"cardContenido": "ResposiveStyles_cardContenido__fDQgA",
	"cardTitle": "ResposiveStyles_cardTitle__h4kBC",
	"cardPrecio": "ResposiveStyles_cardPrecio__DMm_p",
	"cardDescription": "ResposiveStyles_cardDescription__0MQK5",
	"tagTipoProp": "ResposiveStyles_tagTipoProp__Jbd31",
	"tagTipo": "ResposiveStyles_tagTipo__46jiU",
	"topIcons1": "ResposiveStyles_topIcons1___Mpzr",
	"topIcons2": "ResposiveStyles_topIcons2__nGmg2",
	"iconShare": "ResposiveStyles_iconShare__MYOID",
	"iconFav": "ResposiveStyles_iconFav__YLjdm",
	"noImage": "ResposiveStyles_noImage__3gBt_",
	"textNoImage": "ResposiveStyles_textNoImage__8HAQt"
};


/***/ }),

/***/ 3289:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ publicadoHace),
/* harmony export */   "_3": () => (/* binding */ horaMes),
/* harmony export */   "rp": () => (/* binding */ hora)
/* harmony export */ });
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);

const publicadoHace = (fecha)=>{
    const hoyMes = moment__WEBPACK_IMPORTED_MODULE_0___default()(fecha);
    return hoyMes.fromNow();
};
const horaMes = (fecha)=>{
    const hoyMes = moment__WEBPACK_IMPORTED_MODULE_0___default()(fecha);
    return hoyMes.format("HH:mm a - D/MM/YY");
};
const hora = (fecha)=>{
    const hoyMes = moment__WEBPACK_IMPORTED_MODULE_0___default()(fecha);
    return hoyMes.format("HH:mm a");
};


/***/ })

};
;