"use strict";
exports.id = 1458;
exports.ids = [1458];
exports.modules = {

/***/ 1458:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "p5": () => (/* binding */ ChatContext),
  "aM": () => (/* binding */ ChatProvider)
});

// UNUSED EXPORTS: initialState

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/context/auth/AuthContext.tsx
var AuthContext = __webpack_require__(1165);
// EXTERNAL MODULE: ./src/hooks/useConversaciones.tsx
var useConversaciones = __webpack_require__(5440);
// EXTERNAL MODULE: ./src/helpers/fetch.tsx
var fetch = __webpack_require__(22);
;// CONCATENATED MODULE: ./src/context/chat/chatReducer.tsx
const chatReducer = (state, action)=>{
    switch(action.type){
        case "ActivarChat":
            if (state.chatActivo === action.payload) return state;
            return {
                ...state,
                chatActivo: action.payload,
                mensajes: []
            };
        case "DesactivarChat":
            return {
                ...state,
                chatActivo: null,
                mensajes: []
            };
        case "NuevoMensaje":
            if (state.chatActivo === action.payload.remitente || state.chatActivo === action.payload.para) {
                return {
                    ...state,
                    mensajes: [
                        ...state.mensajes,
                        action.payload
                    ]
                };
            } else {
                return state;
            }
        case "CargarMensajes":
            return {
                ...state,
                mensajes: [
                    ...action.payload
                ]
            };
        default:
            return state;
    }
};

;// CONCATENATED MODULE: ./src/context/chat/ChatContext.tsx






const initialState = {
    uid: "",
    chatActivo: null,
    mensajes: []
};
const ChatContext = /*#__PURE__*/ (0,external_react_.createContext)({
});
const ChatProvider = ({ children  })=>{
    const { auth  } = (0,external_react_.useContext)(AuthContext/* AuthContext */.V);
    const { 0: chatState , 1: dispatch  } = (0,external_react_.useReducer)(chatReducer, initialState, undefined);
    const { 0: mensajePara , 1: setMensajePara  } = (0,external_react_.useState)("");
    const { 0: minimizarChat , 1: setMinimizarChat  } = (0,external_react_.useState)(true);
    const scrollToBotom = (0,external_react_.useRef)(null);
    const { 0: showCanvas , 1: setShowCanvas  } = (0,external_react_.useState)(false);
    const { conversaciones , cargando , setConversaciones  } = (0,useConversaciones/* useConversaciones */.r)(auth.uid);
    const iniciarChat = async (data)=>{
        var ref;
        if (data.destinatario === data.remitente) return;
        const añadirChat = await (0,fetch/* crearChat */.kP)("chats", data);
        dispatch({
            type: "ActivarChat",
            payload: data.destinatario
        });
        const resp = await (0,fetch/* obtenerMensajes */.Xo)(`mensajes/${data.destinatario}`);
        dispatch({
            type: "CargarMensajes",
            payload: resp.mensajes
        });
        if (añadirChat.ok) {
            setConversaciones([
                ...conversaciones,
                añadirChat.guardarChat
            ]);
        }
        (ref = scrollToBotom.current) === null || ref === void 0 ? void 0 : ref.scrollIntoView();
    };
    const handleCloseCanvas = ()=>setShowCanvas(false)
    ;
    const handleShowCanvas = ()=>setShowCanvas(true)
    ;
    return(/*#__PURE__*/ jsx_runtime_.jsx(ChatContext.Provider, {
        value: {
            minimizarChat,
            setMinimizarChat,
            chatState,
            dispatch,
            mensajePara,
            setMensajePara,
            scrollToBotom,
            iniciarChat,
            cargando,
            conversaciones,
            showCanvas,
            setShowCanvas,
            handleCloseCanvas,
            handleShowCanvas
        },
        children: children
    }));
};


/***/ }),

/***/ 5440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ useConversaciones),
/* harmony export */   "A": () => (/* binding */ useUltimoMsg)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1165);
/* harmony import */ var _credentials_credentials__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6681);



// import { Conversacion } from "../interfaces/ChatInterface";
const useConversaciones = (uid)=>{
    const { 0: conversaciones , 1: setConversaciones  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    // const [conversaciones, setConversaciones] = useState<Conversacion[]>([]);
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const obtenerConversaciones = async ()=>{
        setCargando(true);
        const resp = await fetch(`${_credentials_credentials__WEBPACK_IMPORTED_MODULE_2__/* .production */ .C7}/chats/${uid}`);
        const data = await resp.json();
        setConversaciones(data);
        setCargando(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerConversaciones();
    }, [
        uid
    ]);
    return {
        conversaciones,
        cargando,
        setConversaciones
    };
};
const useUltimoMsg = (uid, id)=>{
    const { auth  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_1__/* .AuthContext */ .V);
    const { 0: ultimoMsg , 1: setUltimoMsg  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const token = localStorage.getItem("token") || "";
    if (uid === auth.uid) {
        const ultimoMensaje = async ()=>{
            const res = await fetch(`${_credentials_credentials__WEBPACK_IMPORTED_MODULE_2__/* .production */ .C7}/mensajes/${id}`, {
                headers: {
                    "x-token": token
                }
            });
            const data = await res.json();
            setUltimoMsg(data.mensajes);
        };
        (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
            ultimoMensaje();
        }, []);
    }
    if (uid !== auth.uid) {
        const ultimoMensaje = async ()=>{
            const res = await fetch(`${_credentials_credentials__WEBPACK_IMPORTED_MODULE_2__/* .production */ .C7}/mensajes/${uid}`, {
                headers: {
                    "x-token": token
                }
            });
            const data = await res.json();
            setUltimoMsg(data.mensajes);
        };
        (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
            ultimoMensaje();
        }, []);
    }
    return {
        ultimoMsg
    };
};


/***/ })

};
;