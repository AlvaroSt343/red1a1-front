"use strict";
exports.id = 7348;
exports.ids = [7348];
exports.modules = {

/***/ 5762:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ formatPrice)
/* harmony export */ });
const formatPrice = (price)=>{
    const precio = new Intl.NumberFormat("es-MX", {
        currency: "MXN"
    }).format(price);
    const formato = "$" + precio;
    return formato;
};


/***/ }),

/***/ 3674:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "sw": () => (/* binding */ useReferenciasUsuario),
/* harmony export */   "KN": () => (/* binding */ useReferenciaNumero),
/* harmony export */   "uA": () => (/* binding */ useReferencias)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var credentials_credentials__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6681);


const useReferenciasUsuario = (uid, desde)=>{
    const { 0: referencias , 1: setReferencias  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const { 0: total , 1: setTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const obtenerReferencias = async ()=>{
        const res = await fetch(`${credentials_credentials__WEBPACK_IMPORTED_MODULE_1__/* .production */ .C7}/referencias/${uid}?desde=${desde}`);
        const data = await res.json();
        setReferencias(data.referencias);
        setTotal(data.total);
        setCargando(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerReferencias();
    }, [
        desde
    ]);
    return {
        referencias,
        cargando,
        total,
        setReferencias
    };
};
const useReferenciaNumero = (numero)=>{
    const { 0: referencia , 1: setReferencia  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        importe: 0,
        _id: "",
        createdAt: "",
        estado: false,
        paquete: {
            _id: "",
            nombre: ""
        },
        precio: 0,
        referencia: "",
        totalUsuarios: 0,
        updatedAt: "",
        usuario: {
            _id: "",
            apellido: "",
            correo: "",
            img: "",
            nombre: "",
            role: "",
            telefonoOficina: "",
            telefonoPersonal: ""
        },
        comprobante: ""
    });
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const obtenerReferenciaPorNumero = async ()=>{
        const res = await fetch(`${credentials_credentials__WEBPACK_IMPORTED_MODULE_1__/* .production */ .C7}/referencias/ref/numero?numero=${numero}`);
        const data = await res.json();
        setReferencia(data.referencia);
        setCargando(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerReferenciaPorNumero();
    }, [
        numero
    ]);
    return {
        referencia,
        cargando,
        setReferencia
    };
};
const useReferencias = (desde)=>{
    const { 0: referencias , 1: setReferencias  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const { 0: total , 1: setTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const obtenerReferencias = async ()=>{
        const res = await fetch(`${credentials_credentials__WEBPACK_IMPORTED_MODULE_1__/* .production */ .C7}/referencias?desde=${desde}`);
        const data = await res.json();
        setReferencias(data.referencias);
        setTotal(data.total);
        setCargando(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerReferencias();
    }, [
        desde
    ]);
    return {
        referencias,
        cargando,
        total,
        setReferencias
    };
};


/***/ })

};
;