exports.id = 4276;
exports.ids = [4276];
exports.modules = {

/***/ 9454:
/***/ ((module) => {

// Exports
module.exports = {
	"PaqIndivi": "Referencias_PaqIndivi__gWXZq",
	"PaqBasic": "Referencias_PaqBasic__fONaE",
	"PaqInter": "Referencias_PaqInter__XeXLd",
	"PaqAvanza": "Referencias_PaqAvanza__rAPZQ",
	"refCard": "Referencias_refCard__OJ_lL",
	"paqueteBG": "Referencias_paqueteBG__0Pv8J",
	"paqueteNombre": "Referencias_paqueteNombre__KDIf8",
	"refCardContenido": "Referencias_refCardContenido__822Qf",
	"TituloCard": "Referencias_TituloCard__XnAnT",
	"labelsCard": "Referencias_labelsCard__lNwGh",
	"contentCard": "Referencias_contentCard__jsyH1",
	"btnClose": "Referencias_btnClose__hr2iB",
	"btnAp": "Referencias_btnAp__g6rpk",
	"btnTicket": "Referencias_btnTicket__w0geK",
	"tablaRef": "Referencias_tablaRef__iT49E",
	"headerRef": "Referencias_headerRef__Wod6M",
	"rowT": "Referencias_rowT__yRddt",
	"headersT": "Referencias_headersT__p62kN",
	"contentT": "Referencias_contentT__n_bGK",
	"btnT1": "Referencias_btnT1__NhS2w",
	"btnT2": "Referencias_btnT2__oqEg2"
};


/***/ }),

/***/ 3126:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ AdminRoute)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1165);
/* harmony import */ var _components_ui_loading_Loading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6220);





const AdminRoute = (Component)=>{
    return function RutaPrivada(props) {
        const { auth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__/* .AuthContext */ .V);
        const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
        if (auth.role !== "Administrador") {
            (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
                router.replace("/");
            }, []);
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_loading_Loading__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            }));
        }
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
            auth: auth,
            ...props
        }));
    };
};


/***/ })

};
;