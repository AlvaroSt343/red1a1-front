"use strict";
exports.id = 1821;
exports.ids = [1821];
exports.modules = {

/***/ 1821:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ useCategories),
/* harmony export */   "T": () => (/* binding */ useTipoPropiedad)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const devURL = "http://localhost:8080/api";
const baseURL = "https://red1a1-back.herokuapp.com/api";
const useCategories = ()=>{
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const { 0: categorias , 1: setCategorias  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const obtenerCategorias = async ()=>{
        const resp = await fetch(baseURL + "/categorias/");
        const data = await resp.json();
        setCategorias(data.categorias);
        setCargando(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerCategorias();
    }, []);
    return {
        categorias,
        cargando
    };
};
const useTipoPropiedad = ()=>{
    const { 0: propertyTypes , 1: setPropertyTypes  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const obtenerTipoPropiedad = async ()=>{
        const res = await fetch(`${baseURL}/tipo-de-propiedad`);
        const data = await res.json();
        setPropertyTypes(data.tipoPropiedad);
        setLoading(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerTipoPropiedad();
    }, []);
    return {
        propertyTypes,
        loading
    };
};


/***/ })

};
;