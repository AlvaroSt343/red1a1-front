"use strict";
exports.id = 8605;
exports.ids = [8605];
exports.modules = {

/***/ 8605:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "wW": () => (/* binding */ useInmueble),
/* harmony export */   "vx": () => (/* binding */ useInmueblesCoordenadas),
/* harmony export */   "cN": () => (/* binding */ useListaInmuebleCoords),
/* harmony export */   "pc": () => (/* binding */ useAllInmuebles),
/* harmony export */   "wQ": () => (/* binding */ useTipoInmueble),
/* harmony export */   "mJ": () => (/* binding */ useCategoriaInmueble),
/* harmony export */   "oi": () => (/* binding */ useFechaInmueble)
/* harmony export */ });
/* unused harmony exports useInmuebles, useListaInmueble */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var context_map_MapContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1131);
/* harmony import */ var credentials__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6681);




const useInmuebles = ()=>{
    const { dirMapa  } = useContext(MapContext);
    const { 0: inmuebles , 1: setInmuebles  } = useState();
    const { 0: cargando , 1: setCargando  } = useState(true);
    const obtenerInmuebles = async ()=>{
        const resp = await fetch(`${production}/inmuebles/direccion?direccion=${dirMapa}`);
        const data = await resp.json();
        setInmuebles(data.inmuebles);
        setCargando(false);
    };
    useEffect(()=>{
        obtenerInmuebles();
    }, [
        dirMapa
    ]);
    return {
        inmuebles,
        cargando
    };
};
const useListaInmueble = (limite)=>{
    const { dirMapa  } = useContext(MapContext);
    const { 0: listaInmuebles , 1: setListaInmuebles  } = useState();
    const { 0: cargando , 1: setCargando  } = useState(true);
    const obtenerInmuebles = async ()=>{
        const resp = await fetch(`${production}/inmuebles/lista-inmuebles?direccion=${dirMapa}&limite=${limite}`);
        const data = await resp.json();
        setListaInmuebles(data);
        setCargando(false);
    };
    useEffect(()=>{
        obtenerInmuebles();
    }, [
        dirMapa,
        limite
    ]);
    return {
        listaInmuebles,
        cargando
    };
};
const useInmueble = (id)=>{
    const { 0: inmueble , 1: setInmueble  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const { 0: imgs , 1: setImgs  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const obtenerInmueble = async ()=>{
        const res = await fetch(`${credentials__WEBPACK_IMPORTED_MODULE_3__/* .production */ .C7}/inmuebles/${id}`);
        const data = await res.json();
        setInmueble(data.inmueble);
        setImgs(data.inmueble.imgs);
        setCargando(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerInmueble();
    }, []);
    return {
        inmueble,
        cargando,
        imgs,
        setImgs
    };
};
const useInmueblesCoordenadas = (southEast, northWest, southWest, northEast, coordenadas, categoria, tipoPropiedad)=>{
    const { 0: inmuebles , 1: setInmuebles  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const obtenerInmueblesPorCoordenadas = async ()=>{
        try {
            const resp = await fetch(`${credentials__WEBPACK_IMPORTED_MODULE_3__/* .production */ .C7}/inmuebles/inmuebles/coordenadas?lat_south_east=${southEast.lat}&lng_south_east=${southEast.lng}&lat_south_west=${southWest === null || southWest === void 0 ? void 0 : southWest.lat}&lng_south_west=${southWest === null || southWest === void 0 ? void 0 : southWest.lng}&lat_north_east=${northEast === null || northEast === void 0 ? void 0 : northEast.lat}&lng_north_east=${northEast === null || northEast === void 0 ? void 0 : northEast.lng}&lat_north_west=${northWest.lat}&lng_north_west=${northWest.lng}&categoria=${categoria}&tipoPropiedad=${tipoPropiedad}`);
            const data = await resp.json();
            setInmuebles(data.inmuebles);
            setCargando(false);
        } catch (error) {
            console.log(error);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerInmueblesPorCoordenadas();
    }, [
        southEast,
        northWest,
        southWest,
        northEast,
        coordenadas,
        tipoPropiedad,
        categoria, 
    ]);
    return {
        inmuebles,
        cargando
    };
};
const useListaInmuebleCoords = (limite, southEast, northWest, southWest, northEast, coordenadas, categoria, tipoPropiedad)=>{
    const { 0: listaInmuebles , 1: setListaInmuebles  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const obtenerInmuebles = async ()=>{
        try {
            const resp = await fetch(`${credentials__WEBPACK_IMPORTED_MODULE_3__/* .production */ .C7}/inmuebles/lista-inmuebles/coordenadas?lat_south_east=${southEast.lat}&lng_south_east=${southEast.lng}&lat_south_west=${southWest === null || southWest === void 0 ? void 0 : southWest.lat}&lng_south_west=${southWest === null || southWest === void 0 ? void 0 : southWest.lng}&lat_north_east=${northEast === null || northEast === void 0 ? void 0 : northEast.lat}&lng_north_east=${northEast === null || northEast === void 0 ? void 0 : northEast.lng}&lat_north_west=${northWest.lat}&lng_north_west=${northWest.lng}&limite=${limite}&categoria=${categoria}&tipoPropiedad=${tipoPropiedad}`);
            const data = await resp.json();
            setListaInmuebles(data);
            setCargando(false);
        } catch (error) {
            console.log(error);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerInmuebles();
    }, [
        southEast,
        northWest,
        southWest,
        northEast,
        coordenadas,
        tipoPropiedad,
        categoria, 
    ]);
    return {
        listaInmuebles,
        cargando
    };
};
const useAllInmuebles = ()=>{
    const { 0: inmuebles , 1: setInmuebles  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const { 0: total , 1: setTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const obtenerInmuebles = async ()=>{
        const res = await fetch(`${credentials__WEBPACK_IMPORTED_MODULE_3__/* .production */ .C7}/inmuebles`);
        const data = await res.json();
        setTotal(data.total);
        setInmuebles(data.inmuebles);
        setCargando(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerInmuebles();
    }, []);
    return {
        inmuebles,
        cargando,
        total
    };
};
const useTipoInmueble = ()=>{
    const { 0: casas , 1: setCasas  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const { 0: departamentos , 1: setDepartamentos  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const { 0: bodegas , 1: setBodegas  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const { 0: desarrollos , 1: setDesarrollos  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const { 0: locales , 1: setLocales  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const { 0: oficinas , 1: setOficinas  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const obtenerTotalCasas = async ()=>{
        const res = await fetch(`${credentials__WEBPACK_IMPORTED_MODULE_3__/* .production */ .C7}/inmuebles/inmuebles/tipo-propiedad?tipoPropiedad=${credentials__WEBPACK_IMPORTED_MODULE_3__/* .casasC */ .bF}`);
        const data = await res.json();
        setCasas(data.total);
    };
    const obtenerTotalDepartamentos = async ()=>{
        const res = await fetch(`${credentials__WEBPACK_IMPORTED_MODULE_3__/* .production */ .C7}/inmuebles/inmuebles/tipo-propiedad?tipoPropiedad=${credentials__WEBPACK_IMPORTED_MODULE_3__/* .departamentosCat */ .ay}`);
        const data = await res.json();
        setDepartamentos(data.total);
    };
    const obtenerTotalBodegas = async ()=>{
        const res = await fetch(`${credentials__WEBPACK_IMPORTED_MODULE_3__/* .production */ .C7}/inmuebles/inmuebles/tipo-propiedad?tipoPropiedad=${credentials__WEBPACK_IMPORTED_MODULE_3__/* .bodegasCat */ .A9}`);
        const data = await res.json();
        setBodegas(data.total);
    };
    const obtenerTotalDesarrollos = async ()=>{
        const res = await fetch(`${credentials__WEBPACK_IMPORTED_MODULE_3__/* .production */ .C7}/inmuebles/inmuebles/tipo-propiedad?tipoPropiedad=${credentials__WEBPACK_IMPORTED_MODULE_3__/* .desarrollosCat */ .Bd}`);
        const data = await res.json();
        setDesarrollos(data.total);
    };
    const obtenerTotalLocales = async ()=>{
        const res = await fetch(`${credentials__WEBPACK_IMPORTED_MODULE_3__/* .production */ .C7}/inmuebles/inmuebles/tipo-propiedad?tipoPropiedad=${credentials__WEBPACK_IMPORTED_MODULE_3__/* .localesCat */ .qn}`);
        const data = await res.json();
        setLocales(data.total);
    };
    const obtenerTotalOficinas = async ()=>{
        const res = await fetch(`${credentials__WEBPACK_IMPORTED_MODULE_3__/* .production */ .C7}/inmuebles/inmuebles/tipo-propiedad?tipoPropiedad=${credentials__WEBPACK_IMPORTED_MODULE_3__/* .oficinasCat */ .iS}`);
        const data = await res.json();
        setOficinas(data.total);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerTotalCasas();
        obtenerTotalDepartamentos();
        obtenerTotalBodegas();
        obtenerTotalDesarrollos();
        obtenerTotalLocales();
        obtenerTotalOficinas();
    }, []);
    return {
        casas,
        departamentos,
        bodegas,
        desarrollos,
        locales,
        oficinas
    };
};
const useCategoriaInmueble = ()=>{
    const { 0: renta , 1: setRenta  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const { 0: venta , 1: setVenta  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const obtenerTotalRenta = async ()=>{
        const res = await fetch(`${credentials__WEBPACK_IMPORTED_MODULE_3__/* .production */ .C7}/inmuebles/inmuebles/categoria?categoria=${credentials__WEBPACK_IMPORTED_MODULE_3__/* .rentas */ .GJ}`);
        const data = await res.json();
        setRenta(data.total);
    };
    const obtenerTotalVenta = async ()=>{
        const res = await fetch(`${credentials__WEBPACK_IMPORTED_MODULE_3__/* .production */ .C7}/inmuebles/inmuebles/categoria?categoria=${credentials__WEBPACK_IMPORTED_MODULE_3__/* .ventas */ .DJ}`);
        const data = await res.json();
        setVenta(data.total);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerTotalRenta();
        obtenerTotalVenta();
    }, []);
    return {
        renta,
        venta
    };
};
const useFechaInmueble = ()=>{
    const { 0: hoy , 1: setHoy  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const { 0: semana , 1: setSemana  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const { 0: mes , 1: setMes  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const obtenerInmueblesHoy = async ()=>{
        const today = moment__WEBPACK_IMPORTED_MODULE_1___default()().startOf("day");
        const res = await fetch(`${credentials__WEBPACK_IMPORTED_MODULE_3__/* .production */ .C7}/inmuebles/inmuebles/fecha?createdAt=${Number(today)}`);
        const data = await res.json();
        setHoy(data.total);
    };
    const obtenerInmueblesSemana = async ()=>{
        const today = moment__WEBPACK_IMPORTED_MODULE_1___default()().startOf("day");
        const week = today.subtract(7, "day");
        const res = await fetch(`${credentials__WEBPACK_IMPORTED_MODULE_3__/* .production */ .C7}/inmuebles/inmuebles/fecha?createdAt=${Number(week)}`);
        const data = await res.json();
        setSemana(data.total);
    };
    const obtenerInmueblesMes = async ()=>{
        const today = moment__WEBPACK_IMPORTED_MODULE_1___default()().startOf("day");
        const month = today.subtract(30, "days");
        const res = await fetch(`${credentials__WEBPACK_IMPORTED_MODULE_3__/* .production */ .C7}/inmuebles/inmuebles/fecha?createdAt=${Number(month)}`);
        const data = await res.json();
        setMes(data.total);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerInmueblesHoy();
        obtenerInmueblesSemana();
        obtenerInmueblesMes();
    }, []);
    return {
        hoy,
        semana,
        mes
    };
};


/***/ })

};
;