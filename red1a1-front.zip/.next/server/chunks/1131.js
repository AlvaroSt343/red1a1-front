"use strict";
exports.id = 1131;
exports.ids = [1131];
exports.modules = {

/***/ 1131:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "X": () => (/* binding */ MapContext),
  "I": () => (/* binding */ MapProvider)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/helpers/obtenerUbicación.tsx
const obtenerUbicacionUsuario = async ()=>{
    return new Promise((resolve, reject)=>{
        navigator.geolocation.getCurrentPosition(({ coords  })=>{
            resolve({
                lng: coords.longitude,
                lat: coords.latitude
            });
        }, (err)=>{
            alert("No se pudo obtener la geolocalizaci\xf3n");
            console.log(err);
            reject();
        });
    });
};

// EXTERNAL MODULE: ./src/credentials/credentials.tsx
var credentials = __webpack_require__(6681);
;// CONCATENATED MODULE: ./src/context/map/MapContext.tsx




const MapContext = /*#__PURE__*/ (0,external_react_.createContext)({
});
const MapProvider = ({ children  })=>{
    const { 0: coordenadas , 1: setCoordenadas  } = (0,external_react_.useState)({
        lat: 19.4326078,
        lng: -99.133207
    });
    const { 0: ubicacion , 1: setUbicacion  } = (0,external_react_.useState)({
        lat: 19.4326077,
        lng: -99.133208
    });
    const { 0: ubicacionUsuario , 1: setUbicacionUsuario  } = (0,external_react_.useState)({
        lat: 0,
        lng: 0
    });
    const { 0: southEast , 1: setSouthEast  } = (0,external_react_.useState)({
        lat: 0,
        lng: 0
    });
    const { 0: northWest , 1: setNorthWest  } = (0,external_react_.useState)({
        lat: 0,
        lng: 0
    });
    const { 0: southWest , 1: setSouthWest  } = (0,external_react_.useState)({
        lat: 0,
        lng: 0
    });
    const { 0: northEast , 1: setNorthEast  } = (0,external_react_.useState)({
        lat: 0,
        lng: 0
    });
    const { 0: direccion , 1: setDireccion  } = (0,external_react_.useState)();
    const { 0: dirMapa , 1: setDirMapa  } = (0,external_react_.useState)("Ciudad de M\xe9xico, CDMX, M\xe9xico");
    const { 0: zoom , 1: setZoom  } = (0,external_react_.useState)(5);
    const { 0: categoria , 1: setCategoria  } = (0,external_react_.useState)(credentials/* rentas */.GJ);
    const { 0: tipoPropiedad , 1: setTipoPropiedad  } = (0,external_react_.useState)(credentials/* casasC */.bF);
    const { 0: filtros , 1: setFiltros  } = (0,external_react_.useState)(false);
    const { 0: ocultarBottomNav , 1: setOcultarBottomNav  } = (0,external_react_.useState)(true);
    (0,external_react_.useEffect)(()=>{
        obtenerUbicacionUsuario().then((lngLat)=>{
            setUbicacionUsuario({
                lat: lngLat.lat,
                lng: lngLat.lng
            });
            setCoordenadas({
                lat: lngLat.lat,
                lng: lngLat.lng
            });
        });
    }, []);
    (0,external_react_.useEffect)(()=>{
        coordenadas.lat !== 19.4326078 && coordenadas.lng !== -99.133207 ? setZoom(12) : setZoom(5);
    }, [
        coordenadas
    ]);
    return(/*#__PURE__*/ jsx_runtime_.jsx(MapContext.Provider, {
        value: {
            coordenadas,
            setCoordenadas,
            ubicacion,
            setUbicacion,
            direccion,
            setDireccion,
            dirMapa,
            setDirMapa,
            zoom,
            setZoom,
            southEast,
            setSouthEast,
            northWest,
            setNorthWest,
            southWest,
            setSouthWest,
            northEast,
            setNorthEast,
            ubicacionUsuario,
            setUbicacionUsuario,
            categoria,
            setCategoria,
            tipoPropiedad,
            setTipoPropiedad,
            filtros,
            setFiltros,
            ocultarBottomNav,
            setOcultarBottomNav
        },
        children: children
    }));
};


/***/ })

};
;