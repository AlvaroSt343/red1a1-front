"use strict";
exports.id = 1810;
exports.ids = [1810];
exports.modules = {

/***/ 1810:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ SocketContext),
/* harmony export */   "w": () => (/* binding */ SocketProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks_useSocket__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5373);
/* harmony import */ var _auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1165);
/* harmony import */ var _chat_ChatContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1458);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useSocket__WEBPACK_IMPORTED_MODULE_2__]);
_hooks_useSocket__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





const SocketContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
});
const SocketProvider = ({ children  })=>{
    const { auth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__/* .AuthContext */ .V);
    const { dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_chat_ChatContext__WEBPACK_IMPORTED_MODULE_4__/* .ChatContext */ .p5);
    const { socket , online , conectarSocket , desconectarSocket  } = (0,_hooks_useSocket__WEBPACK_IMPORTED_MODULE_2__/* .useSocket */ .s)("https://red1a1-back.herokuapp.com");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (auth.logged) {
            conectarSocket();
        }
    }, [
        auth,
        conectarSocket
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!auth.logged) {
            desconectarSocket();
        }
    }, [
        auth,
        desconectarSocket
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        socket === null || socket === void 0 ? void 0 : socket.on("mensaje-personal", (mensaje)=>{
            dispatch({
                type: "NuevoMensaje",
                payload: mensaje
            });
        });
    }, [
        socket,
        dispatch
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SocketContext.Provider, {
        value: {
            socket,
            online
        },
        children: children
    }));
};

});

/***/ }),

/***/ 5373:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ useSocket)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4612);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([socket_io_client__WEBPACK_IMPORTED_MODULE_1__]);
socket_io_client__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];


const useSocket = (serverPath)=>{
    const { 0: socket , 1: setSocket  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(undefined);
    const { 0: online , 1: setOnline  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const conectarSocket = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        const token = localStorage.getItem('token');
        const socketTemp = (0,socket_io_client__WEBPACK_IMPORTED_MODULE_1__.io)(serverPath, {
            transports: [
                'websocket'
            ],
            autoConnect: true,
            forceNew: true,
            query: {
                'x-token': token
            }
        });
        setSocket(socketTemp);
    }, [
        serverPath
    ]);
    const desconectarSocket = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        socket === null || socket === void 0 ? void 0 : socket.disconnect();
    }, [
        socket
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        setOnline(socket === null || socket === void 0 ? void 0 : socket.connected);
    }, [
        socket
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        socket === null || socket === void 0 ? void 0 : socket.on('connect', ()=>setOnline(true)
        );
    }, [
        socket
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        socket === null || socket === void 0 ? void 0 : socket.on('disconnect', ()=>setOnline(false)
        );
    }, [
        socket
    ]);
    return {
        socket,
        online,
        conectarSocket,
        desconectarSocket
    };
};

});

/***/ })

};
;