exports.id = 7652;
exports.ids = [7652];
exports.modules = {

/***/ 8668:
/***/ ((module) => {

// Exports
module.exports = {
	"nombre": "Perfil_nombre____fMf",
	"paquete": "Perfil_paquete__SwNzM",
	"empresa": "Perfil_empresa__oaf58",
	"correo": "Perfil_correo__HX0zS",
	"telefono": "Perfil_telefono__Oo_Mg",
	"imagencontainer": "Perfil_imagencontainer__6PTyc",
	"perfilImg": "Perfil_perfilImg__iwsUS",
	"cargaImg": "Perfil_cargaImg__QoN4H",
	"buscador": "Perfil_buscador__koiWU",
	"respuesta": "Perfil_respuesta__kPIB8",
	"item": "Perfil_item___YvSN",
	"edicionIcon": "Perfil_edicionIcon__Os3Ng",
	"btnSession": "Perfil_btnSession__tfzBL"
};


/***/ }),

/***/ 411:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ PrivateRoute)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1165);
/* harmony import */ var _components_ui_loading_Loading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6220);





const PrivateRoute = (Component)=>{
    return function RutaPrivada(props) {
        const { auth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__/* .AuthContext */ .V);
        const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
        if (!auth.logged) {
            (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
                router.replace("/");
            }, []);
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_loading_Loading__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            }));
        }
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
            auth: auth,
            ...props
        }));
    };
};


/***/ })

};
;