exports.id = 6030;
exports.ids = [6030];
exports.modules = {

/***/ 2893:
/***/ ((module) => {

// Exports
module.exports = {
	"buscador": "Buscador_buscador__T0bve",
	"respuesta": "Buscador_respuesta__a37x9",
	"item": "Buscador_item__bLX3L",
	"buscador2": "Buscador_buscador2__yH_nM",
	"respuesta2": "Buscador_respuesta2__QI3Yv",
	"item2": "Buscador_item2__INoMs",
	"filterIcon": "Buscador_filterIcon__44GQr",
	"filterIconActive": "Buscador_filterIconActive__HtYGw",
	"leftArrow": "Buscador_leftArrow__XR6MH"
};


/***/ }),

/***/ 2016:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2433);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_map_MapContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1131);




const containerStyle = {
    width: "100%",
    height: "500px"
};
const MapaUbicacion = ()=>{
    const { ubicacion , setUbicacion  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_map_MapContext__WEBPACK_IMPORTED_MODULE_3__/* .MapContext */ .X);
    const onDragEnd = (e)=>{
        setUbicacion({
            lat: e.latLng.lat(),
            lng: e.latLng.lng()
        });
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.GoogleMap, {
        mapContainerStyle: containerStyle,
        center: {
            lat: ubicacion.lat,
            lng: ubicacion.lng
        },
        zoom: 14,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.Marker, {
            draggable: true,
            position: {
                lat: ubicacion.lat,
                lng: ubicacion.lng
            },
            onDragEnd: onDragEnd,
            icon: {
                url: "/images/icons/marcador.svg",
                scaledSize: new google.maps.Size(50, 50)
            }
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MapaUbicacion);


/***/ }),

/***/ 2688:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_geosuggest__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8580);
/* harmony import */ var react_geosuggest__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_geosuggest__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_map_MapContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1131);
/* harmony import */ var _Buscador_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2893);
/* harmony import */ var _Buscador_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Buscador_module_css__WEBPACK_IMPORTED_MODULE_4__);





const SeleccionarLugar = ()=>{
    const geosuggestEl = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { setUbicacion , setDireccion  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_map_MapContext__WEBPACK_IMPORTED_MODULE_3__/* .MapContext */ .X);
    const onSuggestSelect = (suggest)=>{
        if (!suggest) return;
        setDireccion(suggest.label);
        !suggest ? setUbicacion({
            lat: 19.4326077,
            lng: -99.133208
        }) : setUbicacion({
            lat: suggest.location.lat,
            lng: suggest.location.lng
        });
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_geosuggest__WEBPACK_IMPORTED_MODULE_2___default()), {
            ref: geosuggestEl,
            queryDelay: 530,
            country: "mx",
            placeholder: "Busca tu colonia aqu\xed...",
            onSuggestSelect: onSuggestSelect,
            autoComplete: "off",
            inputClassName: (_Buscador_module_css__WEBPACK_IMPORTED_MODULE_4___default().buscador2),
            suggestsClassName: (_Buscador_module_css__WEBPACK_IMPORTED_MODULE_4___default().respuesta2),
            suggestItemClassName: (_Buscador_module_css__WEBPACK_IMPORTED_MODULE_4___default().item2)
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SeleccionarLugar);


/***/ })

};
;