"use strict";
exports.id = 4269;
exports.ids = [4269];
exports.modules = {

/***/ 4269:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ui_loading_Loading__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6220);
/* harmony import */ var _FormDesign_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3320);
/* harmony import */ var _FormDesign_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _hooks_useCategories__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1821);
/* harmony import */ var _ui_buscador_SeleccionarLugar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2688);
/* harmony import */ var _MapaUbicacion__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2016);
/* harmony import */ var _ui_button_Button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7924);
/* harmony import */ var _context_map_MapContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1131);










const FormStepOne = (props)=>{
    const { handleNextStep , handleChange , titulo , tipoPropiedad , setTipoPropiedad , precio , comisiones , categoria: categoria1 , setCategoria ,  } = props;
    const { direccion  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_map_MapContext__WEBPACK_IMPORTED_MODULE_8__/* .MapContext */ .X);
    const { categorias , cargando  } = (0,_hooks_useCategories__WEBPACK_IMPORTED_MODULE_4__/* .useCategories */ .L)();
    const { loading , propertyTypes  } = (0,_hooks_useCategories__WEBPACK_IMPORTED_MODULE_4__/* .useTipoPropiedad */ .T)();
    const longitudTitulo = titulo.length;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Form.Group, {
                className: "mb-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Form.Label, {
                        className: `${(_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_9___default().subTitulo)}`,
                        children: "T\xedtulo del inmueble"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Form.Control, {
                        type: "text",
                        value: titulo,
                        name: "titulo",
                        onChange: handleChange
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Row, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Form.Text, {
                                    className: "text-muted",
                                    children: "Ej. Casa en venta en Palmaris, Canc\xfan"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                className: "d-flex justify-content-end",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        style: {
                                            color: longitudTitulo > 75 ? "red" : "black"
                                        },
                                        children: longitudTitulo
                                    }),
                                    "/75"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Row, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                        md: 6,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row mb-3",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-sm-5 col-md-4 col-lg-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_9___default().content),
                                        children: "Tipo de inmueble"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-sm-7 col-md-8 col-lg-6",
                                    children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_loading_Loading__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Form.Select, {
                                        value: tipoPropiedad,
                                        onChange: (e)=>setTipoPropiedad(e.target.value)
                                        ,
                                        children: propertyTypes.map((propertyType)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: propertyType._id,
                                                children: propertyType.nombre
                                            }, propertyType._id)
                                        )
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                        md: 6,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row mb-3",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-sm-5 col-md-4 col-lg-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_9___default().content),
                                        children: "Tipo de operaci\xf3n"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-sm-7 col-md-8 col-lg-6",
                                    children: cargando ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_loading_Loading__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Form.Select, {
                                        value: categoria1,
                                        onChange: (e)=>setCategoria(e.target.value)
                                        ,
                                        children: categorias.map((categoria)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: categoria._id,
                                                children: categoria.nombre
                                            }, categoria._id)
                                        )
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_9___default().MiniSub),
                children: "Ubicaci\xf3n"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_9___default().line)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12 mb-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_buscador_SeleccionarLugar__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12 mb-5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_MapaUbicacion__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-sm-12 col-md-6 col-xxl-6",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row d-flex justify-content-start",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-sm-12 col-xxl-3",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_9___default().labels2),
                                        children: "Valor"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-sm-12 col-xxl-7",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "input-group mb-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "input-group-text",
                                                children: "$"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "number",
                                                className: "form-control",
                                                placeholder: "5,000.00",
                                                value: precio,
                                                name: "precio",
                                                onChange: handleChange,
                                                min: 0
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-sm-12 col-md-6 col-xxl-6",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row d-flex justify-content-end",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-sm-12 col-xxl-5",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_FormDesign_module_css__WEBPACK_IMPORTED_MODULE_9___default().labels2),
                                        children: "Comisiones"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-sm-12 col-xxl-5",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "input-group mb-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "input-group-text",
                                                children: "%"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "number",
                                                className: "form-control",
                                                placeholder: "5",
                                                value: comisiones,
                                                name: "comisiones",
                                                onChange: handleChange,
                                                min: 0
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12 my-4",
                        children: titulo.length === 0 || precio <= 0 || !direccion ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button_Button__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            titulo: "Siguiente",
                            btn: "Disabled"
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button_Button__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            titulo: "Siguiente",
                            onClick: handleNextStep
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormStepOne);


/***/ })

};
;