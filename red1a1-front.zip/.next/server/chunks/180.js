exports.id = 180;
exports.ids = [180];
exports.modules = {

/***/ 4677:
/***/ ((module) => {

// Exports
module.exports = {
	"position": "Dashboard_position__s5qF_",
	"sidebarposition": "Dashboard_sidebarposition__7rFNJ",
	"navbarCustom": "Dashboard_navbarCustom__4AYDr",
	"hoja": "Dashboard_hoja__WB22A",
	"navLinks": "Dashboard_navLinks__RYSDw",
	"profileImg": "Dashboard_profileImg__yIo9Q",
	"bgContainer": "Dashboard_bgContainer__eLXJr",
	"dashContain": "Dashboard_dashContain__ioOlB",
	"burger": "Dashboard_burger__lMALa"
};


/***/ }),

/***/ 180:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Dashboard)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react-pro-sidebar"
var external_react_pro_sidebar_ = __webpack_require__(1981);
// EXTERNAL MODULE: ./src/components/paginas/dashboard/Dashboard.module.css
var Dashboard_module = __webpack_require__(4677);
var Dashboard_module_default = /*#__PURE__*/__webpack_require__.n(Dashboard_module);
// EXTERNAL MODULE: ./src/context/auth/AuthContext.tsx
var AuthContext = __webpack_require__(1165);
;// CONCATENATED MODULE: ./src/components/paginas/dashboard/Sidebar.tsx








const Sidebar = ({ handleToggleSidebar , toggled , collapsed  })=>{
    const { logOut  } = (0,external_react_.useContext)(AuthContext/* AuthContext */.V);
    const router = (0,router_.useRouter)();
    const goToHome = ()=>router.push("/")
    ;
    return(/*#__PURE__*/ jsx_runtime_.jsx(external_react_pro_sidebar_.ProSidebar, {
        toggled: toggled,
        collapsed: collapsed,
        onToggle: handleToggleSidebar,
        breakPoint: "md",
        className: (Dashboard_module_default()).sidebarposition,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_pro_sidebar_.Menu, {
            iconShape: "square",
            className: "mx-2",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_pro_sidebar_.SidebarHeader, {
                    className: "text-center mb-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            className: "pointer",
                            onClick: goToHome,
                            src: "/images/logos/red1-color.png",
                            alt: "Red 1 a 1"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_pro_sidebar_.SidebarContent, {
                    className: "py-4",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_pro_sidebar_.MenuItem, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "bi bi-grid-3x3 me-2"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/dashboard",
                                    children: "Resumen"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_pro_sidebar_.MenuItem, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "bi bi-people-fill me-2"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/dashboard/Usuarios",
                                    children: "Usuarios"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_pro_sidebar_.MenuItem, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "bi bi-house-fill me-2"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/dashboard/Inmuebles",
                                    children: "Inmuebles"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_pro_sidebar_.MenuItem, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "bi bi-wallet2 me-2"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/dashboard/pagos/wallet",
                                    children: "Wallet"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_pro_sidebar_.MenuItem, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "bi bi-receipt-cutoff me-2"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/dashboard/pagos/referencias",
                                    children: "Referencias"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const dashboard_Sidebar = (Sidebar);

;// CONCATENATED MODULE: ./src/components/paginas/dashboard/Main.tsx





const Main = ({ children , handleToggleSidebar , titulo  })=>{
    const { auth  } = (0,external_react_.useContext)(AuthContext/* AuthContext */.V);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        style: {
            width: "100%",
            overflowX: "hidden",
            background: "#F4F3FF"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row ",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col text-end",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Dashboard_module_default()).navbarCustom,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: `${(Dashboard_module_default()).hoja} mt-2`,
                                children: titulo
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: `${(Dashboard_module_default()).navLinks} mx-3 pointer`,
                                    children: "Inicio"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/perfil",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    className: `pointer ${(Dashboard_module_default()).profileImg}`,
                                    src: auth.img,
                                    alt: "..."
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                onClick: ()=>handleToggleSidebar(true)
                ,
                className: `bi bi-list ${(Dashboard_module_default()).burger}`,
                style: {
                    fontSize: 30,
                    color: "black"
                }
            }),
            children
        ]
    }));
};
/* harmony default export */ const dashboard_Main = (Main);

;// CONCATENATED MODULE: ./src/components/layout/Dashboard.tsx




const DashboardLayout = ({ children , titulo  })=>{
    const { 0: collapsed , 1: setCollapsed  } = (0,external_react_.useState)(false);
    const { 0: toggled , 1: setToggled  } = (0,external_react_.useState)(false);
    const handleCollapsedChange = (checked)=>{
        setCollapsed(checked);
    };
    const handleToggleSidebar = (value)=>{
        setToggled(value);
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "d-flex",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(dashboard_Sidebar, {
                collapsed: collapsed,
                toggled: toggled,
                handleToggleSidebar: handleToggleSidebar
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(dashboard_Main, {
                handleCollapsedChange: handleCollapsedChange,
                handleToggleSidebar: handleToggleSidebar,
                titulo: titulo,
                children: children
            })
        ]
    }));
};
/* harmony default export */ const Dashboard = (DashboardLayout);


/***/ })

};
;