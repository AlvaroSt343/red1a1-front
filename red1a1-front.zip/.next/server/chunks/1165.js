"use strict";
exports.id = 1165;
exports.ids = [1165];
exports.modules = {

/***/ 1165:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ AuthContext),
/* harmony export */   "H": () => (/* binding */ AuthProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _helpers_fetch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(22);





const AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
});
const initialState = {
    uid: null,
    checking: true,
    logged: false,
    nombre: undefined,
    apellido: undefined,
    correo: undefined,
    telefonoOficina: undefined,
    telefonoPersonal: undefined,
    direccionFisica: undefined,
    sitioweb: undefined,
    facebookpage: undefined,
    instagram: undefined,
    nombreInmobiliaria: undefined,
    twitter: undefined,
    youtube: undefined,
    perfilEmpresarial: undefined,
    linkedin: undefined,
    img: undefined,
    logo: undefined,
    role: undefined,
    paqueteAdquirido: undefined,
    usuarios: undefined,
    propietario: undefined,
    google: undefined,
    recibirCorreo: false
};
const AuthProvider = ({ children  })=>{
    const { 0: auth , 1: setAuth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialState);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { 0: mostrarLogin , 1: setMostrarLogin  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: mostrarRegistro , 1: setMostrarRegistro  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const abrirLogin = ()=>setMostrarLogin(true)
    ;
    const cerrarLogin = ()=>setMostrarLogin(false)
    ;
    const abrirRegistro = ()=>setMostrarRegistro(true)
    ;
    const cerrarRegistro = ()=>setMostrarRegistro(false)
    ;
    const login = async (correo, password)=>{
        const resp = await (0,_helpers_fetch__WEBPACK_IMPORTED_MODULE_4__/* .fetchSinToken */ .L8)("auth/login", {
            correo,
            password
        }, "POST");
        if (resp.token) {
            localStorage.setItem("token", resp.token);
            const { usuario  } = resp;
            setAuth({
                uid: usuario.uid,
                checking: false,
                logged: true,
                nombre: usuario.nombre,
                apellido: usuario.apellido,
                correo: usuario.correo,
                direccionFisica: usuario.direccionFisica,
                sitioweb: usuario.sitioweb,
                facebookpage: usuario.facebookpage,
                instagram: usuario.instagram,
                nombreInmobiliaria: usuario.nombreInmobiliaria,
                telefonoOficina: usuario.telefonoOficina,
                telefonoPersonal: usuario.telefonoPersonal,
                twitter: usuario.twitter,
                youtube: usuario.youtube,
                perfilEmpresarial: usuario.perfilEmpresarial,
                linkedin: usuario.linkedin,
                img: usuario.img,
                logo: usuario.logo,
                role: usuario.role,
                paqueteAdquirido: usuario.paqueteAdquirido,
                usuarios: usuario.usuarios,
                propietario: usuario.propietario,
                google: undefined,
                recibirCorreo: usuario.recibirCorreo
            });
        }
        return resp;
    };
    const register = async (nombre, apellido, correo, password, role)=>{
        const resp = await (0,_helpers_fetch__WEBPACK_IMPORTED_MODULE_4__/* .fetchSinToken */ .L8)("usuarios", {
            nombre,
            apellido,
            correo,
            password,
            role
        }, "POST");
        if (resp.token) {
            localStorage.setItem("token", resp.token);
            const { usuario  } = resp;
            setAuth({
                uid: usuario.uid,
                checking: false,
                logged: true,
                nombre: usuario.nombre,
                apellido: usuario.apellido,
                correo: usuario.correo,
                direccionFisica: usuario.direccionFisica,
                sitioweb: usuario.sitioweb,
                facebookpage: usuario.facebookpage,
                instagram: usuario.instagram,
                nombreInmobiliaria: usuario.nombreInmobiliaria,
                telefonoOficina: usuario.telefonoOficina,
                telefonoPersonal: usuario.telefonoPersonal,
                twitter: usuario.twitter,
                youtube: usuario.youtube,
                perfilEmpresarial: usuario.perfilEmpresarial,
                linkedin: auth.linkedin,
                img: usuario.img,
                logo: usuario.logo,
                role: usuario.role,
                paqueteAdquirido: usuario.paqueteAdquirido,
                usuarios: usuario.usuarios,
                propietario: usuario.propietario,
                google: undefined,
                recibirCorreo: usuario.recibirCorreo
            });
        }
        return resp;
    };
    const crearUsuario = async (nombre, apellido, correo, password, role, propietario)=>{
        const resp = await (0,_helpers_fetch__WEBPACK_IMPORTED_MODULE_4__/* .crearUsuarioFetch */ .bf)("usuarios/propietario", {
            nombre,
            apellido,
            correo,
            password,
            role,
            propietario
        });
        if (resp.token) {
            localStorage.setItem("token", resp.token);
            const { usuario  } = resp;
            setAuth({
                uid: usuario.uid,
                checking: false,
                logged: true,
                nombre: usuario.nombre,
                apellido: usuario.apellido,
                correo: usuario.correo,
                direccionFisica: usuario.direccionFisica,
                sitioweb: usuario.sitioweb,
                facebookpage: usuario.facebookpage,
                instagram: usuario.instagram,
                nombreInmobiliaria: usuario.nombreInmobiliaria,
                telefonoOficina: usuario.telefonoOficina,
                telefonoPersonal: usuario.telefonoPersonal,
                twitter: usuario.twitter,
                youtube: usuario.youtube,
                perfilEmpresarial: usuario.perfilEmpresarial,
                linkedin: auth.linkedin,
                img: usuario.img,
                logo: usuario.logo,
                role: usuario.role,
                paqueteAdquirido: usuario.paqueteAdquirido,
                usuarios: usuario.usuarios,
                propietario: usuario.propietario,
                google: undefined,
                recibirCorreo: usuario.recibirCorreo
            });
        }
        return resp;
    };
    const verificaToken = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async ()=>{
        const token = localStorage.getItem("token");
        if (!token) {
            setAuth({
                uid: null,
                checking: true,
                logged: false,
                nombre: undefined,
                apellido: undefined,
                correo: undefined,
                telefonoOficina: undefined,
                telefonoPersonal: undefined,
                direccionFisica: undefined,
                sitioweb: undefined,
                facebookpage: undefined,
                instagram: undefined,
                nombreInmobiliaria: undefined,
                twitter: undefined,
                youtube: undefined,
                perfilEmpresarial: undefined,
                linkedin: undefined,
                img: undefined,
                logo: undefined,
                role: undefined,
                paqueteAdquirido: undefined,
                usuarios: undefined,
                propietario: undefined,
                google: undefined,
                recibirCorreo: false
            });
            return false;
        }
        const resp = await (0,_helpers_fetch__WEBPACK_IMPORTED_MODULE_4__/* .fetchConToken */ .Z_)("auth/renovarToken");
        if (resp.ok) {
            localStorage.setItem("token", resp.token);
            const { usuario  } = resp;
            setAuth({
                uid: usuario.uid,
                checking: false,
                logged: true,
                nombre: usuario.nombre,
                apellido: usuario.apellido,
                correo: usuario.correo,
                direccionFisica: usuario.direccionFisica,
                sitioweb: usuario.sitioweb,
                facebookpage: usuario.facebookpage,
                instagram: usuario.instagram,
                nombreInmobiliaria: usuario.nombreInmobiliaria,
                telefonoOficina: usuario.telefonoOficina,
                telefonoPersonal: usuario.telefonoPersonal,
                twitter: usuario.twitter,
                youtube: usuario.youtube,
                perfilEmpresarial: usuario.perfilEmpresarial,
                linkedin: usuario.linkedin,
                img: usuario.img,
                logo: usuario.logo,
                role: usuario.role,
                paqueteAdquirido: usuario.paqueteAdquirido,
                usuarios: usuario.usuarios,
                propietario: usuario.propietario,
                google: true,
                recibirCorreo: usuario.recibirCorreo
            });
            return true;
        } else {
            setAuth({
                uid: null,
                checking: false,
                logged: false,
                nombre: undefined,
                apellido: undefined,
                correo: undefined,
                telefonoOficina: undefined,
                telefonoPersonal: undefined,
                direccionFisica: undefined,
                sitioweb: undefined,
                facebookpage: undefined,
                instagram: undefined,
                nombreInmobiliaria: undefined,
                twitter: undefined,
                youtube: undefined,
                perfilEmpresarial: undefined,
                linkedin: undefined,
                img: undefined,
                logo: undefined,
                role: undefined,
                paqueteAdquirido: undefined,
                usuarios: undefined,
                propietario: undefined,
                google: undefined,
                recibirCorreo: false
            });
            return false;
        }
    }, []);
    const logOut = async ()=>{
        localStorage.removeItem("token");
        setAuth({
            uid: null,
            checking: false,
            logged: false,
            nombre: undefined,
            apellido: undefined,
            correo: undefined,
            telefonoOficina: undefined,
            telefonoPersonal: undefined,
            direccionFisica: undefined,
            sitioweb: undefined,
            facebookpage: undefined,
            instagram: undefined,
            nombreInmobiliaria: undefined,
            twitter: undefined,
            youtube: undefined,
            perfilEmpresarial: undefined,
            linkedin: undefined,
            img: undefined,
            logo: undefined,
            role: undefined,
            paqueteAdquirido: undefined,
            usuarios: undefined,
            propietario: undefined,
            google: undefined,
            recibirCorreo: false
        });
    };
    const actualizarPerfil = async (formulario)=>{
        const resp = await (0,_helpers_fetch__WEBPACK_IMPORTED_MODULE_4__/* .actualizarPerfilFetch */ .P5)("usuarios/" + auth.uid, formulario);
        const { usuario  } = resp;
        if (resp.ok) {
            setAuth({
                uid: usuario.uid,
                checking: false,
                logged: true,
                nombre: usuario.nombre,
                apellido: usuario.apellido,
                correo: usuario.correo,
                direccionFisica: usuario.direccionFisica,
                sitioweb: usuario.sitioweb,
                facebookpage: usuario.facebookpage,
                instagram: usuario.instagram,
                nombreInmobiliaria: usuario.nombreInmobiliaria,
                telefonoOficina: usuario.telefonoOficina,
                telefonoPersonal: usuario.telefonoPersonal,
                twitter: usuario.twitter,
                youtube: usuario.youtube,
                perfilEmpresarial: usuario.perfilEmpresarial,
                linkedin: usuario.linkedin,
                img: usuario.img,
                logo: usuario.logo,
                role: usuario.role,
                paqueteAdquirido: usuario.paqueteAdquirido,
                usuarios: usuario.usuarios,
                propietario: usuario.propietario,
                google: undefined,
                recibirCorreo: usuario.recibirCorreo
            });
            react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast.success(resp.msg);
            router.push("/perfil");
        }
        if (!resp.ok) {
            resp.errors.map((error)=>{
                react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast.error(error.msg);
            });
        }
        return resp;
    };
    const actualizarRol = async (data, uid)=>{
        const resp = await (0,_helpers_fetch__WEBPACK_IMPORTED_MODULE_4__/* .actualizarRolUsuario */ .uW)(`usuarios/rol/${uid}`, data);
        const { usuario  } = resp;
        if (resp.ok) {
            setAuth({
                uid: usuario.uid,
                checking: false,
                logged: true,
                nombre: usuario.nombre,
                apellido: usuario.apellido,
                correo: usuario.correo,
                direccionFisica: usuario.direccionFisica,
                sitioweb: usuario.sitioweb,
                facebookpage: usuario.facebookpage,
                instagram: usuario.instagram,
                nombreInmobiliaria: usuario.nombreInmobiliaria,
                telefonoOficina: usuario.telefonoOficina,
                telefonoPersonal: usuario.telefonoPersonal,
                twitter: usuario.twitter,
                youtube: usuario.youtube,
                perfilEmpresarial: usuario.perfilEmpresarial,
                linkedin: usuario.linkedin,
                img: usuario.img,
                logo: usuario.logo,
                role: usuario.role,
                paqueteAdquirido: usuario.paqueteAdquirido,
                usuarios: usuario.usuarios,
                propietario: usuario.propietario,
                google: undefined,
                recibirCorreo: usuario.recibirCorreo
            });
        }
        return resp;
    };
    const fotoPerfil = async (formData)=>{
        const resp = await (0,_helpers_fetch__WEBPACK_IMPORTED_MODULE_4__/* .subirFotoPerfil */ .ec)(`subidas/usuarios/${auth.uid}`, formData);
        const { usuario  } = resp;
        if (resp.ok) {
            setAuth({
                uid: usuario.uid,
                checking: false,
                logged: true,
                nombre: usuario.nombre,
                apellido: usuario.apellido,
                correo: usuario.correo,
                direccionFisica: usuario.direccionFisica,
                sitioweb: usuario.sitioweb,
                facebookpage: usuario.facebookpage,
                instagram: usuario.instagram,
                nombreInmobiliaria: usuario.nombreInmobiliaria,
                telefonoOficina: usuario.telefonoOficina,
                telefonoPersonal: usuario.telefonoPersonal,
                twitter: usuario.twitter,
                youtube: usuario.youtube,
                perfilEmpresarial: usuario.perfilEmpresarial,
                linkedin: usuario.linkedin,
                img: usuario.img,
                logo: usuario.logo,
                role: usuario.role,
                paqueteAdquirido: usuario.paqueteAdquirido,
                usuarios: usuario.usuarios,
                propietario: usuario.propietario,
                google: undefined,
                recibirCorreo: usuario.recibirCorreo
            });
            react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast.success(resp.msg);
        }
        return resp;
    };
    const signInWithGoogle = async (response)=>{
        /* response:GoogleLoginResponse */ const id_token = response.getAuthResponse().id_token;
        const body = {
            id_token
        };
        const res = await (0,_helpers_fetch__WEBPACK_IMPORTED_MODULE_4__/* .googleLogin */ .u9)("auth/google", body);
        if (res.ok) {
            localStorage.setItem("token", res.token);
            const { usuario  } = res;
            setAuth({
                uid: usuario.uid,
                checking: false,
                logged: true,
                nombre: usuario.nombre,
                apellido: usuario.apellido,
                correo: usuario.correo,
                direccionFisica: usuario.direccionFisica,
                sitioweb: usuario.sitioweb,
                facebookpage: usuario.facebookpage,
                instagram: usuario.instagram,
                nombreInmobiliaria: usuario.nombreInmobiliaria,
                telefonoOficina: usuario.telefonoOficina,
                telefonoPersonal: usuario.telefonoPersonal,
                twitter: usuario.twitter,
                youtube: usuario.youtube,
                perfilEmpresarial: usuario.perfilEmpresarial,
                linkedin: usuario.linkedin,
                img: usuario.img,
                logo: usuario.logo,
                role: usuario.role,
                paqueteAdquirido: usuario.paqueteAdquirido,
                usuarios: usuario.usuarios,
                propietario: usuario.propietario,
                google: true,
                recibirCorreo: usuario.recibirCorreo
            });
        }
        setMostrarLogin(false);
        setMostrarRegistro(false);
        return res;
    };
    const signInWithFacebook = async ()=>{
        console.log("Iniciando sesi\xf3n con facebook");
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthContext.Provider, {
        value: {
            auth,
            login,
            logOut,
            register,
            signInWithGoogle,
            signInWithFacebook,
            verificaToken,
            actualizarPerfil,
            fotoPerfil,
            mostrarLogin,
            mostrarRegistro,
            setMostrarLogin,
            setMostrarRegistro,
            abrirLogin,
            cerrarLogin,
            abrirRegistro,
            cerrarRegistro,
            actualizarRol,
            crearUsuario
        },
        children: children
    }));
};


/***/ })

};
;