exports.id = 8884;
exports.ids = [8884];
exports.modules = {

/***/ 5264:
/***/ ((module) => {

// Exports
module.exports = {
	"barraCategorias": "BarraCategoria_barraCategorias__yw6VP",
	"barraCategoriasInactive": "BarraCategoria_barraCategoriasInactive__iXUO1",
	"btnContainer": "BarraCategoria_btnContainer__hhLWV",
	"barraItemPropertyType": "BarraCategoria_barraItemPropertyType__VovYI",
	"barraItemPropertyTypeSelected": "BarraCategoria_barraItemPropertyTypeSelected__Hzt0l",
	"barraItemCategory": "BarraCategoria_barraItemCategory__DZcUH",
	"barraItemCategorySelected": "BarraCategoria_barraItemCategorySelected__X_0IK"
};


/***/ }),

/***/ 2507:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorCard": "MapCards_contenedorCard__Fsb2U",
	"containerimg": "MapCards_containerimg__khGjT",
	"imgCard": "MapCards_imgCard__J8kCP",
	"title": "MapCards_title__Co0t5",
	"ciudad": "MapCards_ciudad__pXlFD",
	"operacion": "MapCards_operacion__l70Sg",
	"descripcion": "MapCards_descripcion__9IQVs",
	"precio": "MapCards_precio__9nnfP",
	"btnDetalle": "MapCards_btnDetalle__S_9aV"
};


/***/ }),

/***/ 3469:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _BarraCategoria_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5264);
/* harmony import */ var _BarraCategoria_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_BarraCategoria_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var context_map_MapContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1131);




const BarraCategorias = (props)=>{
    const { setTipoPropiedad , propertyTypes , categorias , setCategoria  } = props;
    const { categoria: categoria1 , tipoPropiedad  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(context_map_MapContext__WEBPACK_IMPORTED_MODULE_2__/* .MapContext */ .X);
    const { 0: selectedPro , 1: setSelected  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(tipoPropiedad);
    const { 0: selectedCat , 1: setselectedCat  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(categoria1);
    const seleccionarCategoria = (id)=>{
        setCategoria(id);
        setselectedCat(id);
    };
    const seleccionarTipoPropiedad = (id)=>{
        setTipoPropiedad(id);
        setSelected(id);
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `text-center`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_BarraCategoria_module_css__WEBPACK_IMPORTED_MODULE_3___default().btnContainer),
            children: [
                propertyTypes.map((propertyType)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: `${selectedPro === propertyType._id ? (_BarraCategoria_module_css__WEBPACK_IMPORTED_MODULE_3___default().barraItemPropertyTypeSelected) : (_BarraCategoria_module_css__WEBPACK_IMPORTED_MODULE_3___default().barraItemPropertyType)} mx-2 pointer`,
                        onClick: ()=>seleccionarTipoPropiedad(propertyType._id)
                        ,
                        children: propertyType.nombre
                    }, propertyType._id)
                ),
                categorias === null || categorias === void 0 ? void 0 : categorias.map((categoria)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: `${selectedCat === categoria._id ? (_BarraCategoria_module_css__WEBPACK_IMPORTED_MODULE_3___default().barraItemCategorySelected) : (_BarraCategoria_module_css__WEBPACK_IMPORTED_MODULE_3___default().barraItemCategory)} mx-2 pointer`,
                        onClick: ()=>{
                            seleccionarCategoria(categoria._id);
                        },
                        children: categoria.nombre
                    }, categoria._id)
                )
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BarraCategorias);


/***/ }),

/***/ 6746:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var context_map_MapContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1131);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Inicio_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7945);
/* harmony import */ var _Inicio_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Inicio_module_css__WEBPACK_IMPORTED_MODULE_3__);




const BuscarZona = ()=>{
    const { filtros  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(context_map_MapContext__WEBPACK_IMPORTED_MODULE_1__/* .MapContext */ .X);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `${filtros ? (_Inicio_module_css__WEBPACK_IMPORTED_MODULE_3___default().buscarZonaWithFilter) : (_Inicio_module_css__WEBPACK_IMPORTED_MODULE_3___default().buscarZona)} pointer text-center`,
        children: "Buscar en esta zona"
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BuscarZona);


/***/ }),

/***/ 3374:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2433);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3877);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3015);
/* harmony import */ var _helpers_formatPrice__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5762);
/* harmony import */ var _MapCards_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2507);
/* harmony import */ var _MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1165);
/* harmony import */ var _helpers_fetch__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(22);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_5__, swiper__WEBPACK_IMPORTED_MODULE_4__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_5__, swiper__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);













swiper__WEBPACK_IMPORTED_MODULE_4__["default"].use([
    swiper__WEBPACK_IMPORTED_MODULE_4__.EffectCube,
    swiper__WEBPACK_IMPORTED_MODULE_4__.Pagination,
    swiper__WEBPACK_IMPORTED_MODULE_4__.Autoplay
]);
const InfoWindowMap = ({ inmueble  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { auth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_6__/* .AuthContext */ .V);
    const handleProperty = async (id, slug)=>{
        const data = {
            usuario: auth.uid,
            inmueble: id
        };
        router.push(`/propiedades/${slug}`);
        await (0,_helpers_fetch__WEBPACK_IMPORTED_MODULE_7__/* .agregarHist */ .Fl)("historial", data);
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_3__.InfoWindow, {
        position: {
            lat: inmueble.lat,
            lng: inmueble.lng
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().contenedorCard),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "col text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().containerimg),
                            children: inmueble.imgs.length === 1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_5__.Swiper, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    className: (_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().imgCard),
                                    src: inmueble.imgs[0]
                                })
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_5__.Swiper, {
                                effect: "cube",
                                grabCursor: true,
                                loop: true,
                                autoplay: {
                                    delay: 3200,
                                    disableOnInteraction: false,
                                    pauseOnMouseEnter: true
                                },
                                cubeEffect: {
                                    shadow: true,
                                    slideShadows: true,
                                    shadowOffset: 20,
                                    shadowScale: 0.94
                                },
                                className: "mySwiper",
                                children: inmueble.imgs.map((img)=>{
                                    const sepracion = img.split(".");
                                    const extension = sepracion[sepracion.length - 1];
                                    const extensionesValidas = [
                                        "mp4"
                                    ];
                                    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_5__.SwiperSlide, {
                                        children: extensionesValidas.includes(extension) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                            src: img,
                                            controls: true,
                                            controlsList: "nodownload",
                                            style: {
                                                height: 200,
                                                width: "100%",
                                                overflow: "hidden"
                                            }
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            className: (_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().imgCard),
                                            src: img
                                        })
                                    }, img));
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `${(_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().title)} mb-2`,
                            children: inmueble.titulo
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mb-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: `${(_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().operacion)}`,
                                children: inmueble.categoria.nombre
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `${(_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().descripcion)} mb-2`,
                            children: inmueble.descripcion ? inmueble.descripcion : "Sin descripci\xf3n"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `${(_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().precio)} mb-3`,
                            children: (0,_helpers_formatPrice__WEBPACK_IMPORTED_MODULE_9__/* .formatPrice */ .T)(inmueble.precio)
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mb-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: (_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().btnDetalle),
                                onClick: ()=>handleProperty(inmueble._id, inmueble.slug)
                                ,
                                children: "Ver detalles"
                            })
                        })
                    ]
                })
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InfoWindowMap);

});

/***/ }),

/***/ 8884:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2433);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_map_MapContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1131);
/* harmony import */ var _hooks_useInmuebles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8605);
/* harmony import */ var _ui_loading_Loading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6220);
/* harmony import */ var _InfoWindowMap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3374);
/* harmony import */ var _BuscarZona__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6746);
/* harmony import */ var hooks_useCategories__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1821);
/* harmony import */ var _BarraCategorias__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3469);
/* harmony import */ var _BarraCategoria_module_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5264);
/* harmony import */ var _BarraCategoria_module_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_BarraCategoria_module_css__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_InfoWindowMap__WEBPACK_IMPORTED_MODULE_6__]);
_InfoWindowMap__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];











const containerStyle = {
    width: "100%",
    height: "87vh"
};
const options = {
    disableDefaultUI: true,
    streetViewControl: true,
    zoomControl: true,
    fullscreenControl: false
};
const MapaUbicacion = ()=>{
    const { coordenadas , zoom , setCoordenadas , southEast: southEast1 , setSouthEast , northWest: northWest1 , setNorthWest , southWest: southWest1 , setSouthWest , northEast: northEast1 , setNorthEast , categoria , tipoPropiedad , setCategoria , setTipoPropiedad , filtros ,  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_map_MapContext__WEBPACK_IMPORTED_MODULE_3__/* .MapContext */ .X);
    const { 0: seleccionado , 1: setSeleccionado  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { loading , propertyTypes  } = (0,hooks_useCategories__WEBPACK_IMPORTED_MODULE_8__/* .useTipoPropiedad */ .T)();
    const { categorias  } = (0,hooks_useCategories__WEBPACK_IMPORTED_MODULE_8__/* .useCategories */ .L)();
    const mapRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { inmuebles , cargando  } = (0,_hooks_useInmuebles__WEBPACK_IMPORTED_MODULE_4__/* .useInmueblesCoordenadas */ .vx)(southEast1, northWest1, southWest1, northEast1, coordenadas, categoria, tipoPropiedad);
    const propiedadSeleccionada = (id, lat, lng)=>{
        setCoordenadas({
            lat,
            lng
        });
        setSeleccionado(id);
    };
    const closeInfoWindow = ()=>setSeleccionado("")
    ;
    const onBoundsChange = ()=>{
        var ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7, ref8, ref9, ref10, ref11, ref12, ref13, ref14, ref15, ref16, ref17;
        const southWest = (ref2 = (ref1 = (ref = mapRef.current) === null || ref === void 0 ? void 0 : ref.state.map) === null || ref1 === void 0 ? void 0 : ref1.getBounds()) === null || ref2 === void 0 ? void 0 : ref2.getSouthWest().toJSON();
        const northEast = (ref5 = (ref4 = (ref3 = mapRef.current) === null || ref3 === void 0 ? void 0 : ref3.state.map) === null || ref4 === void 0 ? void 0 : ref4.getBounds()) === null || ref5 === void 0 ? void 0 : ref5.getNorthEast().toJSON();
        const northWest = {
            lat: (ref8 = (ref7 = (ref6 = mapRef.current) === null || ref6 === void 0 ? void 0 : ref6.state.map) === null || ref7 === void 0 ? void 0 : ref7.getBounds()) === null || ref8 === void 0 ? void 0 : ref8.getNorthEast().lat(),
            lng: (ref11 = (ref10 = (ref9 = mapRef.current) === null || ref9 === void 0 ? void 0 : ref9.state.map) === null || ref10 === void 0 ? void 0 : ref10.getBounds()) === null || ref11 === void 0 ? void 0 : ref11.getSouthWest().lng()
        };
        const southEast = {
            lat: (ref14 = (ref13 = (ref12 = mapRef.current) === null || ref12 === void 0 ? void 0 : ref12.state.map) === null || ref13 === void 0 ? void 0 : ref13.getBounds()) === null || ref14 === void 0 ? void 0 : ref14.getSouthWest().lat(),
            lng: (ref17 = (ref16 = (ref15 = mapRef.current) === null || ref15 === void 0 ? void 0 : ref15.state.map) === null || ref16 === void 0 ? void 0 : ref16.getBounds()) === null || ref17 === void 0 ? void 0 : ref17.getNorthEast().lng()
        };
        setSouthEast(southEast);
        setNorthWest(northWest);
        setSouthWest(southWest);
        setNorthEast(northEast);
    };
    const handleClick = ()=>{
        onBoundsChange();
        getCenter();
    };
    const getCenter = ()=>{
        var ref, ref18, ref19;
        const center = (ref19 = (ref18 = (ref = mapRef.current) === null || ref === void 0 ? void 0 : ref.state.map) === null || ref18 === void 0 ? void 0 : ref18.getCenter()) === null || ref19 === void 0 ? void 0 : ref19.toJSON();
        setCoordenadas(center);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        onBoundsChange();
    }, [
        coordenadas,
        cargando
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.GoogleMap, {
            ref: mapRef,
            mapContainerStyle: containerStyle,
            center: {
                lat: coordenadas.lat,
                lng: coordenadas.lng
            },
            onClick: closeInfoWindow,
            zoom: zoom,
            options: options,
            children: cargando ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_loading_Loading__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        onClick: handleClick,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_BuscarZona__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: filtros ? (_BarraCategoria_module_css__WEBPACK_IMPORTED_MODULE_10___default().barraCategorias) : (_BarraCategoria_module_css__WEBPACK_IMPORTED_MODULE_10___default().barraCategoriasInactive),
                                children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_loading_Loading__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_BarraCategorias__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                    setTipoPropiedad: setTipoPropiedad,
                                    propertyTypes: propertyTypes,
                                    setCategoria: setCategoria,
                                    categorias: categorias
                                })
                            })
                        ]
                    }),
                    inmuebles === null || inmuebles === void 0 ? void 0 : inmuebles.filter((inmueble)=>{
                        return inmueble.publicado === true;
                    }).map((inmueble)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.Marker, {
                                animation: 2,
                                position: {
                                    lat: inmueble.lat,
                                    lng: inmueble.lng
                                },
                                icon: {
                                    url: "/images/icons/marcador.svg",
                                    scaledSize: new google.maps.Size(50, 50)
                                },
                                onClick: ()=>propiedadSeleccionada(inmueble._id, inmueble.lat, inmueble.lng)
                                ,
                                children: seleccionado === inmueble._id ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InfoWindowMap__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    inmueble: inmueble
                                }) : null
                            })
                        }, inmueble._id)
                    )
                ]
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(MapaUbicacion));

});

/***/ }),

/***/ 5762:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ formatPrice)
/* harmony export */ });
const formatPrice = (price)=>{
    const precio = new Intl.NumberFormat("es-MX", {
        currency: "MXN"
    }).format(price);
    const formato = "$" + precio;
    return formato;
};


/***/ })

};
;