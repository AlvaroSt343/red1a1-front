exports.id = 6852;
exports.ids = [6852];
exports.modules = {

/***/ 2924:
/***/ ((module) => {

// Exports
module.exports = {
	"paquetesCard": "paquetes_paquetesCard__6CfGs",
	"paquetesCardTitle": "paquetes_paquetesCardTitle__pUcHs",
	"listItems": "paquetes_listItems__aOLSf",
	"paquetesCardPrecio": "paquetes_paquetesCardPrecio__jm0Ke",
	"paquetesCardPrecio2": "paquetes_paquetesCardPrecio2__WnIlz",
	"tabla": "paquetes_tabla__Jcfxn",
	"btnContratar": "paquetes_btnContratar__sJChF",
	"ajusteBtn": "paquetes_ajusteBtn__0fSkc",
	"advice": "paquetes_advice__G1HpM",
	"section2": "paquetes_section2__hefCQ",
	"precio": "paquetes_precio__QFNNI",
	"paqueteInvalido": "paquetes_paqueteInvalido__4qj6Y",
	"precioAPagar": "paquetes_precioAPagar__X7p91",
	"modalS1": "paquetes_modalS1__Hw_DA",
	"modalS2": "paquetes_modalS2__A4VSj",
	"modalS1header": "paquetes_modalS1header__CPnGf",
	"modalS2header": "paquetes_modalS2header__DuE3q",
	"headTitle": "paquetes_headTitle__qSobB",
	"S1content": "paquetes_S1content__wT5OQ",
	"S2content": "paquetes_S2content__HID46",
	"S1labels": "paquetes_S1labels__hy0M2",
	"S2labels": "paquetes_S2labels__ohkmD",
	"inputS2": "paquetes_inputS2__jj0Jq",
	"selectS2": "paquetes_selectS2__vEi4V"
};


/***/ }),

/***/ 6852:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Paquetes)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@stripe/react-stripe-js"
var react_stripe_js_ = __webpack_require__(4515);
// EXTERNAL MODULE: external "@stripe/stripe-js"
var stripe_js_ = __webpack_require__(943);
// EXTERNAL MODULE: ./src/credentials/credentials.tsx
var credentials = __webpack_require__(6681);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/hooks/usePaquetes.tsx


const usePaqueteInd = ()=>{
    const { 0: paquete , 1: setPaquete  } = (0,external_react_.useState)();
    const { 0: cargando , 1: setCargando  } = (0,external_react_.useState)(true);
    const obtenerPaquetes = async ()=>{
        const resp = await fetch(`${credentials/* production */.C7}/paquetes/62420cbcce32c067c37ac093`);
        const data = await resp.json();
        setPaquete(data.paquete);
        setCargando(false);
    };
    (0,external_react_.useEffect)(()=>{
        obtenerPaquetes();
    }, []);
    return {
        paquete,
        cargando
    };
};
const usePaquetes = ()=>{
    const { 0: paquetes , 1: setPaquetes  } = (0,external_react_.useState)([]);
    const { 0: cargando , 1: setCargando  } = (0,external_react_.useState)(true);
    const obtenerPaquetes = async ()=>{
        const resp = await fetch(`${credentials/* production */.C7}/paquetes?desde=1`);
        const data = await resp.json();
        setPaquetes(data.paquetes);
        setCargando(false);
    };
    (0,external_react_.useEffect)(()=>{
        obtenerPaquetes();
    }, []);
    return {
        paquetes,
        cargando
    };
};

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__(2245);
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_);
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: ./src/context/auth/AuthContext.tsx
var AuthContext = __webpack_require__(1165);
// EXTERNAL MODULE: ./src/helpers/formatPrice.tsx
var formatPrice = __webpack_require__(5762);
// EXTERNAL MODULE: ./src/components/ui/button/Button.tsx
var Button = __webpack_require__(7924);
// EXTERNAL MODULE: ./src/components/ui/loading/Loading.tsx
var Loading = __webpack_require__(6220);
// EXTERNAL MODULE: ./src/components/ui/modaltitle/Modaltitle.tsx
var Modaltitle = __webpack_require__(4074);
// EXTERNAL MODULE: ./src/components/paginas/paquetes/paquetes.module.css
var paquetes_module = __webpack_require__(2924);
var paquetes_module_default = /*#__PURE__*/__webpack_require__.n(paquetes_module);
// EXTERNAL MODULE: ./src/helpers/fetch.tsx
var helpers_fetch = __webpack_require__(22);
;// CONCATENATED MODULE: ./src/components/paginas/paquetes/Individual.tsx















const Individual = ()=>{
    const { auth , abrirLogin , actualizarRol  } = (0,external_react_.useContext)(AuthContext/* AuthContext */.V);
    const { 0: precioSeleccionado , 1: setPrecioSeleccionado  } = (0,external_react_.useState)("");
    const router = (0,router_.useRouter)();
    const stripe = (0,react_stripe_js_.useStripe)();
    const elements = (0,react_stripe_js_.useElements)();
    const { 0: show , 1: setShow  } = (0,external_react_.useState)(false);
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    const { paquete , cargando  } = usePaqueteInd();
    const { 0: mostrarPago , 1: setMostrarPago  } = (0,external_react_.useState)(false);
    const { 0: mostrarTransferencia , 1: setMostrarTransferencia  } = (0,external_react_.useState)(false);
    const handleClose = ()=>{
        setPrecioSeleccionado("");
        setShow(false);
    };
    const handleNext = ()=>setShow(false)
    ;
    const handleShow = ()=>setShow(true)
    ;
    const ocultarPago = ()=>setMostrarPago(false)
    ;
    const ocultarTransferencia = ()=>setMostrarTransferencia(false)
    ;
    const pagar = ()=>{
        handleNext();
        setMostrarPago(true);
    };
    const pagarTransferencia = ()=>{
        handleNext();
        setMostrarTransferencia(true);
    };
    const generarReferencia = async (e)=>{
        e.preventDefault();
        const body = {
            usuario: auth.uid,
            paquete: paquete === null || paquete === void 0 ? void 0 : paquete._id,
            referencia: Math.floor(1000000000000 + Math.random() * 9000000000000),
            precio: Number(precioSeleccionado),
            importe: Number(precioSeleccionado),
            totalUsuarios: 1,
            estado: false
        };
        const res = await (0,helpers_fetch/* generarRefInd */.Np)("referencias", body);
        if (res.ok) {
            external_react_toastify_.toast.success(res.msg);
            router.push("/perfil/referencias-de-pago");
        } else {
            external_react_toastify_.toast.success("Error al generear la referencia. Int\xe9ntelo de nuevo");
        }
    };
    const onSubmit = async (e)=>{
        e.preventDefault();
        if (!stripe || !elements) return;
        const { error , paymentMethod  } = await stripe.createPaymentMethod({
            type: "card",
            card: elements.getElement(react_stripe_js_.CardElement)
        });
        setLoading(true);
        const fechaPago = external_moment_default()().format();
        const fechaVencimiento = external_moment_default()(fechaPago).add(1, "y").format();
        const fechaVencimientoSem = external_moment_default()(fechaPago).add(6, "M").format();
        const fechaVencimientoTri = external_moment_default()(fechaPago).add(3, "M").format();
        if (!error) {
            const pago = paymentMethod;
            const body = {
                usuario: auth.uid,
                paquete: paquete === null || paquete === void 0 ? void 0 : paquete._id,
                precio: Number(precioSeleccionado),
                importe: Number(precioSeleccionado),
                fechaPago,
                fechaVencimiento: Number(precioSeleccionado) === 1250 ? fechaVencimientoTri : Number(precioSeleccionado) === 2799 ? fechaVencimientoSem : fechaVencimiento,
                metodoPago: pago === null || pago === void 0 ? void 0 : pago.type,
                vigencia: true,
                idPago: pago === null || pago === void 0 ? void 0 : pago.id,
                totalUsuarios: 1
            };
            const correoPedido = {
                apellido: auth.apellido,
                nombre: auth.nombre,
                correo: auth.correo,
                idCompra: pago === null || pago === void 0 ? void 0 : pago.id,
                nombrePaquete: paquete === null || paquete === void 0 ? void 0 : paquete.nombre,
                precio: Number(precioSeleccionado),
                importe: Number(precioSeleccionado)
            };
            const correoPedidoAdmin = {
                apellido: auth.apellido,
                nombre: auth.nombre,
                idCompra: pago === null || pago === void 0 ? void 0 : pago.id,
                nombrePaquete: paquete === null || paquete === void 0 ? void 0 : paquete.nombre,
                precio: Number(precioSeleccionado),
                importe: Number(precioSeleccionado)
            };
            try {
                const resp = await (0,helpers_fetch/* anadirPaqueteInv */.tU)("pedidos", body);
                auth.role !== "Administrador" ? await actualizarRol({
                    role: paquete === null || paquete === void 0 ? void 0 : paquete.nombre,
                    paqueteAdquirido: paquete === null || paquete === void 0 ? void 0 : paquete._id
                }, auth.uid) : null;
                await (0,helpers_fetch/* nuevoPedido */.Az)("correos/nuevo-pedido", correoPedido);
                await (0,helpers_fetch/* nuevoPedidoAdmin */.xh)("correos/nuevo-pedido-admin", correoPedidoAdmin);
                if (resp.ok) {
                    external_react_toastify_.toast.success(resp.msg);
                    ocultarPago();
                    router.push("/perfil/historial-de-pagos");
                }
                if (!resp.ok) external_react_toastify_.toast.error(resp.msg);
                setLoading(false);
            } catch (error) {
                console.log(error);
            }
            setLoading(false);
        }
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "col-sm-12 col-md-6 col-lg-4 col-xl-3 mb-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (paquetes_module_default()).paquetesCard,
                children: cargando ? /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {
                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "d-flex justify-content-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/images/icons/individual.png",
                                alt: "Paquete"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `${(paquetes_module_default()).paquetesCardTitle}  my-4 text-center`,
                            children: paquete === null || paquete === void 0 ? void 0 : paquete.nombre
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("table", {
                                    className: (paquetes_module_default()).tabla,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tbody", {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "tupla",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: (paquetes_module_default()).listItems,
                                                            children: "Anual"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "tupla",
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: (paquetes_module_default()).paquetesCardPrecio2,
                                                            children: [
                                                                (0,formatPrice/* formatPrice */.T)(paquete.precioAnual),
                                                                "MXN"
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "tupla",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: (paquetes_module_default()).listItems,
                                                            children: "Semestral"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "tupla",
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: (paquetes_module_default()).paquetesCardPrecio2,
                                                            children: [
                                                                (0,formatPrice/* formatPrice */.T)(paquete.precioSemestral),
                                                                "MXN"
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "tupla",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: (paquetes_module_default()).listItems,
                                                            children: "Trimestral"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "tupla",
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: (paquetes_module_default()).paquetesCardPrecio2,
                                                            children: [
                                                                (0,formatPrice/* formatPrice */.T)(paquete.precioTrimestral),
                                                                "MXN"
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: (paquetes_module_default()).listItems,
                                    children: paquete === null || paquete === void 0 ? void 0 : paquete.descripcion
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `${(paquetes_module_default()).ajusteBtn} text-center`,
                            children: auth.uid ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                children: auth.role === "Individual" ? /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    titulo: "Contratado",
                                    btn: "Disabled"
                                }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                    children: auth.role === "B\xe1sico" || auth.role === "Intermedio" || auth.role === "Avanzado" ? /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        titulo: "Contratar",
                                        btn: "Disabled"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        onClick: handleShow,
                                        type: "button",
                                        className: (paquetes_module_default()).btnContratar,
                                        children: "CONTRATAR"
                                    })
                                })
                            }) : /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: abrirLogin,
                                type: "button",
                                className: (paquetes_module_default()).btnContratar,
                                children: "CONTRATAR"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Modal, {
                show: show,
                onHide: handleClose,
                contentClassName: (paquetes_module_default()).modalS1,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Modal.Header, {
                        closeButton: true,
                        className: (paquetes_module_default()).modalS1header
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Modal.Body, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (paquetes_module_default()).headTitle,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Modaltitle/* default */.Z, {
                                    titulo: "Individual"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `${(paquetes_module_default()).S1content} text-center mt-5 mb-4`,
                                children: "Selecciona el tipo de plan que desea."
                            }),
                            loading ? /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {
                            }) : null,
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "row d-flex justify-content-center",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "col-sm-12 col-md-12 col-lg-9",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "row d-flex justify-content-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "col-4",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: `${(paquetes_module_default()).S1labels}`,
                                                            children: "Anual"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "col-7 text-end mb-2",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                value: paquete === null || paquete === void 0 ? void 0 : paquete.precioAnual,
                                                                onChange: (e)=>setPrecioSeleccionado(e.target.value)
                                                                ,
                                                                type: "radio",
                                                                name: "individual"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: `${(paquetes_module_default()).precio} ms-2`,
                                                                children: paquete ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                                    children: [
                                                                        (0,formatPrice/* formatPrice */.T)(paquete === null || paquete === void 0 ? void 0 : paquete.precioAnual),
                                                                        " MXN"
                                                                    ]
                                                                }) : null
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "col-4",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: `${(paquetes_module_default()).S1labels}`,
                                                            children: "Semestral"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "col-7 text-end mb-2",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                value: paquete === null || paquete === void 0 ? void 0 : paquete.precioSemestral,
                                                                onChange: (e)=>setPrecioSeleccionado(e.target.value)
                                                                ,
                                                                type: "radio",
                                                                name: "individual"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: `${(paquetes_module_default()).precio} ms-2`,
                                                                children: paquete ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                                    children: [
                                                                        (0,formatPrice/* formatPrice */.T)(paquete.precioSemestral),
                                                                        " MXN"
                                                                    ]
                                                                }) : null
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "col-4",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: `${(paquetes_module_default()).S1labels}`,
                                                            children: "Trimestral"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "col-7 text-end mb-2",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                value: paquete === null || paquete === void 0 ? void 0 : paquete.precioTrimestral,
                                                                type: "radio",
                                                                name: "individual",
                                                                onChange: (e)=>setPrecioSeleccionado(e.target.value)
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: `${(paquetes_module_default()).precio} ms-2`,
                                                                children: paquete ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                                    children: [
                                                                        (0,formatPrice/* formatPrice */.T)(paquete.precioTrimestral),
                                                                        " MXN"
                                                                    ]
                                                                }) : null
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-center mt-5",
                                        children: precioSeleccionado ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                    titulo: "Pagar con tarjeta",
                                                    onClick: pagar
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                    titulo: "Transferencia bancaria",
                                                    onClick: pagarTransferencia
                                                })
                                            ]
                                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                    titulo: "Pago con tarjeta",
                                                    btn: "Disabled"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                    titulo: "Transferencia bancaria",
                                                    btn: "Disabled"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Modal, {
                contentClassName: (paquetes_module_default()).modalS1,
                show: mostrarPago,
                onHide: ocultarPago,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Modal.Header, {
                        closeButton: true,
                        className: (paquetes_module_default()).modalS1header
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Modaltitle/* default */.Z, {
                        titulo: "Paquete individual"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `${(paquetes_module_default()).S1content} text-center`,
                        children: [
                            "Cantidad a pagar:",
                            " ",
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                className: `${(paquetes_module_default()).precio}`,
                                children: [
                                    (0,formatPrice/* formatPrice */.T)(Number(precioSeleccionado)),
                                    " MXN"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("br", {
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Form, {
                        onSubmit: onSubmit,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "form-group px-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_stripe_js_.CardElement, {
                                    options: {
                                        style: {
                                            base: {
                                                iconColor: "#2C2C2C",
                                                color: "#2C2C2C",
                                                fontWeight: "500",
                                                fontFamily: "Roboto, Open Sans, Segoe UI, sans-serif",
                                                fontSize: "16px",
                                                "::placeholder": {
                                                    color: "#757575"
                                                }
                                            },
                                            invalid: {
                                                iconColor: "#E44122",
                                                color: "#E44122"
                                            }
                                        }
                                    }
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-center my-3",
                                children: !stripe ? /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    titulo: "Pagar",
                                    btn: "Disabled"
                                }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: loading ? /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        titulo: "Finalizar pedido"
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Modal, {
                contentClassName: (paquetes_module_default()).modalS1,
                show: mostrarTransferencia,
                onHide: ocultarTransferencia,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Modal.Header, {
                        closeButton: true,
                        className: (paquetes_module_default()).modalS1header
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Modaltitle/* default */.Z, {
                        titulo: "Paquete individual"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `${(paquetes_module_default()).S1content} text-center`,
                        children: [
                            "Cantidad a pagar:",
                            " ",
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                className: `${(paquetes_module_default()).precio}`,
                                children: [
                                    (0,formatPrice/* formatPrice */.T)(Number(precioSeleccionado)),
                                    " MXN"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("br", {
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Form, {
                        onSubmit: generarReferencia,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "p-4",
                                        children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Id maiores neque harum distinctio cumque ratione dolorum quam aperiam aut repudiandae in quas architecto molestias quo est obcaecati, similique, voluptatum consectetur!"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        titulo: "Generar referencia"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const paquetes_Individual = (Individual);

// EXTERNAL MODULE: external "react-select"
var external_react_select_ = __webpack_require__(1929);
var external_react_select_default = /*#__PURE__*/__webpack_require__.n(external_react_select_);
// EXTERNAL MODULE: ./src/hooks/useForm.tsx
var useForm = __webpack_require__(1267);
;// CONCATENATED MODULE: ./src/components/paginas/paquetes/PaqueteMultiple.tsx
















const PaqueteMultiple = (props)=>{
    const { titulo , precio , descripcion , options , avanzado , usuario , id  } = props;
    const { auth , abrirLogin , actualizarRol  } = (0,external_react_.useContext)(AuthContext/* AuthContext */.V);
    const { 0: show , 1: setShow  } = (0,external_react_.useState)(false);
    const { 0: mostrarPago , 1: setMostrarPago  } = (0,external_react_.useState)(false);
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    const router = (0,router_.useRouter)();
    const stripe = (0,react_stripe_js_.useStripe)();
    const elements = (0,react_stripe_js_.useElements)();
    const { 0: mostrarTransferencia , 1: setMostrarTransferencia  } = (0,external_react_.useState)(false);
    const { 0: usuariosSeleccionados , 1: setUsuariosSeleccionados  } = (0,external_react_.useState)(usuario);
    const { formulario , handleChange  } = (0,useForm/* useForm */.c)({
        usuarios: 11
    });
    const { usuarios  } = formulario;
    const handleClose = ()=>setShow(false)
    ;
    const handleShow = ()=>setShow(true)
    ;
    const ocultarPago = ()=>setMostrarPago(false)
    ;
    const handleNext = ()=>setShow(false)
    ;
    const pagar = ()=>{
        handleNext();
        setMostrarPago(true);
        !avanzado ? setUsuariosSeleccionados(usuariosSeleccionados.value) : null;
    };
    const ocultarTransferencia = ()=>setMostrarTransferencia(false)
    ;
    const pagarTransferencia = ()=>{
        handleNext();
        setMostrarTransferencia(true);
    };
    const generarReferencia = async (e)=>{
        e.preventDefault();
        const body = {
            usuario: auth.uid,
            paquete: id,
            referencia: Math.floor(1000000000000 + Math.random() * 9000000000000),
            precio: Number(precio),
            importe: avanzado ? Number(precio) * Number(usuarios) : Number(precio) * Number(usuariosSeleccionados.value),
            totalUsuarios: avanzado ? Number(usuarios) : usuariosSeleccionados.value,
            estado: false
        };
        const res = await (0,helpers_fetch/* generarRefMul */.Sd)("referencias", body);
        if (res.ok) {
            external_react_toastify_.toast.success(res.msg);
            router.push("/perfil/referencias-de-pago");
        } else {
            external_react_toastify_.toast.success("Error al generear la referencia. Int\xe9ntelo de nuevo");
        }
    };
    const onSubmit = async (e)=>{
        e.preventDefault();
        if (!stripe || !elements) return;
        const { error , paymentMethod  } = await stripe.createPaymentMethod({
            type: "card",
            card: elements.getElement(react_stripe_js_.CardElement)
        });
        setLoading(true);
        const fechaPago = external_moment_default()().format();
        const fechaVencimiento = external_moment_default()(fechaPago).add(1, "y").format();
        if (!error) {
            const pago = paymentMethod;
            const body = {
                usuario: auth.uid,
                paquete: id,
                precio: Number(precio),
                importe: avanzado ? Number(precio) * Number(usuarios) : Number(precio) * Number(usuariosSeleccionados),
                fechaPago,
                fechaVencimiento,
                metodoPago: pago === null || pago === void 0 ? void 0 : pago.type,
                vigencia: true,
                idPago: pago === null || pago === void 0 ? void 0 : pago.id,
                totalUsuarios: avanzado ? usuarios : usuariosSeleccionados
            };
            const correoPedido = {
                apellido: auth.apellido,
                nombre: auth.nombre,
                correo: auth.correo,
                idCompra: pago === null || pago === void 0 ? void 0 : pago.id,
                nombrePaquete: titulo,
                precio: Number(precio),
                importe: avanzado ? Number(precio) * Number(usuarios) : Number(precio) * Number(usuariosSeleccionados)
            };
            const correoPedidoAdmin = {
                apellido: auth.apellido,
                nombre: auth.nombre,
                idCompra: pago === null || pago === void 0 ? void 0 : pago.id,
                nombrePaquete: titulo,
                precio: Number(precio),
                importe: avanzado ? Number(precio) * Number(usuarios) : Number(precio) * Number(usuariosSeleccionados)
            };
            try {
                const resp = await (0,helpers_fetch/* anadirPaqueteInv */.tU)("pedidos", body);
                auth.role !== "Administrador" ? await actualizarRol({
                    role: titulo,
                    paqueteAdquirido: id,
                    usuarios: avanzado ? usuarios : usuariosSeleccionados
                }, auth.uid) : null;
                await (0,helpers_fetch/* nuevoPedido */.Az)("correos/nuevo-pedido", correoPedido);
                await (0,helpers_fetch/* nuevoPedidoAdmin */.xh)("correos/nuevo-pedido-admin", correoPedidoAdmin);
                if (resp.ok) {
                    external_react_toastify_.toast.success(resp.msg);
                    ocultarPago();
                    router.push("/perfil/historial-de-pagos");
                }
                if (!resp.ok) external_react_toastify_.toast.error(resp.msg);
                setLoading(false);
            } catch (error) {
                console.log(error);
            }
            setLoading(false);
        }
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "col-sm-12 col-md-6 col-lg-4 col-xl-3 mb-4",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (paquetes_module_default()).paquetesCard,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "d-flex justify-content-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/images/icons/basico.png",
                            alt: "..."
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `${(paquetes_module_default()).paquetesCardTitle}  my-4 text-center`,
                        children: titulo
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `${(paquetes_module_default()).paquetesCardPrecio} text-center`,
                        children: [
                            (0,formatPrice/* formatPrice */.T)(precio),
                            " MXN"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: (paquetes_module_default()).listItems,
                                children: "Anuales"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: (paquetes_module_default()).listItems,
                                children: descripcion
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `${(paquetes_module_default()).ajusteBtn} text-center`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                            children: auth.uid ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                children: auth.role === titulo ? /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    titulo: "Contratado",
                                    btn: "Disabled"
                                }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                    children: auth.role === "Intermedio" ? /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        titulo: "Contratar",
                                        btn: "Disabled"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                        children: auth.role === "Avanzado" ? /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                            titulo: "Contratar",
                                            btn: "Disabled"
                                        }) : /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            onClick: handleShow,
                                            type: "button",
                                            className: (paquetes_module_default()).btnContratar,
                                            children: "CONTRATAR"
                                        })
                                    })
                                })
                            }) : /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: abrirLogin,
                                type: "button",
                                className: (paquetes_module_default()).btnContratar,
                                children: "CONTRATAR"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Modal, {
                show: show,
                onHide: handleClose,
                contentClassName: (paquetes_module_default()).modalS2,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Modal.Header, {
                        closeButton: true,
                        className: (paquetes_module_default()).modalS2header
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Modal.Body, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (paquetes_module_default()).headTitle,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Modaltitle/* default */.Z, {
                                    titulo: titulo
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: `${(paquetes_module_default()).S2content} text-center mt-5 mb-4`,
                                children: [
                                    "Especifique el n\xfamero de ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {
                                    }),
                                    " usuarios a contratar."
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: avanzado ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "row d-flex justify-content-center",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "col-10",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "row d-flex justify-content-between",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "col-9",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: `${(paquetes_module_default()).S2labels}`,
                                                            children: "Digite el n\xfamero de usuarios"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "col-3",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "number",
                                                            min: 11,
                                                            name: "usuarios",
                                                            value: usuarios,
                                                            onChange: handleChange,
                                                            className: (paquetes_module_default()).inputS2
                                                        })
                                                    }),
                                                    usuarios < 11 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: `col-12 text-center my-4 ${(paquetes_module_default()).paqueteInvalido}`,
                                                        children: "Paquete v\xe1lido para 11 usuarios en adelante"
                                                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: `${(paquetes_module_default()).precioAPagar} col-12 text-center mt-4 mb-5`,
                                                                children: (0,formatPrice/* formatPrice */.T)(precio * usuarios)
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "col-12 d-flex justify-content-center",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                                        titulo: "Pago con tarjeta",
                                                                        onClick: pagar
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                                        titulo: "Transferencia bancaria",
                                                                        onClick: pagarTransferencia
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "row d-flex justify-content-center ",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "col-sm-12 col-md-12 col-lg-9",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "row d-flex justify-content-between",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "col-8",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: `${(paquetes_module_default()).S2labels}`,
                                                            children: "N\xfamero de usuarios"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "col-4",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_select_default()), {
                                                            defaultValue: usuariosSeleccionados,
                                                            onChange: setUsuariosSeleccionados,
                                                            options: options,
                                                            classNamePrefix: (paquetes_module_default()).selectS2
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "col-12",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "text-center mt-4",
                                                            children: usuariosSeleccionados.value ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: `${(paquetes_module_default()).precioAPagar} text-center`,
                                                                children: (0,formatPrice/* formatPrice */.T)(precio * usuariosSeleccionados.value) + " MXN"
                                                            }) : null
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "col-12",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "text-center mt-5",
                                                            children: !usuariosSeleccionados.value ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "d-flex justify-content-center",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                                        titulo: "Pago con tarjeta",
                                                                        btn: "Disabled"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                                        titulo: "Transferencia bancaria",
                                                                        btn: "Disabled"
                                                                    })
                                                                ]
                                                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "d-flex justify-content-center",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                                        titulo: "Pago con tarjeta",
                                                                        onClick: pagar
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                                        titulo: "Transferencia bancaria",
                                                                        onClick: pagarTransferencia
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Modal, {
                show: mostrarPago,
                onHide: ocultarPago,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Modal.Header, {
                        closeButton: true,
                        className: (paquetes_module_default()).modalS1header
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Modaltitle/* default */.Z, {
                        titulo: titulo
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `${(paquetes_module_default()).S1content} text-center`,
                        children: [
                            "Cantidad a pagar:",
                            " ",
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                className: `${(paquetes_module_default()).precio}`,
                                children: [
                                    avanzado ? (0,formatPrice/* formatPrice */.T)(Number(precio) * Number(usuarios)) : (0,formatPrice/* formatPrice */.T)(Number(precio) * usuariosSeleccionados),
                                    "MXN"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("br", {
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Form, {
                        onSubmit: onSubmit,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "form-group px-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_stripe_js_.CardElement, {
                                    options: {
                                        style: {
                                            base: {
                                                iconColor: "#2C2C2C",
                                                color: "#2C2C2C",
                                                fontWeight: "500",
                                                fontFamily: "Roboto, Open Sans, Segoe UI, sans-serif",
                                                fontSize: "16px",
                                                "::placeholder": {
                                                    color: "#757575"
                                                }
                                            },
                                            invalid: {
                                                iconColor: "#E44122",
                                                color: "#E44122"
                                            }
                                        }
                                    }
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-center my-3",
                                children: !stripe ? /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    titulo: "Pagar",
                                    btn: "Disabled"
                                }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: loading ? /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        titulo: "Finalizar pedido"
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Modal, {
                contentClassName: (paquetes_module_default()).modalS1,
                show: mostrarTransferencia,
                onHide: ocultarTransferencia,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Modal.Header, {
                        closeButton: true,
                        className: (paquetes_module_default()).modalS1header
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Modaltitle/* default */.Z, {
                        titulo: titulo
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `${(paquetes_module_default()).S1content} text-center`,
                        children: [
                            "Cantidad a pagar:",
                            " ",
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                className: `${(paquetes_module_default()).precio}`,
                                children: [
                                    avanzado ? (0,formatPrice/* formatPrice */.T)(Number(precio) * Number(usuarios)) : (0,formatPrice/* formatPrice */.T)(Number(precio) * usuariosSeleccionados.value),
                                    "MXN"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("br", {
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Form, {
                        onSubmit: generarReferencia,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "p-4",
                                        children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Id maiores neque harum distinctio cumque ratione dolorum quam aperiam aut repudiandae in quas architecto molestias quo est obcaecati, similique, voluptatum consectetur!"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        titulo: "Generar referencia"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const paquetes_PaqueteMultiple = (PaqueteMultiple);

;// CONCATENATED MODULE: ./src/components/paginas/paquetes/Paquetes.tsx








const basico = [
    {
        value: 3,
        label: "3"
    },
    {
        value: 4,
        label: "4"
    },
    {
        value: 5,
        label: "5"
    }, 
];
const intermedio = [
    {
        value: 6,
        label: "6"
    },
    {
        value: 7,
        label: "7"
    },
    {
        value: 8,
        label: "8"
    },
    {
        value: 9,
        label: "9"
    },
    {
        value: 10,
        label: "10"
    }, 
];
const stripePromise = (0,stripe_js_.loadStripe)(credentials/* stripePublicId */.tB);
const PaquetesCards = ()=>{
    const { paquetes  } = usePaquetes();
    return(/*#__PURE__*/ jsx_runtime_.jsx(react_stripe_js_.Elements, {
        stripe: stripePromise,
        options: {
            appearance: {
                theme: "stripe"
            }
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "my-5",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(paquetes_Individual, {
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                            children: paquetes.map((paquete)=>/*#__PURE__*/ jsx_runtime_.jsx(paquetes_PaqueteMultiple, {
                                    id: paquete._id,
                                    titulo: paquete.nombre,
                                    precio: paquete.precioAnual,
                                    descripcion: paquete.descripcion,
                                    usuario: paquete.nombre === "B\xe1sico" ? 3 : paquete.nombre === "Intermedio" ? 6 : 11,
                                    options: paquete.nombre === "B\xe1sico" ? basico : paquete.nombre === "Intermedio" ? intermedio : null,
                                    avanzado: paquete.nombre === "Avanzado" ? true : false
                                }, paquete._id)
                            )
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `${(paquetes_module_default()).advice} text-center`,
                                children: "*Precios indicados son por cada usuario."
                            })
                        })
                    ]
                })
            })
        })
    }));
};
/* harmony default export */ const Paquetes = (PaquetesCards);


/***/ }),

/***/ 5762:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ formatPrice)
/* harmony export */ });
const formatPrice = (price)=>{
    const precio = new Intl.NumberFormat("es-MX", {
        currency: "MXN"
    }).format(price);
    const formato = "$" + precio;
    return formato;
};


/***/ })

};
;